// Parameterized 2D Cel-Shaded Character Rig for the Every Memory Has a Price 2.5D Style.
// Renders crisp RGBA Canvas2D textures mounted as depth-sorted billboards in Three.js.
// Implements the full measured emotion state machine:
//   eyes:  'ring' | 'wide_ring' | 'half_lid' | 'dash_closed' | 'wink_left' | 'empty_dot' | 'squeezed_x' | 'squiggly'
//   brows: 'neutral' | 'worried' | 'angry' | 'raised' | 'resolute' | 'sad'
//   mouth: 'dot' | 'smile' | 'smirk' | 'flat' | 'o_open' | 'wavy_anxious' | 'toothy_grin' | 'frown'
//   hair:  'spiky' | 'limp' | 'hood' | 'bald'
//   extras: { sweatDrop, tear, tremorLines, drainHalo, amberEyeGlow, badgeColor }
import * as THREE from 'three';

const INK = '#120E1E';

export function createCharacterTexture(opts = {}) {
  const {
    width = 1024,
    height = 1536,
    skinBase = '#F0DFD6',
    skinShadow = '#B29CC6',
    warmRim = 'rgba(255,222,178,0.45)',
    hairColor = '#D95B26',
    hairShade = '#8F3116',
    hairState = 'spiky', // 'spiky' | 'limp' | 'hood' | 'bald'
    torsoColor = '#E2A42B',
    torsoStripe = '#F6F3EC',
    badgeColor = '#4CAF4F',
    eyes = 'ring',
    brows = 'neutral',
    mouth = 'dot',
    pupilOffset = [0, 0],
    headTiltRad = 0,
    leftArm = 'down',    // 'down' | 'hip' | 'raised' | 'hold_front'
    rightArm = 'down',   // 'down' | 'point' | 'raised' | 'hold_front'
    extras = {},
  } = opts;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const g = canvas.getContext('2d');
  g.lineCap = 'round';
  g.lineJoin = 'round';

  const inkW = Math.round(width * 0.0175); // ~18px at 1024w (~1% frame width when scaled)

  // 1. Optional Memory-Drain Blue-White Halo Outline (Reference: S19 f1607-1640)
  if (extras.drainHalo) {
    g.save();
    const hg = g.createRadialGradient(512, 430, 140, 512, 430, 320);
    hg.addColorStop(0.0, 'rgba(180,210,255,0.68)');
    hg.addColorStop(0.55, 'rgba(145,180,255,0.34)');
    hg.addColorStop(1.0, 'rgba(120,150,255,0)');
    g.fillStyle = hg;
    g.beginPath();
    g.arc(512, 430, 320, 0, Math.PI * 2);
    g.fill();
    g.restore();
  }

  // 2. Stick Legs (Rubber-hose ink lines + simple flat feet)
  g.strokeStyle = INK;
  g.lineWidth = inkW;
  g.beginPath();
  g.moveTo(455, 935);
  g.quadraticCurveTo(445, 1170, 432, 1390);
  g.lineTo(372, 1406);
  g.moveTo(568, 935);
  g.quadraticCurveTo(576, 1170, 588, 1390);
  g.lineTo(652, 1406);
  g.stroke();

  // 3. Stick Arms with Round Ball-Hands (No Fingers!)
  function drawArm(side, pose) {
    const sx = side === 'left' ? 405 : 618;
    const sy = 700;
    const dir = side === 'left' ? -1 : 1;
    let cx = sx + dir * 85;
    let cy = 835;
    let ex = sx + dir * 40;
    let ey = 960;

    if (pose === 'hip') {
      cx = sx + dir * 130; cy = 820; ex = sx + dir * 35; ey = 900;
    } else if (pose === 'raised') {
      cx = sx + dir * 155; cy = 620; ex = sx + dir * 110; ey = 455;
    } else if (pose === 'point') {
      cx = sx + dir * 135; cy = 740; ex = sx + dir * 245; ey = 765;
    } else if (pose === 'hold_front') {
      cx = sx + dir * 75; cy = 825; ex = 512 + dir * 38; ey = 855;
    }

    g.strokeStyle = INK;
    g.lineWidth = inkW;
    g.beginPath();
    g.moveTo(sx, sy);
    g.quadraticCurveTo(cx, cy, ex, ey);
    g.stroke();

    // Iconic round ball-hand
    g.fillStyle = INK;
    g.beginPath();
    g.arc(ex, ey, inkW * 1.15, 0, Math.PI * 2);
    g.fill();
  }
  drawArm('left', leftArm);
  drawArm('right', rightArm);

  // 4. Bean Torso (Flat Fill + Simple Vest Stripe + Optional Icon Badge)
  g.save();
  g.beginPath();
  g.moveTo(415, 615);
  g.bezierCurveTo(355, 695, 350, 885, 425, 955);
  g.bezierCurveTo(485, 998, 545, 998, 602, 955);
  g.bezierCurveTo(672, 885, 668, 695, 608, 615);
  g.closePath();
  g.fillStyle = torsoColor;
  g.fill();

  g.save();
  g.clip();
  // Subtle lavender shadow band on left edge of torso
  g.fillStyle = 'rgba(28,22,68,0.22)';
  g.fillRect(340, 610, 95, 400);
  // Center shirt stripe
  if (torsoStripe) {
    g.fillStyle = torsoStripe;
    g.fillRect(478, 610, 68, 395);
    g.strokeStyle = INK;
    g.lineWidth = Math.round(inkW * 0.45);
    g.strokeRect(478, 610, 68, 395);
  }
  // Small circular chest badge (e.g. Jerry's frog emblem)
  if (badgeColor) {
    g.fillStyle = badgeColor;
    g.beginPath();
    g.arc(512, 718, 28, 0, Math.PI * 2);
    g.fill();
    g.strokeStyle = INK;
    g.lineWidth = Math.round(inkW * 0.38);
    g.stroke();
  }
  g.restore();

  g.strokeStyle = INK;
  g.lineWidth = inkW;
  g.stroke();
  g.restore();

  // 5. Large Round Cel Head (~42% of visible figure height)
  g.save();
  g.translate(512, 432);
  g.rotate(headTiltRad);

  const rx = 202;
  const ry = 192;

  // Hood silhouette behind head if hooded character (e.g. Shopkeeper)
  if (hairState === 'hood') {
    g.beginPath();
    g.moveTo(-245, 220);
    g.bezierCurveTo(-295, 20, -255, -245, 0, -268);
    g.bezierCurveTo(255, -245, 295, 20, 245, 220);
    g.closePath();
    g.fillStyle = '#15162E';
    g.fill();
    g.strokeStyle = '#6E82D6'; // subtle cool rim line on hood
    g.lineWidth = 8;
    g.stroke();
    g.strokeStyle = INK;
    g.lineWidth = inkW;
    g.stroke();
  }

  // Head base fill
  g.beginPath();
  g.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
  g.fillStyle = skinBase;
  g.fill();

  // Soft single-step lavender cel shadow crescent + warm rim inside clip
  g.save();
  g.clip();
  const sh = g.createRadialGradient(rx * 0.28, -ry * 0.14, rx * 0.35, -rx * 0.12, ry * 0.12, rx * 1.15);
  sh.addColorStop(0.0, 'rgba(178,156,198,0)');
  sh.addColorStop(0.68, 'rgba(150,130,180,0.18)');
  sh.addColorStop(1.0, skinShadow);
  g.fillStyle = sh;
  g.fillRect(-rx * 1.2, -ry * 1.2, rx * 2.4, ry * 2.4);

  const wr = g.createRadialGradient(rx * 0.72, -ry * 0.12, 10, rx * 0.68, -ry * 0.1, rx * 0.72);
  wr.addColorStop(0.0, warmRim);
  wr.addColorStop(1.0, 'rgba(255,220,175,0)');
  g.fillStyle = wr;
  g.fillRect(-rx * 1.2, -ry * 1.2, rx * 2.4, ry * 2.4);
  g.restore();

  // Thick pure-black head outline
  g.beginPath();
  g.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
  g.strokeStyle = INK;
  g.lineWidth = inkW;
  g.stroke();

  // 6. Hair (Spiky with Zig-Zag Shading = Healthy | Limp Flat = Sick)
  if (hairState === 'spiky') {
    g.save();
    g.beginPath();
    g.moveTo(-195, -55);
    g.quadraticCurveTo(-225, -185, -125, -205);
    g.lineTo(-148, -252);
    g.lineTo(-55, -218);
    g.lineTo(-18, -278);
    g.lineTo(42, -216);
    g.lineTo(118, -264);
    g.lineTo(138, -196);
    g.quadraticCurveTo(218, -172, 196, -50);
    g.quadraticCurveTo(85, -112, 0, -106);
    g.quadraticCurveTo(-98, -112, -195, -55);
    g.closePath();
    g.fillStyle = hairColor;
    g.fill();
    g.strokeStyle = INK;
    g.lineWidth = inkW * 0.85;
    g.stroke();
    // Signature zig-zag interior hair strokes
    g.strokeStyle = hairShade;
    g.lineWidth = 8;
    g.beginPath();
    g.moveTo(-120, -135); g.lineTo(-82, -180); g.lineTo(-42, -135);
    g.lineTo(8, -195); g.lineTo(52, -138); g.lineTo(105, -182);
    g.stroke();
    // Pale highlight strokes
    g.strokeStyle = 'rgba(255,212,158,0.65)';
    g.lineWidth = 6;
    g.beginPath();
    g.moveTo(-70, -198); g.lineTo(-22, -238);
    g.moveTo(45, -196); g.lineTo(95, -230);
    g.stroke();
    g.restore();
  } else if (hairState === 'limp') {
    g.save();
    g.beginPath();
    g.moveTo(-196, -42);
    g.quadraticCurveTo(-185, -178, 0, -185);
    g.quadraticCurveTo(185, -178, 196, -42);
    g.quadraticCurveTo(80, -95, 0, -88);
    g.quadraticCurveTo(-80, -95, -196, -42);
    g.closePath();
    g.fillStyle = hairColor;
    g.fill();
    g.strokeStyle = INK;
    g.lineWidth = inkW * 0.85;
    g.stroke();
    g.restore();
  }

  // 7. Eyes (Primary Acting & Emotional State Machine)
  const [px, py] = pupilOffset;
  const eyeLx = -62, eyeRx = 62, eyeY = -12;

  function drawSingleEye(ex, mode) {
    if (mode === 'ring' || mode === 'wide_ring') {
      const r = mode === 'wide_ring' ? 38 : 30;
      g.fillStyle = '#FFFFFF';
      g.beginPath(); g.arc(ex, eyeY, r, 0, Math.PI * 2); g.fill();
      g.strokeStyle = INK; g.lineWidth = 9; g.stroke();
      g.fillStyle = extras.amberEyeGlow ? '#FFB833' : INK;
      g.beginPath(); g.arc(ex + px, eyeY + py, mode === 'wide_ring' ? 10 : 12, 0, Math.PI * 2); g.fill();
    } else if (mode === 'half_lid') {
      g.fillStyle = '#FFFFFF';
      g.beginPath(); g.arc(ex, eyeY, 30, 0, Math.PI * 2); g.fill();
      g.fillStyle = INK;
      g.beginPath(); g.arc(ex + px, eyeY + 6 + py, 10, 0, Math.PI * 2); g.fill();
      // Upper half-lid cover
      g.fillStyle = skinBase;
      g.fillRect(ex - 34, eyeY - 34, 68, 30);
      g.strokeStyle = INK; g.lineWidth = 9;
      g.beginPath(); g.arc(ex, eyeY, 30, 0, Math.PI); g.stroke();
      g.beginPath(); g.moveTo(ex - 32, eyeY - 4); g.lineTo(ex + 32, eyeY - 4); g.stroke();
    } else if (mode === 'dash_closed') {
      g.strokeStyle = INK; g.lineWidth = 10;
      g.beginPath(); g.moveTo(ex - 26, eyeY + 4); g.lineTo(ex + 26, eyeY + 4); g.stroke();
    } else if (mode === 'empty_dot') {
      // Hollow / memory-erased eye design (Reference: Jerry f2203-2334)
      g.fillStyle = INK;
      g.beginPath(); g.arc(ex + px, eyeY + py, 12, 0, Math.PI * 2); g.fill();
    } else if (mode === 'squeezed_x') {
      // Affectionate squeezed-arc eyes (Reference: healed brother f2116-2130)
      g.strokeStyle = INK; g.lineWidth = 10;
      g.beginPath();
      g.arc(ex, eyeY + 12, 24, Math.PI * 1.15, Math.PI * 1.85);
      g.stroke();
    } else if (mode === 'squiggly') {
      g.strokeStyle = INK; g.lineWidth = 8;
      g.beginPath();
      g.arc(ex, eyeY, 22, 0, Math.PI * 2);
      g.stroke();
      g.beginPath();
      g.moveTo(ex - 12, eyeY); g.quadraticCurveTo(ex, eyeY - 12, ex + 12, eyeY);
      g.stroke();
    }
  }

  if (eyes === 'wink_left') {
    drawSingleEye(eyeLx, 'dash_closed');
    drawSingleEye(eyeRx, 'ring');
  } else {
    drawSingleEye(eyeLx, eyes);
    drawSingleEye(eyeRx, eyes);
  }

  // 8. Eyebrows (Main Emotion Actuator)
  g.strokeStyle = INK;
  g.lineWidth = 9;
  const by = eyeY - 52;
  if (brows === 'neutral') {
    g.beginPath();
    g.moveTo(eyeLx - 26, by); g.quadraticCurveTo(eyeLx, by - 10, eyeLx + 24, by);
    g.moveTo(eyeRx - 24, by); g.quadraticCurveTo(eyeRx, by - 10, eyeRx + 26, by);
    g.stroke();
  } else if (brows === 'worried' || brows === 'sad') {
    g.beginPath();
    g.moveTo(eyeLx - 28, by + 12); g.lineTo(eyeLx + 22, by - 12);
    g.moveTo(eyeRx - 22, by - 12); g.lineTo(eyeRx + 28, by + 12);
    g.stroke();
  } else if (brows === 'angry' || brows === 'resolute') {
    g.beginPath();
    g.moveTo(eyeLx - 28, by - 10); g.lineTo(eyeLx + 24, by + 12);
    g.moveTo(eyeRx - 24, by + 12); g.lineTo(eyeRx + 28, by - 10);
    g.stroke();
  } else if (brows === 'raised') {
    g.beginPath();
    g.moveTo(eyeLx - 24, by - 16); g.quadraticCurveTo(eyeLx, by - 32, eyeLx + 24, by - 16);
    g.moveTo(eyeRx - 24, by - 16); g.quadraticCurveTo(eyeRx, by - 32, eyeRx + 24, by - 16);
    g.stroke();
  }

  // 9. Minimalist Mouth
  const my = 72;
  g.strokeStyle = INK;
  g.fillStyle = INK;
  g.lineWidth = 9;
  if (mouth === 'dot') {
    g.beginPath(); g.arc(0, my, 8, 0, Math.PI * 2); g.fill();
  } else if (mouth === 'flat') {
    g.beginPath(); g.moveTo(-24, my); g.lineTo(24, my); g.stroke();
  } else if (mouth === 'smile') {
    g.beginPath(); g.arc(0, my - 18, 36, Math.PI * 0.18, Math.PI * 0.82); g.stroke();
  } else if (mouth === 'smirk') {
    g.beginPath(); g.moveTo(-22, my + 4); g.quadraticCurveTo(10, my + 6, 30, my - 10); g.stroke();
  } else if (mouth === 'frown') {
    g.beginPath(); g.arc(0, my + 28, 34, Math.PI * 1.18, Math.PI * 1.82); g.stroke();
  } else if (mouth === 'o_open') {
    g.beginPath(); g.ellipse(0, my + 6, 18, 26, 0, 0, Math.PI * 2); g.fill();
  } else if (mouth === 'wavy_anxious') {
    // Signature wavy anxiety/confusion mouth (Reference: f1306-1320, f2145-2150)
    g.beginPath();
    g.moveTo(-36, my + 4);
    g.quadraticCurveTo(-18, my - 14, 0, my + 4);
    g.quadraticCurveTo(18, my + 22, 36, my + 4);
    g.stroke();
  } else if (mouth === 'toothy_grin') {
    g.fillStyle = '#FFFFFF';
    g.beginPath();
    g.moveTo(-72, my - 14);
    g.quadraticCurveTo(0, my - 2, 72, my - 14);
    g.quadraticCurveTo(58, my + 54, 0, my + 56);
    g.quadraticCurveTo(-58, my + 54, -72, my - 14);
    g.closePath();
    g.fill();
    g.stroke();
    // Vertical teeth dividers
    g.lineWidth = 5;
    for (const tx of [-38, -14, 14, 38]) {
      g.beginPath(); g.moveTo(tx, my - 8); g.lineTo(tx, my + 42); g.stroke();
    }
  }

  // 10. Micro Acting Extras (Sweat Drop, Tear, Tremor Lines)
  if (extras.sweatDrop) {
    g.fillStyle = '#8CD3FF';
    g.strokeStyle = INK;
    g.lineWidth = 6;
    g.beginPath();
    g.moveTo(148, -68);
    g.quadraticCurveTo(174, -22, 148, -10);
    g.quadraticCurveTo(122, -22, 148, -68);
    g.closePath();
    g.fill(); g.stroke();
  }
  if (extras.tear) {
    g.fillStyle = '#9CE0FF';
    g.beginPath();
    g.ellipse(eyeRx + 8, eyeY + 46, 9, 14, 0.15, 0, Math.PI * 2);
    g.fill();
  }
  if (extras.tremorLines) {
    g.strokeStyle = INK;
    g.lineWidth = 7;
    g.beginPath();
    g.moveTo(-235, -45); g.quadraticCurveTo(-252, -10, -235, 25);
    g.moveTo(-260, -30); g.quadraticCurveTo(-274, -5, -260, 20);
    g.stroke();
  }

  g.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}
