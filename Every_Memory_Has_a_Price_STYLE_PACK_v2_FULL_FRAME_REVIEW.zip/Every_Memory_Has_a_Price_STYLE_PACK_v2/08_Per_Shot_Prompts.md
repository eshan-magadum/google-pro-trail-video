# 08 — PER-SHOT PROMPTS (24 scenes)
For each scene: **IMAGE PROMPT** (first frame / keyframe), **MOTION PROMPT** (image-to-video), **GRADE** (grade.sh preset + numbers), **TIMING**. Paste the *STYLE LOCK* from `07_Astra_Master_Prompts.md` before each image prompt if your generator forgets between shots. Generate at 9:16.


## S01 · Hook: hero at the memory counter, swing-pitch to the counter  (0.00–0.90 s · 0.9 s clip)
**IMAGE PROMPT**
> Vertical 9:16 night interior of a pawn-style memory shop: long wooden counter in steep wide-angle perspective, round-headed stick-figure boy (orange spiky hair, yellow vest with white stripe, tiny green frog badge) standing at the right looking worried, hooded figure with glowing amber eyes behind a translucent glass partition at far left, green pendant lamp glowing, teal wallpaper, amber-lit wooden door, brass cash register, one tiny glowing memory card on the counter, hard diagonal shadow across the counter, indigo shadows, strong vignette. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Brief push-in on the worried hero, then a fast eased swing: camera pitches down onto the counter as he slides out of frame right; his face ghosts for 3 frames; focus lands on the glowing card. 0.9 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 67.9, saturation ≈ 0.48, vignette corner÷centre ≈ 0.21, dominant colours #1f162c, #2f3453, #5d3942, #ba754b.
**TRANSITION OUT:** Camera swing onto the card (T1).


## S02 · Macro: glowing memory card, then pull-up  (0.90–1.80 s · 0.9 s clip)
**IMAGE PROMPT**
> Top-down macro close-up of a small glowing golden memory card (like a miniature photo cassette with a tiny sunny lake picture) lying on a pale glass tray set in a warm wooden counter, shallow depth of field, blurred brass cash register at top, soft gold glow from the card, cool white tray, warm wood, flat clean 2.5D stylised render. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera pushes in slowly while focus racks from soft to razor-sharp on the card; card glow pulses once. 0.7 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 103.2, saturation ≈ 0.35, vignette corner÷centre ≈ 0.26, dominant colours #7d5866, #a5a7b2, #b17a65, #4c3754.
**TRANSITION OUT:** Continuous pull-up into the stranger's room with a 0.3 s exposure fall (luma 130 -> 40).


## S03 · Hooded stranger + memory-cubby wall (slow pull-back drift)  (1.80–5.00 s · 3.2 s clip)
**IMAGE PROMPT**
> Vertical 9:16 dark shop interior: round-faced hooded figure with big toothy grin and glowing amber eyes behind a wooden counter, hood is navy-black with a thin pale-blue rim light, a wall of small cubby holes containing tiny glowing blue/pink/amber memory cards, filing drawers with gold label plates, amber-lit door at right, brass register on the counter, a pool of warm lamplight on the counter, deep indigo shadows, heavy vignette, slightly tilted camera. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Slow push-in toward the grinning figure with 1–2° lateral drift; grin widens slightly; eyes glow brighter at the end. 3.4 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 38.5, saturation ≈ 0.55, vignette corner÷centre ≈ 0.4, dominant colours #1b1835, #0f0d21, #322844, #6b4a58.
**TRANSITION OUT:** Glass pane drifts across; dissolve to alley (T3).


## S04 · Glass-pane dissolve into the alley  (5.00–5.60 s · 0.6 s clip)
**IMAGE PROMPT**
> Dark rainy alley at night, wet reflective paving tiles, purple-brick wall at left, glowing light-box poster with a shop logo, warm bokeh lights far down the alley, rain streaks, a faint translucent glass pane edge sweeping across the foreground. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> A translucent glass pane glides across the lens; interior dissolves into the rainy alley; rain streaks fade in first. 0.9 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 57.9, saturation ≈ 0.48, vignette corner÷centre ≈ 0.63, dominant colours #1a1530, #332b4b, #4b4a70, #704a51.
**TRANSITION OUT:** T3 glass sweep dissolve.


## S05 · Rainy alley dolly + skyline bokeh  (5.60–6.53 s · 0.9 s clip)
**IMAGE PROMPT**
> Vertical 9:16 rainy night alley in wide-angle, wet reflective tiled ground mirroring neon, brick wall left, glowing shop light-box poster right, vertical neon sign, warm orange and magenta bokeh at the vanishing point, rain streaks, indigo and electric-blue gradient, haze. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Smooth forward dolly down the alley, rain falling, reflections sliding on the wet ground. 0.8 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 68.2, saturation ≈ 0.57, vignette corner÷centre ≈ 0.61, dominant colours #1d1845, #1f2b80, #524a96, #4e355b.
**TRANSITION OUT:** 0.25 s window-glass dissolve (6.50–6.75 s): the alley is seen through rain-spotted glass while the lit extractor shop fades in behind it (luma 68→104). Not a cut.


## S06 · Extractor shop (seen through window glass), extraction flash  (6.53–8.67 s · 2.1 s clip)
**IMAGE PROMPT**
> Vertical 9:16 bright shop interior with lavender-pink glowing haze, teal wall with an arched yellow shop sign, teal-and-white checkerboard floor, a round-headed stick-figure customer sitting in a dentist-style chair with a metal dome helmet on their head, a bald round-headed assistant standing beside, large white pendant lamp blooming at the top, soft diffusion. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Slow pull-back; at ~8 s a small glowing card rises out of the helmet and the lamp/helmet bloom flashes lavender-white, then settles. 2.3 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `bright (haze) + extra bloom` — target luma ≈ 109.9, saturation ≈ 0.39, vignette corner÷centre ≈ 0.48, dominant colours #645387, #373e73, #90708c, #bb99a6.
**TRANSITION OUT:** ~0.2 s cross-dissolve (f259-264): lavender haze fades to indigo deli street.


## S07 · Deli street: landlord, bike crash  (8.67–13.20 s · 4.5 s clip)
**IMAGE PROMPT**
> Vertical 9:16 rainy night street, a deli with a red awning and a huge warm glowing shop window full of colourful goods, fire escape above, wet pavement reflections, round-headed stick-figure people on the steps and a child on a small bicycle, indigo and violet night with amber window glow, rain. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera starts on the landlord, trucks right along the lit shop window to the kid on the bike; the bike wobbles and crashes; rain keeps falling; then the camera begins tilting up. 4.5 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom (use PI/5.5 vignette)` — target luma ≈ 84.6, saturation ≈ 0.54, vignette corner÷centre ≈ 0.5, dominant colours #2c3486, #1e1b47, #5a559a, #efd7be.
**TRANSITION OUT:** Camera tilts up the wall (continuous into S08).


## S08 · Tilt up the giant wall + light shafts  (13.20–15.67 s · 2.5 s clip)
**IMAGE PROMPT**
> Vertical 9:16 dramatic upward view of a gigantic concrete city wall at dusk, tilted 15–20°, warm spotlights along the top casting white light shafts through violet haze, tiny stick-figure child and a fallen bicycle at the bottom of frame, indigo and lavender gradient sky. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera tilts upward along the wall with a slow Dutch roll; light shafts sweep; lens flare grows. 2.6 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 74.5, saturation ≈ 0.57, vignette corner÷centre ≈ 1.07, dominant colours #303483, #1c1c4e, #645b9e, #614262.
**TRANSITION OUT:** T4 top-down luminous wipe to the pool.


## S09 · Rich side: resort pool, lounger + butler  (15.67–18.67 s · 3.0 s clip)
**IMAGE PROMPT**
> Vertical 9:16 sunny luxury resort pool, turquoise water with bright caustic patterns, tall palm trees, pink flowering bushes, a stadium-like green hillside with floodlight tower under a deep blue sky, in the foreground a round-headed stick-figure wearing a huge straw hat and sunglasses on a lounger with a butler in a white jacket holding a tray, clean glossy 3D look, over-bright and cheerful. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Low camera at pool-edge level glides forward over the water and rises to reveal the lounger and butler. 2.9 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `bright` — target luma ≈ 157.6, saturation ≈ 0.4, vignette corner÷centre ≈ 0.92, dominant colours #b2a589, #84bed8, #ecd8af, #564932.
**TRANSITION OUT:** Cross-dissolve + WHITE BLOW-OUT (f557-566: near-white frame) into the Bahamas guy's window room.


## S10 · Bahamas guy: dome descends, odometer ticks, dome lifts  (18.67–21.60 s · 2.9 s clip)
**IMAGE PROMPT**
> Vertical 9:16 sunny interior with big window to sea, round-headed stick-figure in a floral Hawaiian shirt with snorkel mask and yellow snorkel, eyes closed in bliss, wearing a glowing copper memory-extractor dome on his head, golden mechanical odometer counter on a round gold tray in the foreground labelled BAHAMAS with rolling digits, radial white-to-cobalt halo glow, bright and slightly over-exposed. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> A copper dome descends on a tube onto the man's blissful head with a glowing halo; camera dollies in, then tilts down as the gold odometer rises and its digits roll and settle; the dome lifts away. 2.9 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `bright` — target luma ≈ 176.9, saturation ≈ 0.37, vignette corner÷centre ≈ 0.94, dominant colours #ebe9ee, #e3cda7, #8cbaec, #bb833e.
**TRANSITION OUT:** Pulls back to the couch (S11).


## S11 · Couch wide, then flamingo-pool water dissolve  (21.60–23.47 s · 1.9 s clip)
**IMAGE PROMPT**
> Vertical 9:16 modern poolside, a round-headed stick-figure lounging on a white couch beside a gold counter box, a pink flamingo float on turquoise water with bright caustics, blue sky, glossy over-bright 3D, camera slightly high. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera pulls back to a wide of the couch, dissolves to rippling pool water with a flamingo float, then vertical blurred light streaks sweep across and dissolve to the next scene. 2.1 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `bright` — target luma ≈ 176.5, saturation ≈ 0.41, vignette corner÷centre ≈ 0.97, dominant colours #e4cfa1, #4fcdc1, #7f96ed, #d5deed.
**TRANSITION OUT:** CORRECTION: VERTICAL BLURRED LIGHT STREAKS (blinds/fog-column look) sweep over the water f705-720 and dissolve into the dusk bench; bench figures ghost through at f716-720.


## S12 · Poor side: bench push-in, photos  (23.47–27.60 s · 4.1 s clip)
**IMAGE PROMPT**
> Vertical 9:16 dusk street bench scene: three elderly round-headed stick-figure people sitting in a row holding old framed photos, curly-haired woman and bald man with round glasses, blank gentle expressions, blue chain-link fence behind, red advertisement banner on the bench with white lettering, cracked concrete floor, thick black outlines, cold violet-blue light with warm skin tones. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Tiny far-wide bench scene pushes in steadily to a medium shot; elders blink and smile blankly; the woman lifts her photo; a round brass dial ring grows over the frame. 4.1 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom (cool)` — target luma ≈ 96.4, saturation ≈ 0.49, vignette corner÷centre ≈ 0.73, dominant colours #854e5f, #323372, #5e67a9, #80a5cf.
**TRANSITION OUT:** SHAPE MATCH-CUT (f825-836): a big round brass dial ring grows over the bench scene and becomes the HAPPINESS gauge (photo frame -> round dial).


## S13 · Happiness gauge: pull-back, grin, gold flood  (27.60–31.67 s · 4.1 s clip)
**IMAGE PROMPT**
> Vertical 9:16 close-up of a brass pocket-watch style gauge on a small wooden base labelled HAPPINESS with a coloured arc, a sun icon at the right and a rain-cloud icon at left, a rolling price counter, a metal bucket of tiny memory cards at left, behind it a dark hooded figure with a huge toothy grin and glowing amber eyes, dark cubby wall, gold glow from the gauge, indigo shadows. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera pulls back from a big silver gauge as sparks glint, the stranger's smile grows to a full grin, the needle climbs to the sun and the dial floods gold, eyes glowing. 4.1 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 79.2, saturation ≈ 0.47, vignette corner÷centre ≈ 0.3, dominant colours #0f0e24, #382c46, #6b515b, #b68a55.
**TRANSITION OUT:** CIRCULAR IRIS-RING dissolve (f946-956): the gold gauge ring fades out over the night street.


## S14 · Night street: rent, brother collapses, frog on the ground  (31.67–36.00 s · 4.3 s clip)
**IMAGE PROMPT**
> Vertical 9:16 low Dutch-angle night street with strings of small pennant lights, tall apartment buildings with glowing windows, a fire hydrant, wet ground reflecting everything like a mirror, round-headed stick-figure boy with orange hair and yellow vest next to a small kid in a green cap holding a green frog, deep cobalt and indigo palette, rain mist. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Low tilted camera; a frog hops onto a bouncing kid's cap, leaps off as the kid collapses; camera rolls and tilts down to the frog on the wet ground, defocuses, and dissolves to the hospital with the frog staying in place. 4.3 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 54.6, saturation ≈ 0.67, vignette corner÷centre ≈ 0.43, dominant colours #162175, #151541, #383991, #523859.
**TRANSITION OUT:** FROG MATCH-DISSOLVE (f1078-1092): the frog holds its screen position while the street dissolves into the hospital, where it becomes the bed-rail frog.


## S15 · Hospital bedside: bedtime story, polaroid grows  (36.00–39.17 s · 3.2 s clip)
**IMAGE PROMPT**
> Vertical 9:16 dim hospital room at night, a sick small round-headed stick-figure child in a bed with a green frog plush, an older boy with orange spiky hair and a yellow vest sitting beside the bed with eyes closed and a gentle smile, small warm bedside lamp, red blanket, deep navy-blue background, soft lamplight on faces. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Slow push-in; camera drifts past Jerry's face to a polaroid that grows to fill the frame with a glare streak; its white border slides away to reveal the full-frame lake. 3.2 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 79.8, saturation ≈ 0.55, vignette corner÷centre ≈ 0.29, dominant colours #192068, #1a0e2a, #51549c, #a18d9f.
**TRANSITION OUT:** Polaroid grows to full-frame and its border slides off, becoming the lake (f1162-1188).


## S16 · Polaroid becomes the golden-hour lake memory (frog leap)  (39.17–42.40 s · 3.2 s clip)
**IMAGE PROMPT**
> Vertical 9:16 golden-hour lake scene seen as a nostalgic memory, wooden dock, two round-headed stick-figure boys (one orange spiky hair, one smaller) fishing with a net, a green frog leaping out of the net, lily pads and reeds in the foreground, sun low at the horizon with glowing reflections on blue water, tree line in the distance, warm gold and cool teal-blue palette. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Gentle parallax drift; a frog leaps from a lily pad into a net in an arc with spray, lands on the dock; the whole picture shrinks back into a polaroid and dims. 3.2 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `warm/bright` — target luma ≈ 123.5, saturation ≈ 0.47, vignette corner÷centre ≈ 0.66, dominant colours #1d4e74, #407fab, #82a3be, #e2d3bb.
**TRANSITION OUT:** The scene is RE-FRAMED INSIDE a polaroid (frame shrinks back, border returns f1266-1272), dims to dark blue and becomes the polaroid clipped to the IV stand (reverse match-cut).


## S17 · IV-pole price gauge + the desk sale (lamp-lit face)  (42.40–47.07 s · 4.7 s clip)
**IMAGE PROMPT**
> Vertical 9:16 very dark scene: a worried round-headed stick-figure boy with orange spiky hair at a desk lit from below by a small lamp so his face glows peach-white, a dark hooded silhouette in the left foreground with only faint eyes catching light, a thin glass partition with a pale reflection, a tiny glowing golden memory card on the desk, deep indigo-black surroundings, strong vignette. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Tilt-up on the IV pole as the hero's face swings in; dissolve to a lamp-lit desk where his face glows and a tiny card sparkles; a tear rolls. 4.7 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 45.9, saturation ≈ 0.64, vignette corner÷centre ≈ 0.27, dominant colours #0c0b20, #16194a, #273279, #beb9e5.
**TRANSITION OUT:** Face-ghost dissolve (f1412-1418) into the birthday-card macro.


## S18 · Birthday card macro, pull-back, OPERATING sign goes red  (47.07–50.00 s · 2.9 s clip)
**IMAGE PROMPT**
> Vertical 9:16 clinical teal corridor with a checkerboard floor, a pale door with a small sign that reads OPERATING glowing red, a round-headed stick-figure boy with orange hair and a yellow vest standing with a flat blank expression beside a small olive-green gauge box on a pole holding a colourful birthday card, bright cold fluorescent light. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Macro on the birthday card, pull back as a ball-hand swings in and Jerry follows; his eyes close in resignation; the OPERATING sign flicks red and bathes the corridor in red. 2.9 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `bright, teal` — target luma ≈ 119.1, saturation ≈ 0.39, vignette corner÷centre ≈ 0.75, dominant colours #212d32, #79a3a7, #40656f, #a78569.
**TRANSITION OUT:** Orange/blue overlay cross-dissolve (f1498-1512) into the 'WE BUY SUMMERS' scene; the corridor figure ghosts over it.


## S19 · WE BUY SUMMERS: Jerry sells whole years (face colour pulses)  (50.00–54.67 s · 4.7 s clip)
**IMAGE PROMPT**
> Vertical 9:16 medium low-angle shot of a round-headed stick-figure boy with orange spiky hair and yellow vest holding a small box at his waist, standing against a teal wall under a slanted mustard-orange sign reading WE BUY SUMMERS in maroon slab-serif capitals with a script line 'cash today, any grade', orange spotlights, his face half cold lavender-white and half warm orange as if a light is pulsing, a blue-white halo outline around his head, tired half-lidded eyes, dark navy surroundings, strong vignette. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Near-static camera; his skin tone pulses cold lavender <-> warm orange about every 1.4 s; a blue-white halo grows around his head; his eyes close and his head droops back. 4.7 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 73.1, saturation ≈ 0.59, vignette corner÷centre ≈ 0.46, dominant colours #1e1b38, #1d3f69, #804930, #5d5587.
**TRANSITION OUT:** Dissolve (f1636-1648): his face ghost + red/orange warmth fade into the cold-blue sickroom.


## S20 · Brother worse + the MEMORY SAVINGS ledger  (54.67–58.17 s · 3.5 s clip)
**IMAGE PROMPT**
> Vertical 9:16 top-down view of an open ledger book titled MEMORY SAVINGS with rows of years, each with a red SOLD stamp, one row highlighted gold with a star, pale paper, soft shadows; second image: dim blue hospital bedroom, a frail round-headed child in bed, small lamp. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Dissolve from the bed to the ledger, SOLD stamps slam in one after another; camera pushes down to the gold star row. 4 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 95.0, saturation ≈ 0.45, vignette corner÷centre ≈ 0.34, dominant colours #140e28, #d7c6c4, #191e5c, #ad9fba.
**TRANSITION OUT:** Ledger page dissolves UP into the shop scene (f1737-1748).


## S21 · Shop: stranger's hood is pulled back, warning + resolve  (58.17–63.33 s · 5.2 s clip)
**IMAGE PROMPT**
> Vertical 9:16 close-up of a pale round-headed hooded shopkeeper with worried raised brows and a small open mouth, black surroundings, a glowing gold arched sign reading MEMORIES bought & sold behind him, a round-headed boy with orange hair and a metal dome helmet on his head at the left edge, dark navy-black palette with warm gold accents. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Hood slides back to a round worried face; camera pushes in then pulls back to the two-shot; the hero's expression hardens; the dome lamp lowers onto his head. 5.2 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom` — target luma ≈ 68.0, saturation ≈ 0.52, vignette corner÷centre ≈ 0.27, dominant colours #120d23, #3f2b46, #f0e6de, #6c6cae.
**TRANSITION OUT:** The overhead dome lamp descends onto Jerry's head (f1902-1920) - the lamp IS the extractor.


## S22 · Dome lowers, tube follow, pixel-block mosaic, gold blow-out  (63.33–65.93 s · 2.6 s clip)
**IMAGE PROMPT**
> Vertical 9:16 abstract dark navy void with drifting blue pixel blocks, a small rectangular memory card glowing intensely warm gold at the centre, a transparent tube coming from below, faint outline of letters, deep blue and gold only. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera follows a tube upward at speed into darkness; the card brightens and swells until it fills the screen with gold light. 1.6 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom → gold flash` — target luma ≈ 90.2, saturation ≈ 0.47, vignette corner÷centre ≈ 0.36, dominant colours #14112a, #43365b, #d9bc8d, #9b7b65.
**TRANSITION OUT:** Gold blow-out dissolves (f1976-1992) into the morning ward with a blue-white light smear.


## S23 · Cured brother wakes, hair springs up (warm, bokeh)  (65.93–71.20 s · 5.3 s clip)
**IMAGE PROMPT**
> Vertical 9:16 bright cosy hospital morning, a small round-headed stick-figure child with orange spiky hair sitting up in bed with a big happy open-mouth smile holding a polaroid, a green frog plush on the bed rail, red blanket, cream-gold light, extremely blurred background of windows and colourful get-well drawings, royal-blue edges to the frame. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Camera pushes in as the small boy wakes, sits up and his hair springs into spikes; he beams, poses cured, asks excitedly, then leans in with a squeezed-eye smile; his face dissolves into the hero's. 7 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `warm` — target luma ≈ 139.9, saturation ≈ 0.46, vignette corner÷centre ≈ 0.46, dominant colours #e3c192, #9d8a92, #353f8b, #871b1f.
**TRANSITION OUT:** FACE-MATCH CROSS-DISSOLVE (f2137-2143): the brother's face ghosts onto Jerry's face at the same screen position as warm cream flips to cold cobalt.


## S24 · Cold flip: Jerry's eyes go hollow; brother's hurt face; ending hold  (71.20–77.80 s · 6.6 s clip)
**IMAGE PROMPT**
> Vertical 9:16 close-up of a pale round-headed stick-figure man with orange hair bathed in cold cobalt-blue light, blank slightly confused face, a much smaller warm-lit child with orange hair in bed at the left, heavily blurred window bokeh behind, blue and warm-gold contrast, emotional and quiet. Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism.

**MOTION PROMPT**
> Cold-blue close-up; the hero's eyes simplify to dots; camera drifts so the small warm brother appears at left with a polaroid; his smile falls into a hurt frown while the hero stares past him; slow push-in then total hold. 6.6 s. Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `gloom (cold cobalt)` — target luma ≈ 86.8, saturation ≈ 0.63, vignette corner÷centre ≈ 0.38, dominant colours #1e319b, #17173b, #857c9c, #debe95.
**TRANSITION OUT:** No exit: the final shot holds with the brother's hurt face (motion ~0).
