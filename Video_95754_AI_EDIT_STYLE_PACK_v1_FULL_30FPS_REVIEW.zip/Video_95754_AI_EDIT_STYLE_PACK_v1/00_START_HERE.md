# VIDEO-95754 — AI EDIT STYLE PACK (full frame-by-frame analysis)

This pack analyses `Video-95754.mp4`, an Instagram Reel where the creator gave only a raw talking-head recording and an AI edited the rest: split-screens, word-by-word captions, animated explainer graphics in several illustration styles, punch-ins, and the CTA. Use it to get **the same level of editing on a new raw video**.

| Spec | Value |
|---|---|
| Resolution / aspect | 720 × 1280, 9:16 vertical |
| Frame rate | 29.97 fps (2997/100), constant. Usually called "30 fps". |
| Frames | **1,093** (36.47 s) — **every frame was extracted, measured and viewed** |
| Codec | H.264 video ~1.07 Mbps, AAC 48 kHz stereo 53 kbps |
| Loudness | −14.1 LUFS integrated, LRA 1.6 LU, peak −0.9 dBFS |
| Narration | 130 words in 36.5 s ≈ **214 wpm** (fast, pauses cut out) |
| Structure | **18 shots**, 17 cuts, average shot length **2.03 s** |
| Captions | **72 caption chunks**, 1–3 words each (mean 1.8 words, median 14 frames ≈ 0.47 s) |

## How to use this pack with an AI editor
1. Upload **this ZIP + your raw talking-head video** (and your script if you have one).
2. Paste the prompt from **`08_AI_Editor_Master_Prompt.md`**. It tells the AI to read the pack, plan a new EDL from your script, and build it.
3. If your AI can write code (Remotion / After Effects scripts / HTML canvas / Python-MoviePy), have it use **`edit_decision_list.json`** as the template for its own JSON plan, and **`03_Animation_Motion_Library.md`** for the exact easing and frame timings.
4. Check the result with the QA checklist at the end of `08`.

## Read in this order
| File | What it covers |
|---|---|
| `01_Edit_DNA_Style_Bible.md` | **The core rules.** The 3 layouts, the 4 illustration worlds, the pacing law, the 15 signature moves |
| `02_Shot_By_Shot_Breakdown.md` | All 18 shots: frames, layout, what's on screen, every animation with frame numbers, caption sync, measured colours |
| `03_Animation_Motion_Library.md` | 30+ reusable animation primitives (typewriter, strike-through, iceberg dive, stamp press, card flip, confetti, etc.) with frame counts and easing curves |
| `04_Captions_and_Typography.md` | Caption chip spec (font, size, box, position per layout), chunking rules, the serif CTA keyword, in-graphic fonts |
| `05_Script_to_Visual_Method.md` | **How each spoken line was turned into a visual metaphor**, so the AI can do the same for a NEW script |
| `06_Color_Lighting_Illustration_Style.md` | Measured palettes for every shot, the illustration style for each world, lighting, glow, texture |
| `07_Audio_Pacing_Rhythm.md` | Narration speed, jump-cut density, the beat grid (cuts on words), audio measurements |
| `08_AI_Editor_Master_Prompt.md` | **Copy-paste prompts** (master brief, per-shot generation prompts, negatives, QA checklist) |
| `09_Frame_Accurate_Event_Log.md` | Raw notes from viewing all 1,093 frames in order, by frame number |
| `edit_decision_list.json` | Machine-readable EDL of the whole reference edit: shots, layers, keyframes, captions |
| `data/` | Per-frame metrics for all 1,093 frames (CSV), audio per frame, word-level transcript, caption timing CSV, scene JSON, timeline chart |
| `reference_frames/` | 54 full-resolution frames (start/mid/end of every shot) |
| `transitions/` | 17 strips showing ±6 frames around every cut (the cut frame is marked red) |
| `sheets/all_1093_frames_in_order/` | 28 contact sheets, 40 frames each, every frame labelled with frame number and time |
| `analysis_scripts/` | The Python used, so the analysis can be re-run on any video |

## How the analysis was done
* All 1,093 frames were extracted with ffmpeg (`-vsync 0`, no frames dropped or duplicated).
* **Every frame was viewed in order** on 28 labelled contact sheets (40 frames per sheet, 150 × 267 px tiles), plus ~20 frames at full 720 × 1280 to check details: fonts, UI, emoji style, textures. Notes were written while viewing (`09_…`).
* **Every frame was also measured by code** (OpenCV): brightness, contrast, saturation, hue, warmth, edge density, sharpness, vignette, frame difference, histogram correlation, Farnebäck optical flow (magnitude, dx, dy, zoom index). See `data/per_frame_metrics_all_frames.csv`.
* Cuts: the code found 16 cut candidates and the visual review found 17. The extra cut at f122 is a re-framed cut of the same document, so the histogram barely changes.
* Narration was transcribed with Whisper (small) to get word timestamps. Caption chunks and their frames come from the visual review, not OCR.
* Audio was **measured, not listened to** (loudness, spectrum, per-frame RMS). Whether there is a music bed is uncertain (see `07`).
* Colour hex values are k-means cluster centres from real frames.
* Limits: tiles were 150 px wide, so very small UI text was read at full resolution only where it mattered. Timings are ±1 frame.

## Script (from audio, matched to on-screen captions)
> Anthropic engineer just built the most powerful prompt that I have ever seen, but nobody is using it. When prompting, most of us just describe the task. Well, in fact, we should be using the deeper meaning behind the prompt. For example, instead of saying to Claude "fix this bug", say to Claude "keep this app bug-free". Paste this prompt in before any task. And that's why this Anthropic skill is so powerful. Just paste it in before any task, and it tells you what a top expert would say — things that you would never have thought about. And it doesn't just give you advice. It actually reviews the whole prompt, so you're getting the expert version of it. Want the prompt? Comment "deeper" and I'll send it over.
