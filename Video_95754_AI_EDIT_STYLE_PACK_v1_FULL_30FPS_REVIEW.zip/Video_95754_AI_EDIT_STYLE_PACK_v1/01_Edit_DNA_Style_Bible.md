# 01 — EDIT DNA / MASTER STYLE BIBLE

## 1. What kind of edit this is
A **fast faceless-explainer edit wrapped around a talking head**. The creator sits at a desk with a podcast mic in an RGB-lit room, purple and blue. The AI editor:
- cuts out every pause, so speech runs at about 214 wpm with no dead air,
- covers **54% of the runtime with full-screen animated graphics** and another **33% with split-screen** (graphic on top, speaker below). The plain speaker is full-screen only **12.5%** of the time, used for emphasis beats and the CTA,
- turns almost every sentence into a **concrete visual metaphor** (iceberg = hidden depth, fly-swatter = fixing symptoms, door = access to an expert, light bulbs = ideas, magnifier = review, stamp press = apply to every task),
- adds **word-synced captions, 1–3 words at a time**, in a grey chip,
- makes every graphic **move all the time**. Nothing is ever a still frame. Each caption change gets a micro-event, and each sentence gets a major animation beat.

## 2. The three layouts (measured)
| Layout | Share | Frames | Geometry |
|---|---|---|---|
| **SPLIT** (graphic top / speaker bottom) | 33.4% | 365 | Hard seam at **y = 640 px**, exactly half. Top 720 × 640 = graphic. Bottom 720 × 640 = speaker crop (face centred, top of head ~y 690, mic boom enters from right). No border, no gap, no rounded corners at the seam. **Caption chip sits ON the seam**, centred at y≈632. |
| **FULL_GFX** (full-screen graphic, speaker hidden) | 54.1% | 591 | Graphic fills 720 × 1280. Main subject sits in the **upper 2/3** (centre ~y 450–550). Caption chip lower-middle, **y≈850**. Bottom ~30% is "floor" (desk, water depth, stage floor, empty sunburst), which leaves room for the caption and the Instagram UI. |
| **FULL_SPEAKER** (punch-in) | 12.5% | 137 | Speaker scaled about **1.7–1.8×** compared with the split crop: face fills the width, eyes at ~y 330–400, chest and cross necklace visible, mic at bottom-right. Caption chip **y≈850** over the chest. Used only 3 times: after a big graphic run ("for example"), before the "advice" pivot, and the CTA. |

**Layout sequence:** SPLIT → GFX → GFX → SPLIT → GFX → SPEAKER → GFX → SPLIT → GFX → SPLIT → GFX → GFX → SPLIT → SPEAKER → SPLIT → GFX → GFX → SPEAKER.
Rule: **never two SPLITs in a row, never two SPEAKER shots in a row.** Full-screen graphics can run 2 in a row when the story continues (doc → doc zoom-out, door → professor, expert card → prompt sheet). SPLIT is used when the speaker's face and emotion matter (hook, "most of us", "paste this", "things you'd never think of", "it reviews").

## 3. Four illustration worlds (one video, deliberately mixed)
The editor does **not** keep one art style. It picks a world for each metaphor, and keeps each world consistent inside itself:

| World | Shots | Look |
|---|---|---|
| **A. Clean product UI** | S02, S03, S04 (chat box), S08, S10 | Real-looking Claude interface: white cards, soft shadows, rounded 16–24 px corners, Inter/SF-style sans, orange `#E8743B`-ish Claude asterisk and send button, soft white or peach glow backgrounds, faint grid, dotted motion paths. Dark variant for the document (S02/S03: near-black `#100f0b`, serif body text, lavender quote rule). |
| **B. Soft 3D / glossy infographic** | S04/S05 iceberg | Low-poly faceted iceberg with thin white facet lines, cyan water with caustic ripples, navy depth gradient, **Microsoft Fluent 3D emoji** as icons (scientist, file cabinet, toolbox, check box), bold navy sans labels, warm internal glow. |
| **C. Flat retro cartoon, thick outline** | S07, S09, S11, S12, S15, S16, S17 | Thick black outlines (5–8 px at 720 w), flat fills with one soft shading tone, cream/beige wallpaper with a faint diagonal-dash pattern, rust/orange desk band, warm palette (orange `#f67644`, rust `#9c440b`, cream `#f7e8cd`). Bold *italic serif* display type for in-world text ("be-ambitious", "Reproduce it first.", "Why is checkout so slow?", "Expert version", "The Prompt"). The theatre (S11/S12) uses a purple velvet curtain and wood stage. The review (S15) uses a green cutting mat. The reward (S16/S17) uses a royal-blue sunburst. |
| **D. Moody night illustration** | S13 bulbs | Navy night sky with dot stars, hanging Edison bulbs, soft searchlight cone. The whole scene warms to amber as the bulbs light. |

What ties them together: the **Claude asterisk** keeps coming back (send button, lectern medallion, stamp head, card icons), **orange is the accent in every world**, all graphics are centred and symmetrical, and the caption chip never changes style.

## 4. Pacing law (measured)
- Average shot **2.03 s** (median 1.94 s). Shortest 0.27 s (S17), longest 4.1 s (S05, S07). Long shots are only allowed when there is **continuous animation with a new event every 10–15 frames**.
- Caption chunk changes every **15 frames on average (0.5 s)**.
- **A visible change on screen at least every 0.5 s.** It can be a caption swap, a character typed, an icon revealed, a pulse ring, or a camera drift.
- **A major animation beat every 1–1.5 s** (door opens, swatter slams, card flips, bulb cascade, stamp hits, seal pops).
- **Every cut lands on a word onset.** The first word of a new sentence or clause starts on the first frame of the new shot (see `07`). Cuts never land mid-word.
- Graphics are **never static**. Even "hold" moments carry a slow 2–5% push-in, a float/bob, a rotating sunburst, drifting particles, or blinking LEDs.

## 5. The 15 signature moves (what makes it look like this)
1. **Hook = source card + face.** Shot 1 is SPLIT, with a credibility object (an Anthropic-tagged image card with a source pill) above the speaker and the first caption word "Anthropic". The speaker shows within 0 ms.
2. **Show the actual artifact early.** By 1.8 s, the real prompt text fills the screen as a document. Then the camera **pulls out** to show where it came from and **draws a highlight box** around it.
3. **Typewriter UI** whenever the script quotes something a user would type ("Make a slide deck for our Q3 review.", "fix this bug", "keep this app bug free"). About 1 character per 1.5 frames, with a blinking caret.
4. **Literal metaphor illustration** for every abstract idea (see `05`).
5. **Camera moves inside graphics.** The iceberg tilts down below the waterline. The door gets a push-in. The magnifier pans across the card. The document zooms out.
6. **Staggered reveals synced to words.** Items in a list appear one per word group, ~12–13 frames apart (iceberg layers), or ~5 frames apart (checklist rows).
7. **Grey → colour activation.** Icons start as 30% grey silhouettes and "light up" (colour + pop + glow ring) when mentioned.
8. **Pulse rings.** A thin expanding circle (peach, gold, mint or orange) marks every impact or activation: paste, stamp, insert, seal, bulb lighting.
9. **Strike-through then rewrite.** A bad prompt gets an animated red strike-through, is deleted, then the good prompt is typed and highlighted green.
10. **Cause → effect payoff.** Swatting causes cracks and more bugs (bad). Typing "bug free" sends out a shockwave that heals the phone and drops the swatter (good). The metaphor resolves on screen.
11. **Power-up climax** on hype words ("so powerful"): LEDs fill one by one, the gauge needle swings into the red, the machine shakes with electric zig-zags, and sunburst rays fade in.
12. **Speech bubble character** for "what an expert would say": a cartoon professor in a spotlight with a pop-in bubble holding the expert's actual line.
13. **3D card flip** from the problem ("Why is checkout so slow?") to the solution ("Expert version" checklist). Then a **verified seal stamp + confetti** as the reward.
14. **Punch-in speaker shots** as breathers and emphasis. Face fills the frame, with expressive gestures (air-quotes, pointing, eye-rolls).
15. **CTA keyword graphic.** A huge white serif “DEEPER" with a drop shadow sits under the normal caption, synced to the speaker's air-quote gesture, and holds to the last frame. No end card, so the video loops cleanly.

## 6. Speaker treatment
- Raw footage is shown **unchanged in colour**: warm skin, magenta/purple/blue RGB background, mean luma ~82, saturation ~122. No heavy grade, no blur, no frame or border.
- In SPLIT the speaker sits at the same scale every time (a consistent crop). FULL_SPEAKER shots are the same 1.7–1.8× punch-in each time, with a slight further push in S18.
- Speaker gestures are **chosen to match graphics**: hands pushing down on "paste in" (S08), finger to temple on "reviews" (S15), air-quotes on “DEEPER" (S18). When editing a new video, prefer SPLIT/SPEAKER for moments where the raw footage has a strong gesture.

## 7. What is NOT in this edit (avoid these)
- No transitions effects between shots (no whip pans, no glitch, no zoom transitions, no dissolves). **All 17 cuts are hard cuts.** All the motion lives *inside* shots.
- No B-roll stock footage, no AI-generated photoreal video. Everything is designed 2D/2.5D motion graphics or real UI.
- No emoji spam in captions, no colour-highlighted caption words, no bouncing caption animation. The caption chip only swaps text.
- No progress bar, no logo bug, no end card, no music-video beat flashes.
- No speaker colour grading, background removal, or zoom pulses on the speaker.
