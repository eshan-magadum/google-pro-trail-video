# Starter Code — True 2.5D Hybrid Code Video Engine

This folder contains a minimal, self-contained **Three.js (3D Diorama) + Canvas2D (2D Cel Characters & Overlays)** rendering engine built directly from our frame-by-frame reverse-engineering of *Every Memory Has a Price*.

## Architecture
- `engine/hybrid_scene_base.js` — `Hybrid25DStage`: 3D wide-angle camera (`PerspectiveCamera`), palette lighting presets (`gloom_indigo`, `warm_honey`, `cold_cobalt`, `red_operating`), matte-wet reflection decal helper (zero clearcoat specular dots), z-buffered 2D character billboard mounting, high-threshold `UnrealBloomPass` (`0.89`), and 2D rain/vignette/caption HUD canvas.
- `engine/cel_character_rig.js` — Parameterized 2D cel character generator supporting the full reference emotion state machine (`ring`, `wide_ring`, `half_lid`, `dash_closed`, `wink_left`, `empty_dot`, `squeezed_x`, `squiggly`, spiky vs limp hair, wavy anxious mouth, sweat drop, tear, memory-drain halo).
- `engine/procedural_textures.js` — 100% procedural Canvas2D PBR textures (brick+bump, wet concrete slabs, glowing storefront signs, memory cubby walls).
- `engine/camera_transitions.js` — Easing curves and all 5 zero-hard-cut transition helpers (`evalWhipPitch`, `evalBlowOutFlash`, `evalSeamWipe`, `evalLightPulseCycle`, `drawPixelMosaicOverlay`).
- `scene_demo.js` — Working 5-second (150-frame) demo showing a rainy storefront with 3D lighting, 3D foreground rail occlusion, live blinking/alarmed 2D cel character, eased camera dolly, gold blow-out, and synced captions.
- `render_frames.mjs` — Headless Chromium + SwiftShader WebGL2 frame renderer (`--preview` or full `--frames=N` MP4).
- `grade_and_finish.sh` — **RGB-safe (`format=gbrp`)** FFmpeg color-grade + halation bloom + `-14.0 LUFS` audio mastering script.
- `verify_video.py` — Automated QA verifier checking resolution, 30 fps, zero hard cuts, lifted indigo shadows, saturation, vignette, freeze hold, and loudness.

## Quick Start
```bash
npm install
# 1. Render a single preview PNG (fast)
node render_frames.mjs --preview --frame=15 --w=720 --h=1280 --out=out/preview.png

# 2. Render full 30-FPS sequence to raw MP4
node render_frames.mjs --frames=150 --fps=30 --w=720 --h=1280 --out=out/raw.mp4

# 3. Apply RGB-safe gloom grade + optional audio mastering
chmod +x grade_and_finish.sh
./grade_and_finish.sh out/raw.mp4 out/final.mp4 gloom

# 4. Run automated QA checks
python3 verify_video.py out/final.mp4 --mode gloom
```
