# 08 — Transcript-to-Video AI Production Playbook

Follow this exact end-to-end checklist whenever a user hands you **a script, voiceover transcript, or story concept** (with or without `Every Memory Has a Price.mp4`) and asks you to plan and build a complete 2.5D video in this style using code.

---

## Step 1: Parse the User's Transcript & Lock Runtime
1. Count total spoken words `W` in the user's transcript.
2. If the user provides an audio narration track (`.wav` / `.mp3`), measure exact duration `D` and extract word-level timestamps (or align chunks manually at `30 fps`).
3. If generating timing from text only, calculate target spoken duration:
   - `D_spoken = W / 2.85` seconds (matching the reference's `2.83 wps` brisk storytelling cadence).
   - Add **`+1.00 s` (`30 frames`)** at the end for the signature motionless emotional freeze hold!
   - Total frames = `round((D_spoken + 1.0) * 30)`.
4. Fill out `templates/caption_timeline_template.csv` chunking every spoken word into **1–2 word chunks** (median `10 frames = 0.33 s`). Mark `"punch"` on emotional twist words — **every punch word must trigger a visual event** (light cue, expression switch, prop motion, or transition)!

---

## Step 2: Map the Transcript to the 8-Act Emotional & Color Arc
Fill out `templates/project_plan_template.md`:
* Divide the transcript into **scenes averaging `2.5–3.5 s`** during Hook/World/Contrast/Mechanic/Escalation, and **`4.5–6.5 s`** on the Climax and Twist holds.
* Assign each scene one of the **4 core palette presets** (`gloom_indigo`, `warm_honey`, `cold_cobalt`, `red_operating`) — plus optional high-key daylight (`rich_cyan`) if the script has a wealth/contrast beat.
* Identify **at least 2–3 Light-as-Plot-Signal cues** (glowing prop pulse, flickering sign, crimson alert bleed, gold blow-out climax, or instant 6-frame warm->cold twist flip).
* Identify **1 recurring symbolic motif** (like the green frog badge / cap / plush / lake in the reference) that visually ties Act 1 to the final twist!

---

## Step 3: Build the Mandatory 3D-vs-2D Layer Plan
Fill out `templates/3d_2d_layer_matrix_template.csv` for **every scene** using `references/02_3D_vs_2D_Layer_Architecture.md`:
1. **3D Background Set:** List exact Three.js architectural geometry (`BoxGeometry`, `PlaneGeometry`, `CylinderGeometry`), procedural textures (`brick`, `stucco`, `wet concrete`, `cubby wall`, `wood`, `tile`), and `FogExp2`.
2. **3D Lighting & Reflections:** Specify `HemisphereLight`, shadow-casting `DirectionalLight`, localized warm `PointLight`s, and matte-wet `addWetReflectionDecal()` planes (zero clearcoat!).
3. **3D Foreground Occluders:** Include at least 1 foreground 3D occluder in 50%+ of scenes (railing, doorway, glass pane, bedpost, counter rim) so camera movement produces unmistakable 2.5D depth.
4. **2D Cel Characters & Hero Props:** Specify each character's billboard Z-depth, tint hex (`< 0.88` bloom threshold), ground contact shadow, and frame-by-frame emotion states (`eyes`, `brows`, `mouth`, `hairState`, `extras`).
5. **2D Particles & HUD Overlays:** Specify rain streaks, dust sparkles, drain halo, Polaroid/ledger print overlays, radial vignette strength, blow-out flash windows, and synced 1–2 word captions.
6. **DOF / Blur Profile:** Choose explicitly for each scene:
   - `extreme_macro` (blurred 3D background + razor-sharp tiny hero prop)
   - `shallow_portrait` (blurred distant 3D wall + razor-sharp 2D actors)
   - `rack_focus_transition` (background blurs out over persistent sharp foreground prop)
   - `crisp_deep_focus` (full sharp tableau for wide streets / stark contrast)

---

## Step 4: Design the Shot List & Zero-Hard-Cut Transitions
Fill out `templates/shot_list_template.csv`:
* Choose camera vertical FOV (`68–76°` wide establishing vs `48–56°` macro/intimate) and smooth eased motion curve (`easeInOutCubic` or `easeInOutSine`) — **zero handheld shake**.
* Connect **every single scene boundary** with one of the 5 approved zero-hard-cut transition families from `references/04_Camera_Motion_and_24_Transitions.md`:
  - Camera-led continuous swing / pull-up / tilt-up
  - Persistent object or circular shape match-cut
  - Face-position match cross-dissolve (`6–12 f`)
  - Light-led gold/white blow-out or warm↔cold flip
  - Physical 3D glass pull-through or downward caustic refraction wipe

---

## Step 5: Code & Visually Verify Keyframes Before Full Render
1. Copy `starter_code/` into the project directory and run `npm install`.
2. Build modular scene builders (`scenes/s01.js`, `scenes/s02.js`, ...) sharing `Hybrid25DStage`, `cel_character_rig.js`, `procedural_textures.js`, and `camera_transitions.js`.
3. **Fast Keyframe Gate (Saves Massive Time!):**
   - Render **1 preview PNG per scene** using `node render_frames.mjs --preview --frame=<mid_frame> --w=720 --h=1280` and inspect every single PNG visually!
   - Verify:
     - Are 2D black ink outlines crisp and unbloomed?
     - Are wet street reflections soft painterly gradients (no white specular dots)?
     - Do 3D foreground occluders properly overlap 2D characters?
     - Are shadows lifted rich indigo (never crushed black)?
     - Are captions centered at `y = 70.5%` and readable over both bright & dark scenes?
4. Iterate on keyframes until every scene matches the visual standard of `assets/keyframes_overview.jpg`.

---

## Step 6: Render 30-FPS Sequence, Apply RGB-Safe Grade & Master Audio
1. Render all frames at exact `30.00 fps` (`720×1280` draft -> `1080×1920` final master):
   ```bash
   node render_frames.mjs --frames=<N> --fps=30 --w=1080 --h=1920 --out=out/raw.mp4
   ```
   *(Tip: for long videos > 30 s, split rendering across scene ranges in parallel Node/Chromium workers and concatenate lossless segments before grading!)*
2. Grade each palette segment using **`starter_code/grade_and_finish.sh`** (`gloom`, `warm`, or `cold` mode — which uses `format=gbrp` before screen-blend so there is zero YUV magenta shift!), concatenate cleanly, and mux the mastered audio normalized to **`-14.0 LUFS`, `LRA 2.0 LU`, `True Peak <= -1.5 dBTP`**.

---

## Step 7: Automated QA Gate & Contact Sheet Review
1. Run `python3 starter_code/verify_video.py out/final.mp4 --mode gloom --expect-freeze`.
2. Generate a visual contact sheet (every 15th or 30th frame) with FFmpeg and visually inspect it end-to-end:
   ```bash
   ffmpeg -y -i out/final.mp4 -vf "select='not(mod(n,30))',scale=240:426,tile=6x5" -frames:v 1 out/qa_sheet.jpg
   ```
3. Confirm ALL automated checks PASS (`9:16`, `30.00 fps`, `0 hard cuts`, lifted indigo shadows, saturation, vignette, ending freeze hold, and `-14 LUFS` audio) before delivering to the user!
