#!/usr/bin/env bash
# Finishing grade for AI-generated clips -> "Every Memory Has a Price" look.
# Usage: ./grade.sh input.mp4 output.mp4 [gloom|bright|warm]
# TIP: gloom uses PI/4 (corner/center ~0.34, matches deep-night scenes S03/S13/S15/S17). For medium-dark scenes (S07-type, ~0.5) use PI/5.5.
# NOTE: ffmpeg's vignette 'angle' is inverted vs. intuition: LARGER angle = STRONGER vignette (PI/2 = black corners).
# Output: 1080x1920, 30 fps, H.264. Presets were tuned against measurements of the reference video.
set -euo pipefail
IN="$1"; OUT="$2"; MODE="${3:-gloom}"

case "$MODE" in
gloom)   # night / alley / shop / hospital scenes: indigo shadows, warm peach highlights, strong vignette
  GRADE="eq=contrast=1.08:saturation=0.88:gamma=0.95,\
colorbalance=rs=-0.03:gs=-0.04:bs=0.09:rm=0.00:gm=-0.03:bm=0.05:rh=0.07:gh=0.02:bh=-0.05,\
curves=all='0/0.05 0.20/0.16 0.55/0.52 0.85/0.88 1/1'"
  VIG="vignette=angle=PI/4"
  BLOOM_THR="0/0 0.62/0 0.85/0.6 1/1"; BLOOM_SIGMA=22; BLOOM_OPA=0.40 ;;
bright)  # pool / resort / sunny lake: clipped highlights, cream whites, lower saturation, heavy bloom
  GRADE="eq=contrast=1.04:saturation=1.35:gamma=1.0,\
colorbalance=rs=0.02:gs=0.01:bs=0.02:rh=0.05:gh=0.03:bh=-0.04,\
curves=all='0/0.0 0.5/0.48 1/1'"
  VIG="null"
  BLOOM_THR="0/0 0.55/0 0.8/0.6 1/1"; BLOOM_SIGMA=30; BLOOM_OPA=0.25 ;;
warm)    # cured-brother morning: honey-gold mids, blue edges, soft focus feel
  GRADE="eq=contrast=1.02:saturation=0.88:gamma=1.04,\
colorbalance=rs=-0.02:bs=0.06:rm=0.05:gm=0.02:bm=-0.05:rh=0.06:gh=0.03:bh=-0.06,\
curves=all='0/0.06 0.5/0.56 1/0.97'"
  VIG="vignette=angle=PI/6"
  BLOOM_THR="0/0 0.6/0 0.85/0.6 1/1"; BLOOM_SIGMA=26; BLOOM_OPA=0.50 ;;
*) echo "mode must be gloom|bright|warm"; exit 1 ;;
esac

ffmpeg -y -i "$IN" -filter_complex "
[0:v]scale=1080:1920:flags=lanczos,fps=30,${GRADE},${VIG},split[a][b];
[b]curves=all='${BLOOM_THR}',gblur=sigma=${BLOOM_SIGMA}[bl];
[a][bl]blend=all_mode=screen:all_opacity=${BLOOM_OPA},format=yuv420p[v]" \
  -map "[v]" -map 0:a? -c:v libx264 -preset slow -crf 17 -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 -c:a aac -b:a 192k "$OUT"
