# 05 — Lighting, Color Grading, Blurriness / DOF & Gloom Engineering

This document quantifies the exact photometric and optical recipe behind *Every Memory Has a Price*, including **regional sharpness/DOF blur measurements** across all 2,334 frames and all **7 Light-as-Plot-Signal cues**.

---

## 1. The "Saturated Indigo Gloom" Paradox (Why Shadows Never Look Muddy)
Most amateur dark videos lower brightness and crush shadows toward neutral black (`#000000`) or muddy grey. *Every Memory Has a Price* does the exact opposite:

* **Lifted Shadow Floor:** Across all 2,334 frames, the **5th-percentile dark floor averages `27.0 / 255`** (even in the darkest pawn shop scenes S03/S17/S21, P05 never crushes to zero — shadows hold rich visible RGB like `#15142D`, `#1B1731`, `#151B5E`, `#161C5F`).
* **Higher Saturation in Shadows Than Highlights:** Global mean HSV saturation is `0.511`, while **shadow saturation (`luma < 45`) jumps to `0.653`** — reaching **`0.778` in S14** and **`0.807` in S24**!
* **85/15 Cool-to-Warm Contrast:** In gloom scenes, `85–90%` of frame area is cool royal indigo/periwinkle (`B - R = +14 to +58`), while `10–15%` is a concentrated warm amber practical pool (`#FFD07A`–`#F1D9C1`). That tiny warm island makes the surrounding indigo feel twice as cold and deep!

---

## 2. Regional Blurriness & Depth-of-Field (DOF) Engineering

A defining feature of the reference video is **intentional optical focus separation** — NOT uniform sharpness and NOT uniform softness. Using 360×640 Laplacian variance across Center, Border, Top, Mid, and Bottom regions (`data/frame_metrics_30fps_2334.csv` + `analysis_dashboard.png` Panel 3), the video uses **4 distinct blur/DOF profiles**:

| DOF Class | Measured Signature | Reference Scenes | Visual Effect | How to Recreate in Code |
|---|---|---|---|---|
| **1. Extreme Macro Shallow DOF** | `Sharp_Ctr ~566` vs `Sharp_Brd ~2.5` (**`159×` ratio**) | **S02** (Glowing Card Macro), **S22** (`40×` floating chip) | Tiny hero prop razor-sharp in center; surrounding counter/shelves dissolve into buttery lens bokeh | Render background 3D pass with heavy Gaussian blur (`radius 22–30 px` at 720p) before compositing razor-sharp hero card plane on top |
| **2. Heavy Portrait / Ward BG Blur** | `Sharp_Top ~4–43` vs `Sharp_Bot ~922–1126` (**`97×–280×` vertical ratio**), `Ctr/Brd 5–39×` | **S01**, **S03**, **S13**, **S15**, **S17**, **S23** (`280×`v), **S24** (`97×`v) | 2D cel characters and foreground bed/desk are razor-sharp while background walls, get-well drawings, and cubbies are softly defocused (`~18–26 px` blur) | Either pre-blur distant wall textures on Canvas2D (`ctx.filter = 'blur(16px)'`) OR render a 2-pass WebGL/Canvas composite (blurred 3D room layer + sharp foreground bed & 2D character layer) |
| **3. Rack-Focus Transition DOF** | Border drops sharply while center locks on foreground prop (`28×` ctr/brd) | **S14 -> S15** (`f1066–1092`, frog rack focus) | Background street blurs out (`sigma 0 -> 24 px`) while foreground 2D frog stays 100% crisp across the dissolve into hospital room, then smoothly unblurs background | Animate Gaussian blur radius of background render pass `0 -> 24 px -> 0` while keeping foreground frog layer unblurred |
| **4. Moderate Street / Crisp Deep Focus** | `Sharp_All 444–1905`, `Sharp_Brd 152–1400`, `Ctr/Brd 2.0–8.5×` | **S05**, **S07** (Deli), **S08**, **S09–S11** (Rich Pool/Dome), **S12** (**sharpest: `1905`**!), **S16** (Lake) | Wide architectural tableaux, rich daylight contrast, and the stark poor-side bench keep environment textures (bricks, fence, water caustics, signs) crisp so the viewer reads the world | Single-pass sharp Three.js render + subtle `FogExp2` (`0.010–0.016`) for natural distance softness without lens blur |

> **Key Takeaway for AI Planners:** Never apply uniform blur over the whole image, and **NEVER blur the 2D character ink outlines or captions**. Blurriness lives exclusively on out-of-plane 3D background/foreground depth layers to isolate emotional beats!

---

## 3. Vignette, Bloom & Halation Rules

### A. Vignette Ratio (`Corner Mean Luma / Center Mean Luma`)
* **Gloom & Intimate Decisions (`S01, S02, S03, S13, S15, S17, S19, S21, S24`):** Strong radial indigo vignette — **`corner/center = 0.20 – 0.42`**. Draws the eye directly onto the character's face or glowing prop.
* **Streets & Transitions (`S05, S06, S07, S12, S23`):** Moderate vignette — **`0.45 – 0.71`**.
* **Rich Daylight / Sky Climbs (`S08, S09, S10, S11`):** Open, vignette-free exposure — **`0.93 – 1.09`** (bright sky/water fills the top/bottom corners).

### B. Restrained Bloom (Protecting 2D Characters)
* In Three.js (`Hybrid25DStage`): set `UnrealBloomPass` **`threshold = 0.88–0.90`**, **`strength = 0.20–0.26`**, **`radius = 0.50–0.55`**.
* Tint 2D character billboards slightly under pure white (`#DED6EC` in gloom, `#B9C8F0` in cold cobalt) so their white eyes and peach skin stay below `0.88` luminance and **never halo or wash out**, while emissive windows, bulbs, and glowing memory cards bloom smoothly.
* **CRITICAL FFmpeg Post-Grade Fix:** When adding secondary halation bloom in FFmpeg (`starter_code/grade_and_finish.sh`), **ALWAYS insert `format=gbrp` before `split[a][b]` and `blend=all_mode=screen`**! Running `blend=screen` directly in `yuv420p` corrupts neutral chroma `(128,128)` into bright magenta!

---

## 4. The 7 Light-as-Plot-Signal Cues (Measured Frame-Accurately)
Light is an active narrator in this style. Plan at least 2–3 plot-driven light signals in every new video:

| # | Scene & Frames | Signal Effect | Narrative Meaning | Code Implementation |
|---|---|---|---|---|
| 1 | **S02** `f43–46` | Card glow pulses brighter (`+18%` emissive) | "Every memory has a price" — introduces the currency | Animate `PointLight.intensity` + emissive scale with bell curve |
| 2 | **S03** `f112–140` (peak `f126–130`) | Back-door amber window swells + tiny counter sparkle | "Money" beat — temptation / transaction | Pulse window material emissive + spawn 1-frame 2D star glint |
| 3 | **S06** `f238–246` | Overhead helmet & lamp bloom lavender-white (`4.5%` bloom) | Memory extraction visually completes | Surge `bloomPass.strength` `0.22 -> 0.85` + soft white overlay `0.35` |
| 4 | **S13** `f885–901` | Brass dial floods silver -> rich gold (`#F1D77C`) + stranger pupils glow amber | "The happier the memory, the more it pays" | Cross-blend dial texture silver -> gold + enable `extras.amberEyeGlow` |
| 5 | **S18** `f1484–1498` | `OPERATING` lightbox switches dim -> bright crimson, bleeding red over teal corridor | Surgery begins; ticking clock & dread | Ramp crimson `PointLight('#FF3B30')` + tint character `#E6B8BE` |
| 6 | **S19** `f1513–1640` | **Warm orange ↔ Cold lavender oscillation every `~43 f` (`1.43 s`)** + growing blue-white head halo (`f1607+`) | Repeatedly selling memories / losing warmth bit by bit | `evalLightPulseCycle(frame, 43)` interpolating character tint & key light + `extras.drainHalo` |
| 7 | **S22 -> S23 -> S24** `f1957–2143` | Peak **gold-white blow-out (`f1969–1973`)** -> warm sunlit cream (`b-r -43`) -> **instant 6-frame flip to cold cobalt (`f2137–2142`, `b-r +47`)** | Ultimate sacrifice -> cure -> devastating realization he no longer remembers why | `evalBlowOutFlash` -> `warm_honey` preset -> 6-frame crossfade into `cold_cobalt` preset |
