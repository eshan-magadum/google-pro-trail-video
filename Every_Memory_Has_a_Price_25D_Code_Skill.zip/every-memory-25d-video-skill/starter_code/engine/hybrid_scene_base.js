// Core 2.5D Hybrid Stage: Real 3D Three.js lit diorama + high-threshold UnrealBloomPass
// + depth-sorted 2D Canvas cel-shaded character billboards + 2D atmospheric/caption HUD.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

export const PALETTE_PRESETS = {
  gloom_indigo: {
    bg: '#0F0D25',
    fog: '#161D4C',
    fogDensity: 0.016,
    hemiSky: '#7A8BF0',
    hemiGround: '#181845',
    hemiIntensity: 1.45,
    dirColor: '#8699F8',
    dirIntensity: 1.05,
    exposure: 1.06,
    bloomThreshold: 0.89,
    bloomStrength: 0.22,
    bloomRadius: 0.52,
    vignetteColor: [12, 11, 34],
    vignetteStrength: 0.42,
    charTint: '#DED6EC',
  },
  warm_honey: {
    bg: '#4E312A',
    fog: '#7B4C3A',
    fogDensity: 0.010,
    hemiSky: '#FFD49B',
    hemiGround: '#4A3142',
    hemiIntensity: 1.65,
    dirColor: '#FFBA66',
    dirIntensity: 1.40,
    exposure: 1.12,
    bloomThreshold: 0.84,
    bloomStrength: 0.28,
    bloomRadius: 0.58,
    vignetteColor: [38, 22, 26],
    vignetteStrength: 0.26,
    charTint: '#F5E5D5',
  },
  cold_cobalt: {
    bg: '#0B1238',
    fog: '#101B52',
    fogDensity: 0.018,
    hemiSky: '#5C82F8',
    hemiGround: '#0D1440',
    hemiIntensity: 1.40,
    dirColor: '#6E95FF',
    dirIntensity: 1.15,
    exposure: 1.02,
    bloomThreshold: 0.90,
    bloomStrength: 0.20,
    bloomRadius: 0.48,
    vignetteColor: [8, 12, 42],
    vignetteStrength: 0.45,
    charTint: '#B9C8F0',
  },
  red_operating: {
    bg: '#1A0C1D',
    fog: '#3A1220',
    fogDensity: 0.020,
    hemiSky: '#FF6A62',
    hemiGround: '#1B1A38',
    hemiIntensity: 1.35,
    dirColor: '#FF5048',
    dirIntensity: 1.25,
    exposure: 1.04,
    bloomThreshold: 0.85,
    bloomStrength: 0.30,
    bloomRadius: 0.60,
    vignetteColor: [24, 6, 16],
    vignetteStrength: 0.46,
    charTint: '#E6B8BE',
  },
};

export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export class Hybrid25DStage {
  constructor({ width = 720, height = 1280, fov = 74, preset = 'gloom_indigo' } = {}) {
    this.W = width;
    this.H = height;
    this.preset = { ...PALETTE_PRESETS[preset] };
    this.billboards = [];

    // 1. WebGL2 3D Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(this.W, this.H);
    this.renderer.setPixelRatio(1);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.preset.exposure;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    document.body.appendChild(this.renderer.domElement);

    // 2. Scene + Camera
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(this.preset.bg);
    this.scene.fog = new THREE.FogExp2(this.preset.fog, this.preset.fogDensity);

    this.camera = new THREE.PerspectiveCamera(fov, this.W / this.H, 0.1, 120);
    this.camera.position.set(0, 2.0, 6.0);
    this.camera.lookAt(0, 1.8, 0);

    // 3. Base 3D Lighting Rig
    this.hemi = new THREE.HemisphereLight(
      this.preset.hemiSky,
      this.preset.hemiGround,
      this.preset.hemiIntensity
    );
    this.scene.add(this.hemi);

    this.keyDir = new THREE.DirectionalLight(this.preset.dirColor, this.preset.dirIntensity);
    this.keyDir.position.set(-8, 16, 12);
    this.keyDir.castShadow = true;
    this.keyDir.shadow.mapSize.set(2048, 2048);
    this.keyDir.shadow.camera.near = 1;
    this.keyDir.shadow.camera.far = 48;
    this.keyDir.shadow.camera.left = -16;
    this.keyDir.shadow.camera.right = 16;
    this.keyDir.shadow.camera.top = 18;
    this.keyDir.shadow.camera.bottom = -8;
    this.keyDir.shadow.bias = -0.0005;
    this.scene.add(this.keyDir);

    // 4. Post-Processing Composer (High-threshold UnrealBloomPass keeps 2D characters crisp)
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(this.W, this.H),
      this.preset.bloomStrength,
      this.preset.bloomRadius,
      this.preset.bloomThreshold
    );
    this.composer.addPass(this.bloomPass);
    this.composer.addPass(new OutputPass());

    // 5. 2D Atmospheric + Caption Overlay Canvas
    this.overlay = document.createElement('canvas');
    this.overlay.width = this.W;
    this.overlay.height = this.H;
    this.overlay.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;';
    document.body.appendChild(this.overlay);
    this.og = this.overlay.getContext('2d');
  }

  applyPreset(name) {
    const p = PALETTE_PRESETS[name];
    if (!p) return;
    this.preset = { ...p };
    this.scene.background = new THREE.Color(p.bg);
    this.scene.fog = new THREE.FogExp2(p.fog, p.fogDensity);
    this.hemi.color.set(p.hemiSky);
    this.hemi.groundColor.set(p.hemiGround);
    this.hemi.intensity = p.hemiIntensity;
    this.keyDir.color.set(p.dirColor);
    this.keyDir.intensity = p.dirIntensity;
    this.renderer.toneMappingExposure = p.exposure;
    this.bloomPass.threshold = p.bloomThreshold;
    this.bloomPass.strength = p.bloomStrength;
    this.bloomPass.radius = p.bloomRadius;
  }

  setCameraPose(pos, target, rollDeg = 0, fov = null) {
    if (fov !== null && Math.abs(this.camera.fov - fov) > 0.01) {
      this.camera.fov = fov;
      this.camera.updateProjectionMatrix();
    }
    this.camera.position.set(pos[0], pos[1], pos[2]);
    this.camera.up.set(0, 1, 0);
    this.camera.lookAt(target[0], target[1], target[2]);
    if (rollDeg !== 0) {
      this.camera.rotateZ(THREE.MathUtils.degToRad(rollDeg));
    }
    this.camera.updateMatrixWorld();
    this.updateBillboards();
  }

  // Mount a 2D CanvasTexture cel character inside the 3D z-buffered world
  addCharacterBillboard(texture, {
    x = 0, y = 1.5, z = 0, width = 2.0, height = 3.0,
    tint = null, shadowW = 1.0, shadowY = 0.015, lockYAxis = true,
  } = {}) {
    const mat = new THREE.MeshBasicMaterial({
      map: texture,
      color: new THREE.Color(tint || this.preset.charTint),
      transparent: true,
      alphaTest: 0.05,
      side: THREE.DoubleSide,
    });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), mat);
    mesh.position.set(x, y, z);
    this.scene.add(mesh);

    let shadowMesh = null;
    if (shadowW > 0) {
      const sc = document.createElement('canvas');
      sc.width = 128; sc.height = 128;
      const sg = sc.getContext('2d');
      const g = sg.createRadialGradient(64, 64, 6, 64, 64, 60);
      g.addColorStop(0, 'rgba(10,12,34,0.58)');
      g.addColorStop(1, 'rgba(10,12,34,0)');
      sg.fillStyle = g;
      sg.fillRect(0, 0, 128, 128);
      const sTex = new THREE.CanvasTexture(sc);
      shadowMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(shadowW, shadowW * 0.55),
        new THREE.MeshBasicMaterial({ map: sTex, transparent: true, depthWrite: false })
      );
      shadowMesh.rotation.x = -Math.PI / 2;
      shadowMesh.position.set(x, shadowY, z);
      this.scene.add(shadowMesh);
    }

    const entry = { mesh, shadowMesh, lockYAxis };
    this.billboards.push(entry);
    this.updateBillboards();
    return entry;
  }

  updateBillboards() {
    for (const b of this.billboards) {
      if (b.lockYAxis) {
        const dx = this.camera.position.x - b.mesh.position.x;
        const dz = this.camera.position.z - b.mesh.position.z;
        b.mesh.rotation.y = Math.atan2(dx, dz);
      } else {
        b.mesh.lookAt(this.camera.position);
      }
      if (b.shadowMesh) {
        b.shadowMesh.position.x = b.mesh.position.x;
        b.shadowMesh.position.z = b.mesh.position.z;
      }
    }
  }

  // Painterly wet-street reflection decal (avoids artificial clearcoat specular circles!)
  addWetReflectionDecal({
    x = 0, y = 0.008, z = 2.0, width = 10, depth = 5,
    innerColor = 'rgba(255,220,170,0.50)',
    midColor = 'rgba(210,170,165,0.26)',
    outerColor = 'rgba(80,75,140,0)',
  } = {}) {
    const rc = document.createElement('canvas');
    rc.width = 512; rc.height = 512;
    const rg = rc.getContext('2d');
    const g = rg.createRadialGradient(256, 130, 18, 256, 240, 255);
    g.addColorStop(0.0, innerColor);
    g.addColorStop(0.45, midColor);
    g.addColorStop(1.0, outerColor);
    rg.fillStyle = g;
    rg.fillRect(0, 0, 512, 512);
    const tex = new THREE.CanvasTexture(rc);
    tex.colorSpace = THREE.SRGBColorSpace;
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(width, depth),
      new THREE.MeshBasicMaterial({
        map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      })
    );
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, y, z);
    this.scene.add(mesh);
    return mesh;
  }

  // Render 3D world + 2D overlay (vignette, rain, flash, captions)
  renderFrame({
    frame = 0,
    rain = false,
    rainCount = 46,
    flashOverlay = null, // { alpha, color: [r,g,b] }
    caption = '',
    vignetteStrength = null,
    customOverlayFn = null,
  } = {}) {
    this.composer.render();

    const og = this.og;
    const W = this.W;
    const H = this.H;
    og.clearRect(0, 0, W, H);

    // 1. Indigo/Theme Radial Vignette
    const [vr, vg, vb] = this.preset.vignetteColor;
    const vs = vignetteStrength !== null ? vignetteStrength : this.preset.vignetteStrength;
    const vig = og.createRadialGradient(W * 0.5, H * 0.45, W * 0.28, W * 0.5, H * 0.5, H * 0.72);
    vig.addColorStop(0.0, `rgba(${vr},${vg},${vb},0)`);
    vig.addColorStop(0.68, `rgba(${vr},${vg},${vb},${(vs * 0.22).toFixed(3)})`);
    vig.addColorStop(1.0, `rgba(${vr},${vg},${vb},${vs.toFixed(3)})`);
    og.fillStyle = vig;
    og.fillRect(0, 0, W, H);

    // 2. Crisp Procedural Diagonal Rain Streaks (2D Overlay)
    if (rain) {
      const rng = mulberry32(9001 + frame * 17);
      og.lineCap = 'round';
      for (let i = 0; i < rainCount; i++) {
        const x = rng() * W;
        const y = ((rng() * H + frame * 54) % (H + 160)) - 80;
        const len = (W / 720) * (36 + rng() * 72);
        const tilt = 0.11 + rng() * 0.04;
        const dx = len * tilt;
        const dy = len;
        const alpha = 0.20 + rng() * 0.34;
        const grad = og.createLinearGradient(x, y, x + dx, y + dy);
        grad.addColorStop(0, 'rgba(210,224,255,0)');
        grad.addColorStop(0.35, `rgba(224,235,255,${alpha})`);
        grad.addColorStop(1, `rgba(235,242,255,${alpha * 0.22})`);
        og.strokeStyle = grad;
        og.lineWidth = (W / 720) * (1.2 + rng() * 1.1);
        og.beginPath();
        og.moveTo(x, y);
        og.lineTo(x + dx, y + dy);
        og.stroke();
      }
    }

    // 3. Custom per-scene 2D overlay hook (e.g. polaroid border, mosaic, light leaks)
    if (customOverlayFn) {
      customOverlayFn(og, W, H, frame);
    }

    // 4. Light-led Blow-out Flash Overlay
    if (flashOverlay && flashOverlay.alpha > 0.005) {
      const [fr, fg, fb] = flashOverlay.color || [255, 244, 210];
      og.fillStyle = `rgba(${fr},${fg},${fb},${flashOverlay.alpha.toFixed(4)})`;
      og.fillRect(0, 0, W, H);
    }

    // 5. Reference-Accurate 1-2 Word Captions (y=70%, white fill, thick black stroke)
    if (caption) {
      const fontSize = Math.round(W * 0.076); // ~55px at 720w, ~82px at 1080w
      const strokeW = Math.max(4, Math.round(fontSize * 0.15));
      og.save();
      og.font = `900 ${fontSize}px "Liberation Sans", "DejaVu Sans", Arial, sans-serif`;
      og.textAlign = 'center';
      og.textBaseline = 'middle';
      og.lineJoin = 'round';
      og.shadowColor = 'rgba(0,0,0,0.45)';
      og.shadowBlur = Math.round(fontSize * 0.16);
      og.shadowOffsetY = Math.round(fontSize * 0.06);
      og.strokeStyle = '#07060D';
      og.lineWidth = strokeW;
      og.strokeText(caption, W * 0.5, H * 0.705);
      og.shadowColor = 'transparent';
      og.fillStyle = '#FCFDFD';
      og.fillText(caption, W * 0.5, H * 0.705);
      og.restore();
    }
  }
}
