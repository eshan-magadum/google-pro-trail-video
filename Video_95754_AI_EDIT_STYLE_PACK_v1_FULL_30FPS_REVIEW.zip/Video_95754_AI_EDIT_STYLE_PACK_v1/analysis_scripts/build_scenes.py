"""Build per-scene stats, k-means palettes, reference frames, transition strips, caption CSV, scene JSON."""
import csv, json, os, shutil, numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
B = "/tmp/v95"; FPS = 2997 / 100; OUT = f"{B}/pack"
rows = list(csv.DictReader(open(f"{B}/data/per_frame_metrics_all_frames.csv")))
for r in rows:
    for k in r: r[k] = float(r[k])
SC = [  # id, start, end (inclusive, 1-indexed), layout, name
 ("S01", 1, 53, "SPLIT", "Hook - Anthropic source card (Goya etching) over speaker"),
 ("S02", 54, 121, "FULL_GFX", "The prompt itself - dark document close-up"),
 ("S03", 122, 175, "FULL_GFX", "Pull-out to full article + highlight box"),
 ("S04", 176, 245, "SPLIT", "Iceberg tip - chat box, typewriter 'Make a slide deck...'"),
 ("S05", 246, 368, "FULL_GFX", "Dive under the iceberg - 4 hidden layers reveal"),
 ("S06", 369, 388, "FULL_SPEAKER", "Speaker punch-in 'for example'"),
 ("S07", 389, 511, "FULL_GFX", "Fly-swatter vs bugs -> 'keep this app bug free' shield"),
 ("S08", 512, 565, "SPLIT", "Cmd+V paste the be-ambitious prompt"),
 ("S09", 566, 641, "FULL_GFX", "SKILL.md cartridge powers up the retro machine"),
 ("S10", 642, 703, "SPLIT", "Stamp press + conveyor belt of tasks"),
 ("S11", 704, 732, "FULL_GFX", "Stage door 'Expert' opens to light"),
 ("S12", 733, 774, "FULL_GFX", "Professor at lectern: 'Reproduce it first.'"),
 ("S13", 775, 847, "SPLIT", "Searchlight lights hanging bulbs (ideas)"),
 ("S14", 848, 882, "FULL_SPEAKER", "Speaker punch-in 'it doesn't just give you advice'"),
 ("S15", 883, 935, "SPLIT", "Magnifier + red marker review the prompt card"),
 ("S16", 936, 1003, "FULL_GFX", "Card flips to 'Expert version' checklist + seal + confetti"),
 ("S17", 1004, 1011, "FULL_GFX", "'The Prompt' EXCLUSIVE sheet"),
 ("S18", 1012, 1093, "FULL_SPEAKER", "CTA punch-in: Comment \"DEEPER\""),
]
def img(n): return cv2.imread(f"{B}/full/f{n:04d}.jpg")
def palette(frames, k=6):
    px = np.concatenate([cv2.resize(img(n), (90, 160)).reshape(-1, 3) for n in frames]).astype(np.float32)
    _, lab, cen = cv2.kmeans(px, k, None, (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 1.0), 3, cv2.KMEANS_PP_CENTERS)
    cnt = np.bincount(lab.ravel(), minlength=k); o = np.argsort(-cnt)
    return [{"hex": "#%02x%02x%02x" % tuple(int(v) for v in cen[i][::-1]), "share": round(float(cnt[i] / cnt.sum()), 3)} for i in o]
os.makedirs(f"{OUT}/reference_frames", exist_ok=True); os.makedirs(f"{OUT}/transitions", exist_ok=True)
scenes = []
for sid, a, b, lay, name in SC:
    rr = [r for r in rows if a <= r["frame"] <= b]
    mean = lambda k: round(float(np.mean([r[k] for r in rr])), 2)
    st = dict(id=sid, name=name, layout=lay, start_frame=a, end_frame=b, frames=b - a + 1,
              start_s=round((a - 1) / FPS, 3), end_s=round(b / FPS, 3), duration_s=round((b - a + 1) / FPS, 3),
              mean_luma=mean("luma"), mean_contrast=mean("contrast"), mean_saturation=mean("sat"), mean_warmth_R_minus_B=mean("warmth"),
              mean_edge_density_pct=mean("edge_density"), mean_motion_flow=mean("flow_mag"), max_motion_flow=round(max(r["flow_mag"] for r in rr[1:] or rr), 2),
              mean_vertical_flow=mean("flow_dy"), mean_zoom_idx=mean("zoom_idx"),
              palette=palette(list(np.linspace(a, b, 6).astype(int))))
    scenes.append(st)
    for tag, n in [("start", a + 1), ("mid", (a + b) // 2), ("end", b - 1)]:
        shutil.copy(f"{B}/full/f{n:04d}.jpg", f"{OUT}/reference_frames/{sid}_{tag}_f{n:04d}_{(n-1)/FPS:05.2f}s.jpg")
json.dump({"video": "Video-95754.mp4", "fps": FPS, "frames": len(rows), "resolution": "720x1280", "scenes": scenes},
          open(f"{OUT}/data/scenes.json", "w"), indent=1)
# transition strips: 5 frames before + 7 after each cut, 180px wide
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
for sid, a, b, lay, name in SC[1:]:
    fr = list(range(max(1, a - 5), min(len(rows), a + 7) + 1)); tw, th = 180, 320
    s = Image.new("RGB", (tw * 6, th * ((len(fr) + 5) // 6)), (255, 0, 255)); d = ImageDraw.Draw(s)
    for j, n in enumerate(fr):
        x, y = (j % 6) * tw, (j // 6) * th; s.paste(Image.open(f"{B}/full/f{n:04d}.jpg").resize((tw, th)), (x, y))
        d.rectangle([x, y, x + 120, y + 20], fill=(255, 0, 0) if n == a else (0, 0, 0)); d.text((x + 3, y + 1), f"f{n} {(n-1)/FPS:.2f}s", fill="yellow", font=font)
    s.save(f"{OUT}/transitions/cut_into_{sid}_f{a:04d}.jpg", quality=85)
for s in scenes: print(s["id"], s["layout"], s["frames"], s["mean_luma"], s["mean_saturation"], s["mean_motion_flow"], [p["hex"] for p in s["palette"][:4]])
