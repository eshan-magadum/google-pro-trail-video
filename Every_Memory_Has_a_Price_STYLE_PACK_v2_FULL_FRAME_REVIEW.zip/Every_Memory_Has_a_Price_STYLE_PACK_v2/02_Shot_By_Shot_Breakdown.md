# 02 — SHOT-BY-SHOT BREAKDOWN (24 scenes, frame-accurate)
Times are in seconds from the start; frame = t × 30 + 1. Numbers (luma, sat, etc.) are measured over *every frame* of the scene. Palette swatches are the six dominant colours (percent of pixels).


## S01 · Hook: hero at the memory counter, swing-pitch to the counter
**0.00 – 0.90 s** (frames 1–27, 27 frames, 0.9 s)

* **What you see:** Memory-shop counter at night. Protagonist stands right of a long, wedge-perspective wooden counter, worried. Hooded stranger visible far-left behind a translucent glass partition. Green-shaded pendant lamp top-centre, teal oval-pattern wallpaper, wood door with an amber lit window, brass cash-register, a tiny glowing memory card on the counter.
* **Camera:** Low wide-angle hold, then a short push-in on the hero (f20-27); at f25 the camera SWINGS and pitches ~70 deg down onto the counter; his face GHOSTS (frame-blend) over the counter for 3 frames (f28-30).
* **Lighting / shadow:** Cool navy ambient + warm counter pool; hard diagonal shadow band across the counter; lamp bloom; vignette strong (corner÷centre 0.21).
* **Depth / blur:** Foreground counter large and slightly soft; stranger behind glass hazy; deep perspective convergence.
* **Characters & expression:** Hero: raised-brow squint (f1) -> ONE-EYE WINK/blink (f2-3) -> half-lid -> wide ring-eyes (f7+) -> alarmed. Stranger: blank, glowing eyes.
* **Transition out:** Camera swing onto the card (T1).
* **Narrative beat (my paraphrase):** Opening hook: someone has traded away their happiest memory to a stranger.
* **Measured:** luma **67.9**/255 (P5 18, P95 188) · saturation **0.48** · vignette corner÷centre **0.21** · bright-pixel share **4.6%** · dark-pixel share **36%** · motion **0.95** px/f · zoom divergence **+0.73** · sharpness **414**
* **Palette:** `#1f162c` 38% · `#2f3453` 21% · `#5d3942` 15% · `#ba754b` 11% · `#5b677c` 9% · `#f0e3d0` 5%


## S02 · Macro: glowing memory card, then pull-up
**0.90 – 1.80 s** (frames 28–54, 27 frames, 0.9 s)

* **What you see:** Top-down macro of a pale glass tray on the counter with the glowing gold memory card (tiny lake-scene picture on it). Out-of-focus cash register at top.
* **Camera:** Top-down macro with the card GLOW PULSING (f43-46) and a rack focus; at f47 the camera PULLS UP/BACK (not a dissolve): card shrinks, register appears, vignette closes (f51-60) and the stranger enters far-left at f55.
* **Lighting / shadow:** Washed highlights (luma 109, sat 0.33): cool white tray against warm wood; card emits warm gold glow.
* **Depth / blur:** Very shallow DOF; background creamy blur.
* **Characters & expression:** n/a (prop).
* **Transition out:** Continuous pull-up into the stranger's room with a 0.3 s exposure fall (luma 130 -> 40).
* **Narrative beat (my paraphrase):** The 'memory' is shown as a physical, glowing object you can hold.
* **Measured:** luma **103.2**/255 (P5 40, P95 177) · saturation **0.35** · vignette corner÷centre **0.26** · bright-pixel share **1.8%** · dark-pixel share **18%** · motion **2.63** px/f · zoom divergence **+0.03** · sharpness **181**
* **Palette:** `#7d5866` 25% · `#a5a7b2` 24% · `#b17a65` 19% · `#4c3754` 17% · `#151027` 13% · `#e4e2dd` 2%


## S03 · Hooded stranger + memory-cubby wall (slow pull-back drift)
**1.80 – 5.00 s** (frames 55–150, 96 frames, 3.2 s)

* **What you see:** Hooded stranger behind the counter, giant toothy grin, glowing amber eyes; wall of memory cubbies (≈6×8 grid) with tiny blue/pink/amber glowing cards; filing drawers with gold label plates; amber lit door; brass register; lamp pool on counter.
* **Camera:** Slow PULL-BACK/orbit drift: the cubby wall slides in from the left, the stranger shrinks in frame (f61-144). The amber door window PULSES brighter f112-140 and a tiny sparkle glints on the counter edge (beat on the word 'money').
* **Lighting / shadow:** Darkest scene (luma 42, 69 % of pixels <40, vignette 0.36). Pale-blue rim on hood; amber door and cubby cards are the only light.
* **Depth / blur:** Cubby wall in soft focus; stranger and counter edge crisp.
* **Characters & expression:** Stranger: constant big grin with amber glints; the room's light flickers instead of the face.
* **Transition out:** Glass pane drifts across; dissolve to alley (T3).
* **Narrative beat (my paraphrase):** Rule of this world: memories are currency.
* **Measured:** luma **38.5**/255 (P5 12, P95 118) · saturation **0.55** · vignette corner÷centre **0.4** · bright-pixel share **0.5%** · dark-pixel share **73%** · motion **0.71** px/f · zoom divergence **-0.06** · sharpness **241**
* **Palette:** `#1b1835` 39% · `#0f0d21` 30% · `#322844` 19% · `#6b4a58` 5% · `#b27e62` 4% · `#c4bfca` 2%


## S04 · Glass-pane dissolve into the alley
**5.00 – 5.60 s** (frames 151–168, 18 frames, 0.6 s)

* **What you see:** A thin glass-pane edge enters from the LEFT at f153 while the hero enters from the RIGHT (f152); the shop dissolves (f158-166) into a rainy alley with a glowing light-box poster.
* **Camera:** Pull-back with sideways glass sweep; zoom divergence −1.9.
* **Lighting / shadow:** Vignette 0.68 (frame still dark at edges), bokeh lights ahead.
* **Depth / blur:** Pane in front → depth layering.
* **Characters & expression:** Hero: worried.
* **Transition out:** T3 glass sweep dissolve.
* **Narrative beat (my paraphrase):** Shift from the shop out into the wider city.
* **Measured:** luma **57.9**/255 (P5 19, P95 134) · saturation **0.48** · vignette corner÷centre **0.63** · bright-pixel share **1.2%** · dark-pixel share **40%** · motion **3.05** px/f · zoom divergence **-2.15** · sharpness **276**
* **Palette:** `#1a1530` 38% · `#332b4b` 28% · `#4b4a70` 14% · `#704a51` 12% · `#a58071` 6% · `#e0d0c3` 2%


## S05 · Rainy alley dolly + skyline bokeh
**5.60 – 6.53 s** (frames 169–196, 28 frames, 0.9 s)

* **What you see:** Rainy neon alley, wet pavement, vanishing-point light, vertical neon sign, bokeh lights, light-box poster at right.
* **Camera:** Forward dolly along the alley.
* **Lighting / shadow:** Indigo→electric-blue→lavender; far-end warm lights; strong haze (vig 0.55).
* **Depth / blur:** Atmospheric perspective: far lights soft and hazy.
* **Characters & expression:** —
* **Transition out:** 0.25 s window-glass dissolve (6.50–6.75 s): the alley is seen through rain-spotted glass while the lit extractor shop fades in behind it (luma 68→104). Not a cut.
* **Narrative beat (my paraphrase):** Memory shops are on every corner.
* **Measured:** luma **68.2**/255 (P5 27, P95 155) · saturation **0.57** · vignette corner÷centre **0.61** · bright-pixel share **2.1%** · dark-pixel share **25%** · motion **1.2** px/f · zoom divergence **-0.78** · sharpness **496**
* **Palette:** `#1d1845` 28% · `#1f2b80` 25% · `#524a96` 19% · `#4e355b` 13% · `#946e84` 12% · `#e0c4b9` 4%


## S06 · Extractor shop (seen through window glass), extraction flash
**6.53 – 8.67 s** (frames 197–260, 64 frames, 2.1 s)

* **What you see:** First seen THROUGH the rain-spotted window glass of the alley (f196-204), sign lettering legible by f204. Extraction-shop chair with a metal helmet on a seated customer (eyes closed, content), bald assistant eyes closed; teal wall, arched gold sign, teal-and-white checkerboard floor, large pendant lamp. EXTRACTION MINI-EVENT f237-252: a small glowing card/jar rises from the helmet top with a big BLOOM FLASH (f238-246) that turns the frame pale lavender-white.
* **Camera:** Dolly-in + tilt up toward the lamp (bloom swells 7.5→8.0 s).
* **Lighting / shadow:** Luma 108, 7 % pixels >235; lavender-pink radial haze `#8F708C→#ECD4D2`.
* **Depth / blur:** Strong glow-fog flattens depth; floor checker pattern gives perspective.
* **Characters & expression:** Customer: calm/blank; assistant: neutral.
* **Transition out:** ~0.2 s cross-dissolve (f259-264): lavender haze fades to indigo deli street.
* **Narrative beat (my paraphrase):** How the trade works: the memory is drawn out of the customer's head.
* **Measured:** luma **109.9**/255 (P5 43, P95 206) · saturation **0.39** · vignette corner÷centre **0.48** · bright-pixel share **7.1%** · dark-pixel share **3%** · motion **0.75** px/f · zoom divergence **+0.65** · sharpness **156**
* **Palette:** `#645387` 26% · `#373e73` 21% · `#90708c` 20% · `#bb99a6` 14% · `#212553` 10% · `#ecd4d3` 9%


## S07 · Deli street: landlord, bike crash
**8.67 – 13.20 s** (frames 261–396, 136 frames, 4.5 s)

* **What you see:** Rainy night deli street: red awning 'DELI GROCERY', big glowing shop window full of colourful goods, fire escape, wet pavement, a landlord on the steps, a kid on a bike, bystanders.
* **Camera:** Starts on the landlord on the steps, TRUCKS RIGHT along the storefront (landlord exits left f313-324), settles low on the kid on the bike. Kid pedals, WOBBLES and CRASHES at f373-377 (cartwheels off), lying beside the fallen bike; a small grey-faced bystander watches from the window. Rain throughout.
* **Lighting / shadow:** Indigo night + warm amber window; red awning accent; luma 85, 8.7 % bright pixels.
* **Depth / blur:** Rain-streaked mid-ground; window glow blooms.
* **Characters & expression:** Landlord: tired ring/dizzy eyes + sweat; kid: delighted -> startled; bystander: worried.
* **Transition out:** Camera tilts up the wall (continuous into S08).
* **Narrative beat (my paraphrase):** Everyday bills (rent, a birthday, groceries) are paid with the best days of your life.
* **Measured:** luma **84.6**/255 (P5 26, P95 225) · saturation **0.54** · vignette corner÷centre **0.5** · bright-pixel share **8.4%** · dark-pixel share **18%** · motion **1.17** px/f · zoom divergence **+0.52** · sharpness **469**
* **Palette:** `#2c3486` 29% · `#1e1b47` 22% · `#5a559a` 20% · `#efd7be` 11% · `#5e324c` 10% · `#9c7d8d` 9%


## S08 · Tilt up the giant wall + light shafts
**13.20 – 15.67 s** (frames 397–470, 74 frames, 2.5 s)

* **What you see:** Camera tilts up the face of a building to a colossal city-dividing wall with warm spotlights and white light shafts; fallen bike and kid at the bottom of frame.
* **Camera:** Tilt-up (f397-432) passes a large hanging BANNER with a round emblem and thin vertical cable lines, then a near-static hold (f433-468) looking up the wall at ~25 deg Dutch roll with a row of warm orange wall lamps and violet sky; slow drift.
* **Lighting / shadow:** God-rays from top, lens flare, violet haze; luma 75.
* **Depth / blur:** Extreme scale — tiny characters vs giant wall.
* **Characters & expression:** —
* **Transition out:** T4 top-down luminous wipe to the pool.
* **Narrative beat (my paraphrase):** A colossal wall splits the city into two worlds.
* **Measured:** luma **74.5**/255 (P5 24, P95 198) · saturation **0.57** · vignette corner÷centre **1.07** · bright-pixel share **4.7%** · dark-pixel share **20%** · motion **1.48** px/f · zoom divergence **-0.71** · sharpness **397**
* **Palette:** `#303483` 35% · `#1c1c4e` 30% · `#645b9e` 14% · `#614262` 8% · `#f1d3b1` 6% · `#ae8488` 6%


## S09 · Rich side: resort pool, lounger + butler
**15.67 – 18.67 s** (frames 471–560, 90 frames, 3.0 s)

* **What you see:** Sunny resort: turquoise pool with caustics, hillside tiered seating, floodlight tower, palm trees, pink bougainvillea; far figure on a lounger, then butler and lounger in big straw hat and sunglasses.
* **Camera:** WIPE at f470-481: a seam appears ~45% down and travels DOWNWARD; its leading edge is an overexposed WHITE band that resolves into cyan caustic water. Then a water-level dolly forward + rise (lounger grows f493-512, butler leans in f509-516); sunglasses visible from f541.
* **Lighting / shadow:** Blown daylight: luma 155, bloom 17 %, no vignette (0.91).
* **Depth / blur:** Deep focus, plastic-clean.
* **Characters & expression:** Rich lounger: smug half-lids; butler: haughty, one brow raised.
* **Transition out:** Cross-dissolve + WHITE BLOW-OUT (f557-566: near-white frame) into the Bahamas guy's window room.
* **Narrative beat (my paraphrase):** Rich side: the wealthy buy other people's summers.
* **Measured:** luma **157.6**/255 (P5 64, P95 223) · saturation **0.4** · vignette corner÷centre **0.92** · bright-pixel share **18.2%** · dark-pixel share **3%** · motion **1.95** px/f · zoom divergence **+0.96** · sharpness **830**
* **Palette:** `#b2a589` 27% · `#84bed8` 20% · `#ecd8af` 19% · `#564932` 13% · `#49b0c6` 13% · `#4c5f8e` 8%


## S10 · Bahamas guy: dome descends, odometer ticks, dome lifts
**18.67 – 21.60 s** (frames 561–648, 88 frames, 2.9 s)

* **What you see:** Hawaiian-shirt guy with snorkel mask in a window room; a copper dome extractor on a ceiling tube DESCENDS onto his head (f577-600) with a glowing halo at its rim while the camera dollies in; eyes closed in bliss. Camera TILTS DOWN (f604-612) as a gold odometer on a round tray rises into frame; digit wheels read 0299, ROLL (blur f616) and tick up (caption '300' overlaps); the dome then LIFTS back up its tube (f640-648).
* **Camera:** Dolly-in as the dome descends, then tilt-down to the odometer, then pull back/up as the dome lifts.
* **Lighting / shadow:** Blown highlights: 46 % pixels >235; radial halo near-white behind head → cobalt edges.
* **Depth / blur:** Counter large in foreground, subject mid, window far.
* **Characters & expression:** Guy: eyes-closed bliss, dreamy smile.
* **Transition out:** Pulls back to the couch (S11).
* **Narrative beat (my paraphrase):** A rich man 'owns' a pile of tropical holidays he never took.
* **Measured:** luma **176.9**/255 (P5 47, P95 243) · saturation **0.37** · vignette corner÷centre **0.94** · bright-pixel share **45.0%** · dark-pixel share **5%** · motion **2.23** px/f · zoom divergence **-0.03** · sharpness **787**
* **Palette:** `#ebe9ee` 27% · `#e3cda7` 24% · `#8cbaec` 16% · `#bb833e` 12% · `#4978ec` 10% · `#3e2828` 9%


## S11 · Couch wide, then flamingo-pool water dissolve
**21.60 – 23.47 s** (frames 649–704, 56 frames, 1.9 s)

* **What you see:** Pull-back wide of the guy on a white couch with the dome rising and glowing, flamingo float in the pool beyond the window; then a cross-dissolve (f685-693) to caustic pool water with the pink flamingo float and a tiled pool-floor grid at the far edge.
* **Camera:** Sideways drift/pull-back to a wide, then slow glide over the water.
* **Lighting / shadow:** Bright cyan water, caustics, 31 % bright pixels.
* **Depth / blur:** Pool surface refracts; ripples fill frame.
* **Characters & expression:** Guy: blissed-out, eyes closed.
* **Transition out:** CORRECTION: VERTICAL BLURRED LIGHT STREAKS (blinds/fog-column look) sweep over the water f705-720 and dissolve into the dusk bench; bench figures ghost through at f716-720.
* **Narrative beat (my paraphrase):** …and never even gets off his couch.
* **Measured:** luma **176.5**/255 (P5 69, P95 231) · saturation **0.41** · vignette corner÷centre **0.97** · bright-pixel share **34.5%** · dark-pixel share **3%** · motion **1.74** px/f · zoom divergence **+0.45** · sharpness **757**
* **Palette:** `#e4cfa1` 27% · `#4fcdc1` 21% · `#7f96ed` 21% · `#d5deed` 20% · `#a77d56` 6% · `#3b2d33` 6%


## S12 · Poor side: bench push-in, photos
**23.47 – 27.60 s** (frames 705–828, 124 frames, 4.1 s)

* **What you see:** Poor side at dusk: starts as a tiny FAR WIDE of three elders on a wooden bench (f721-732) and PUSHES IN continuously to a medium two-shot (woman + bald man with round glasses) while the third figure exits left; chain-link fence, red bench ad ('...BOUGHT & SOLD ... 555-0142'), cracked concrete, vertical foggy light columns at top until ~f780. Elders' eyes CLOSE in a serene blank smile (f790-792, f808-822); the WOMAN LIFTS her framed photo toward her face (f820-828).
* **Camera:** Low static → very slow push-in.
* **Lighting / shadow:** Cold violet-blue ambient (luma 91) with warm skin; softness lost to hyper-detailed linework (sharpness ≈ 2000).
* **Depth / blur:** Mostly flat/deep, fence pattern gives texture.
* **Characters & expression:** Woman: calm blank smile; man with glasses: half-lidded, slightly confused; third: partly seen.
* **Transition out:** SHAPE MATCH-CUT (f825-836): a big round brass dial ring grows over the bench scene and becomes the HAPPINESS gauge (photo frame -> round dial).
* **Narrative beat (my paraphrase):** Poor side: people stare at old photos, smiling without knowing why.
* **Measured:** luma **96.4**/255 (P5 37, P95 181) · saturation **0.49** · vignette corner÷centre **0.73** · bright-pixel share **1.1%** · dark-pixel share **11%** · motion **0.89** px/f · zoom divergence **+0.38** · sharpness **1626**
* **Palette:** `#854e5f` 27% · `#323372` 23% · `#5e67a9` 18% · `#80a5cf` 13% · `#2e172d` 12% · `#eba582` 8%


## S13 · Happiness gauge: pull-back, grin, gold flood
**27.60 – 31.67 s** (frames 829–950, 122 frames, 4.1 s)

* **What you see:** Brass HAPPINESS gauge starts BIG and the camera PULLS BACK (f833-864) to reveal buckets left/right and the cubby wall. The stranger is NOT grinning at first (f833-875: dark, blank, bored, head tilting). Tiny GOLD SPARKS travel at the dial's upper right (f873-884). His GRIN appears gradually (f879-893), the needle swings from the rain icon to the sun (f885-900), the whole dial FLOODS GOLD (f893-900), eyes glow amber from f901, and the price odometer rolls (f910-948).
* **Camera:** Tight static with breathing push.
* **Lighting / shadow:** Gold glow from the gauge strengthens as needle climbs (bright-pixel share ≈ 5 %), cubby wall in dark.
* **Depth / blur:** Gauge sharp; stranger and cubbies soft.
* **Characters & expression:** Stranger: bored/blank -> smile -> full toothy grin, glowing eyes.
* **Transition out:** CIRCULAR IRIS-RING dissolve (f946-956): the gold gauge ring fades out over the night street.
* **Narrative beat (my paraphrase):** The happier the memory, the higher the price (the rule made visual).
* **Measured:** luma **79.2**/255 (P5 11, P95 190) · saturation **0.47** · vignette corner÷centre **0.3** · bright-pixel share **4.9%** · dark-pixel share **35%** · motion **0.57** px/f · zoom divergence **-0.22** · sharpness **467**
* **Palette:** `#0f0e24` 30% · `#382c46` 23% · `#6b515b` 20% · `#b68a55` 14% · `#9f98a9` 8% · `#f0d98c` 5%


## S14 · Night street: rent, brother collapses, frog on the ground
**31.67 – 36.00 s** (frames 951–1080, 130 frames, 4.3 s)

* **What you see:** Night street, pennant lights, apartment windows, wet mirror ground. The LITTLE BROTHER here is a GREEN-CAP kid in a red shirt who is healthy and bouncing; a FROG hops onto his cap (f1025-1044). 'Gets sick' beat f1046-1060: the frog leaps off, the cap tumbles, he collapses and Jerry catches him (Jerry: wide alarmed eyes). A blue-faced landlord stands at the right edge.
* **Camera:** Low Dutch angle with ROLL increasing (f1046-1068) and a TILT-DOWN onto the wet reflection where the frog sits alone (f1054-1068), then heavy rack-defocus (f1066-1080).
* **Lighting / shadow:** Deep cobalt `#152075` / indigo `#151440`, luma 56, sat 0.66 — the most saturated gloom.
* **Depth / blur:** Mirror reflections create a second layer.
* **Characters & expression:** Brother: delighted bounce -> limp collapse; Jerry: troubled -> wide alarm.
* **Transition out:** FROG MATCH-DISSOLVE (f1078-1092): the frog holds its screen position while the street dissolves into the hospital, where it becomes the bed-rail frog.
* **Narrative beat (my paraphrase):** The hero sells one to pay rent; the same week his little brother falls ill.
* **Measured:** luma **54.6**/255 (P5 18, P95 148) · saturation **0.67** · vignette corner÷centre **0.43** · bright-pixel share **1.3%** · dark-pixel share **47%** · motion **0.88** px/f · zoom divergence **+0.11** · sharpness **365**
* **Palette:** `#162175` 32% · `#151541` 30% · `#383991` 14% · `#523859` 12% · `#856890` 8% · `#ceb1be` 4%


## S15 · Hospital bedside: bedtime story, polaroid grows
**36.00 – 39.17 s** (frames 1081–1175, 95 frames, 3.2 s)

* **What you see:** Hospital bedside: brother in light-blue gown LEFT, Jerry RIGHT; Jerry's closed-eye content smile (f1093-1128) while the brother's face sinks into a sad droop (f1117-1128); frog at the bed edge; warm lamp orb behind (f1129-1146). Camera pushes past Jerry's face to a POLAROID on the bedside table, which GROWS toward the lens (f1162-1176) with a diagonal white glare streak and a blue handwritten caption 'the frog!' plus a small smiley; its white border then slides off as the picture fills the frame.
* **Camera:** Slow push-in/orbit.
* **Lighting / shadow:** Warm lamp pool on faces against cobalt; luma 71.
* **Depth / blur:** Soft background; faces crisp.
* **Characters & expression:** Jerry: content smile -> deadpan half-lid (f1141-1145) -> small smile; brother: neutral -> sad droop.
* **Transition out:** Polaroid grows to full-frame and its border slides off, becoming the lake (f1162-1188).
* **Narrative beat (my paraphrase):** In hospital the little brother keeps asking for the same bedtime story.
* **Measured:** luma **79.8**/255 (P5 17, P95 190) · saturation **0.55** · vignette corner÷centre **0.29** · bright-pixel share **4.7%** · dark-pixel share **36%** · motion **1.57** px/f · zoom divergence **+1.10** · sharpness **381**
* **Palette:** `#192068` 28% · `#1a0e2a` 21% · `#51549c` 18% · `#a18d9f` 17% · `#e3ccbd` 9% · `#6c3c40` 8%


## S16 · Polaroid becomes the golden-hour lake memory (frog leap)
**39.17 – 42.40 s** (frames 1176–1272, 97 frames, 3.2 s)

* **What you see:** Golden-hour lake: sun low-centre with rays, dock, two boys (red top / green-yellow top), lily pads and reeds. FROG LEAP f1201-1237: the frog jumps from the left lily pad into the net, arcs up with spray, lands on the dock beside the smaller boy who holds it (f1243+). Boys: delighted squints.
* **Camera:** Photo match-cut zoom, then gentle drift with parallax.
* **Lighting / shadow:** Honey sun + cool blue water: luma 127, bloom 12 %, vig 0.67.
* **Depth / blur:** Layered: reeds in front, dock mid, tree-line distant.
* **Characters & expression:** Boys: joyful squints; frog: wide-eyed leaping.
* **Transition out:** The scene is RE-FRAMED INSIDE a polaroid (frame shrinks back, border returns f1266-1272), dims to dark blue and becomes the polaroid clipped to the IV stand (reverse match-cut).
* **Narrative beat (my paraphrase):** That story is a golden summer when they caught a giant frog at the lake.
* **Measured:** luma **123.5**/255 (P5 56, P95 215) · saturation **0.47** · vignette corner÷centre **0.66** · bright-pixel share **10.7%** · dark-pixel share **2%** · motion **0.43** px/f · zoom divergence **-0.09** · sharpness **578**
* **Palette:** `#1d4e74` 21% · `#407fab` 20% · `#82a3be` 16% · `#e2d3bb` 15% · `#505041` 14% · `#9e8163` 13%


## S17 · IV-pole price gauge + the desk sale (lamp-lit face)
**42.40 – 47.07 s** (frames 1273–1412, 140 frames, 4.7 s)

* **What you see:** Dark hospital: polaroid clipped to an IV stand under a 'BLOOD METER' style label panel (f1278-1282); camera TILTS UP and Jerry's face swings in from the left with a round gauge on the pole behind him. Then a face-position dissolve (f1326-1336) to the desk sale: stranger = dark foreground silhouette far-left with faint eye glints; Jerry's face lit white-peach by the desk lamp; tiny glowing card sparkle on the desk (f1343-1350, f1385-1400).
* **Camera:** Static two-shot with very slow push.
* **Lighting / shadow:** Very dark (luma 48, 61 % <40); face lit from beneath, lavender edge, thin glint on the glass.
* **Depth / blur:** Foreground silhouette defocused; face crisp.
* **Characters & expression:** Jerry: deadpan (f1297-1305) -> WAVY ZIGZAG anxious mouth + SWEAT DROP (f1302-1320) -> flat dash (f1321-1324) -> tiny 'o' (f1325) -> worried frown at the desk -> sideways glance (f1355-1368) -> a TEAR (f1399-1405).
* **Transition out:** Face-ghost dissolve (f1412-1418) into the birthday-card macro.
* **Narrative beat (my paraphrase):** The medicine costs far more; he sells the frog-summer memory to afford it.
* **Measured:** luma **45.9**/255 (P5 9, P95 158) · saturation **0.64** · vignette corner÷centre **0.27** · bright-pixel share **2.3%** · dark-pixel share **63%** · motion **0.73** px/f · zoom divergence **-0.24** · sharpness **288**
* **Palette:** `#0c0b20` 37% · `#16194a` 29% · `#273279` 14% · `#beb9e5` 7% · `#5b60af` 7% · `#5f405c` 5%


## S18 · Birthday card macro, pull-back, OPERATING sign goes red
**47.07 – 50.00 s** (frames 1413–1500, 88 frames, 2.9 s)

* **What you see:** Macro of the BIRTHDAY CARD (maroon card with an illustration of the green-cap kid) on top of the olive gauge box ('EMPTY / PAID' plate). Camera PULLS BACK (f1433-1452) as a dark round BALL-HAND swings in from the right and presses the box (f1442-1447); Jerry swings in (f1447+). Teal-and-white checkerboard corridor; the OPERATING sign goes DIM->RED at f1484-1496 and a RED GLOW BLEEDS across the whole teal corridor (wall, face, floor).
* **Camera:** Whip pull-back and up (T8).
* **Lighting / shadow:** Cold clinical teal `#79A5A9`; luma 118; the red sign is the only hot colour.
* **Depth / blur:** Foreground box large and defocused; boy mid.
* **Characters & expression:** Jerry: sly half-lid (f1449-1458) -> eyes-shut sigh (f1459-1461) -> wide ring-eyes neutral (f1462-1476) -> SERENE EYES-CLOSED resignation (f1481-1500).
* **Transition out:** Orange/blue overlay cross-dissolve (f1498-1512) into the 'WE BUY SUMMERS' scene; the corridor figure ghosts over it.
* **Narrative beat (my paraphrase):** His best birthday pays for the surgery.
* **Measured:** luma **119.1**/255 (P5 34, P95 201) · saturation **0.39** · vignette corner÷centre **0.75** · bright-pixel share **7.1%** · dark-pixel share **8%** · motion **1.87** px/f · zoom divergence **-0.85** · sharpness **445**
* **Palette:** `#212d32` 20% · `#79a3a7` 20% · `#40656f` 19% · `#a78569` 17% · `#becdcc` 15% · `#794f32` 9%


## S19 · WE BUY SUMMERS: Jerry sells whole years (face colour pulses)
**50.00 – 54.67 s** (frames 1501–1640, 140 frames, 4.7 s)

* **What you see:** Jerry stands holding the box under a slanted mustard board reading 'WE BUY SUMMERS' in MAROON slab-serif caps with a handwritten script line 'cash today, any grade'; teal wall, orange spotlights; a hanging spot lamp on a rod lights him from f1573. HIS SKIN COLOUR PULSES between cold lavender-white and warm orange about every 1.45 s (cold f1513-1524, warm f1525-1541, cold f1543-1560, warm f1561-1572, cold f1573-1590, warm f1594-1606, cold + blue-white HALO f1607-1626, warm f1627-1640).
* **Camera:** Low-angle, slightly Dutch hold: the slanted sign and hanging spot lamp stay locked at the top, tiny head drift; his head droops downward-back late in the scene.
* **Lighting / shadow:** Cool/warm flicker on his face, halo around his head at 54 s; luma 75.
* **Depth / blur:** Mid shot; wall slightly soft.
* **Characters & expression:** Wide ring-eyes -> squint (f1537-1541) -> flat closed-lid tired (f1543-1560) -> deadpan sideways glance (f1561-1572) -> head DROOPS and tilts back with eyes closed (f1573-1640).
* **Transition out:** Dissolve (f1636-1648): his face ghost + red/orange warmth fade into the cold-blue sickroom.
* **Narrative beat (my paraphrase):** He keeps selling whole years until his head holds mostly bad days.
* **Measured:** luma **73.1**/255 (P5 24, P95 183) · saturation **0.59** · vignette corner÷centre **0.46** · bright-pixel share **0.5%** · dark-pixel share **27%** · motion **0.5** px/f · zoom divergence **+0.17** · sharpness **398**
* **Palette:** `#1e1b38` 30% · `#1d3f69` 29% · `#804930` 14% · `#5d5587` 14% · `#cf9069` 7% · `#c2b1d5` 6%


## S20 · Brother worse + the MEMORY SAVINGS ledger
**54.67 – 58.17 s** (frames 1641–1745, 105 frames, 3.5 s)

* **What you see:** Sickbed hold (brother sunk in pillows, eyes closed; Jerry watching; lamp orb at left). Cross-dissolve (f1678-1692) to a HUGE cold-lit Jerry face who HOLDS UP the open ledger with his ball-hand; the camera PUSHES IN on the book until the page fills the frame: title 'MEMORY SAVINGS', rows YEAR 2025...2016 each with a red-bordered SOLD stamp, the 2016 row highlighted gold with a star and shimmering (f1709-1740).
* **Camera:** Bed → push into the ledger page.
* **Lighting / shadow:** Cold blue bed; bright paper page lifts frame luma to ≈ 136.
* **Depth / blur:** Ledger flat to camera.
* **Characters & expression:** Brother: sunken.
* **Transition out:** Ledger page dissolves UP into the shop scene (f1737-1748).
* **Narrative beat (my paraphrase):** The brother worsens; the ledger shows only one good year left.
* **Measured:** luma **95.0**/255 (P5 12, P95 198) · saturation **0.45** · vignette corner÷centre **0.34** · bright-pixel share **10.9%** · dark-pixel share **39%** · motion **1.19** px/f · zoom divergence **+0.86** · sharpness **775**
* **Palette:** `#140e28` 29% · `#d7c6c4` 18% · `#191e5c` 16% · `#ad9fba` 14% · `#4f4473` 12% · `#7d6f94` 11%


## S21 · Shop: stranger's hood is pulled back, warning + resolve
**58.17 – 63.33 s** (frames 1746–1900, 155 frames, 5.2 s)

* **What you see:** Shop under the arched gold sign 'MEMORIES bought & sold / CASH TODAY - ALL GRADES': Jerry LEFT (yellow vest, red chair arms), hooded stranger RIGHT, lavender dome lamp overhead. The stranger's HOOD IS PULLED BACK (f1773-1776) revealing a round white face; the camera PUSHES IN until it fills the frame (f1777-1848): worried tilted brows, small ellipse mouth, little TREMOR LINES at the left of the face, a one-eye WINK/FLINCH (f1840-1846). Camera pulls back (f1849-1872) to the two-shot; Jerry's face turns RESOLUTE (brows down, half-lids, tiny smirk-frown, f1889-1900) while the stranger raises a brow, squeezes his eyes shut sadly (f1890-1894), then goes wide-eyed shocked (f1897+).
* **Camera:** Slow push to the stranger, reverse on the boy.
* **Lighting / shadow:** Black surround with warm sign; 56 % <40 luma, but bright face (p95 234).
* **Depth / blur:** Faces large; sign soft behind.
* **Characters & expression:** Stranger: tremor, worried, wink, sad squeeze, shock; Jerry: calm -> resolute.
* **Transition out:** The overhead dome lamp descends onto Jerry's head (f1902-1920) - the lamp IS the extractor.
* **Narrative beat (my paraphrase):** The shopkeeper warns him not to sell the last one.
* **Measured:** luma **68.0**/255 (P5 8, P95 232) · saturation **0.52** · vignette corner÷centre **0.27** · bright-pixel share **11.4%** · dark-pixel share **56%** · motion **0.69** px/f · zoom divergence **+0.09** · sharpness **511**
* **Palette:** `#120d23` 52% · `#3f2b46` 20% · `#f0e6de` 11% · `#6c6cae` 8% · `#b3a8cb` 5% · `#b46f3d` 4%


## S22 · Dome lowers, tube follow, pixel-block mosaic, gold blow-out
**63.33 – 65.93 s** (frames 1901–1978, 78 frames, 2.6 s)

* **What you see:** Dome descends fully (f1921-1932) with a white rim ring; a small card/tube emerges from its top; camera TILTS UP following the tube; the sign letters TUMBLE/ROTATE and the scene breaks into a PIXEL-BLOCK MOSAIC (f1930-1944) over deep navy with a blue pipe at bottom-left; the card glows (f1936-1956) and BLOOMS to a full GOLD-WHITE BLOW-OUT (f1957-1976, peak ~f1969-1973).
* **Camera:** Whip-follow upward; peak motion 10 px/frame at 64.1 s.
* **Lighting / shadow:** Luma 43→188 in 15 frames (the film's brightest flash).
* **Depth / blur:** Abstract; no horizon.
* **Characters & expression:** —
* **Transition out:** Gold blow-out dissolves (f1976-1992) into the morning ward with a blue-white light smear.
* **Narrative beat (my paraphrase):** He sells it anyway, and it pays for everything.
* **Measured:** luma **90.2**/255 (P5 39, P95 206) · saturation **0.47** · vignette corner÷centre **0.36** · bright-pixel share **13.6%** · dark-pixel share **42%** · motion **1.46** px/f · zoom divergence **+0.48** · sharpness **283**
* **Palette:** `#14112a` 43% · `#43365b` 17% · `#d9bc8d` 14% · `#9b7b65` 12% · `#f4e9d7` 9% · `#9590bf` 5%


## S23 · Cured brother wakes, hair springs up (warm, bokeh)
**65.93 – 71.20 s** (frames 1979–2136, 158 frames, 5.3 s)

* **What you see:** Wide: tiny brother in bed, eyes closed, HAIR LIMP/FLAT (f1979-1992); camera PUSHES IN. He wakes (eyes open f2001-2004), SITS UP (f2005-2016) and his HAIR SPRINGS INTO SPIKES (f2008-2012). Expressions: toothy grin (f2009-2028) -> beaming with both arms up behind head, 'cured' pose (f2029-2043) -> hand on hip + wink (f2044-2048) -> neutral talking; mouth wide 'O' when asking (f2097-2112) -> squeezed-eye affectionate smile (f2116-2130); he holds a small card/polaroid. Background heavily blurred wall of get-well drawings, royal-blue window mullions, red bedspread, frog plush at the bed-head.
* **Camera:** Near-static, shallow DOF, hand-held-calm.
* **Lighting / shadow:** Honey light on cream; blue edges; luma 142; bloom 19 %.
* **Depth / blur:** **Extreme shallow DOF** — background is pure bokeh.
* **Characters & expression:** Brother: frown → beaming → ecstatic open grin → excited 'o'.
* **Transition out:** FACE-MATCH CROSS-DISSOLVE (f2137-2143): the brother's face ghosts onto Jerry's face at the same screen position as warm cream flips to cold cobalt.
* **Narrative beat (my paraphrase):** A week later the brother sits up, cured, and asks for the frog story.
* **Measured:** luma **139.9**/255 (P5 33, P95 223) · saturation **0.46** · vignette corner÷centre **0.46** · bright-pixel share **17.7%** · dark-pixel share **7%** · motion **0.36** px/f · zoom divergence **-0.00** · sharpness **727**
* **Palette:** `#e3c192` 47% · `#9d8a92` 15% · `#353f8b` 15% · `#871b1f` 10% · `#2e1a24` 8% · `#b67e3d` 5%


## S24 · Cold flip: Jerry's eyes go hollow; brother's hurt face; ending hold
**71.20 – 77.80 s** (frames 2137–2334, 198 frames, 6.6 s)

* **What you see:** Cold cobalt close-up of Jerry (pale lavender, hair muted). Ring-eyes + wavy confused mouth (f2145-2150), dash-line blinks (f2154-2158, f2173-2175), faint smile (f2177-2189). A ball-hand brings a white polaroid in from the left (f2192-2208). From f2203 his ring-eyes become simple empty DOTS. The camera pans/dollies so Jerry slides RIGHT and the small WARM brother appears bottom-left with the polaroid (f2209-2232), then rests his cheek on his hand (f2233-2250); his eyes turn squiggly/confused (f2257-2284) and then SAD/HURT with a frown (f2285-2334) while Jerry stares past him. Faint diagonal window light shafts from f2265.
* **Camera:** Very slow push-in then total freeze (last 30 frames identical).
* **Lighting / shadow:** Cold cobalt key on Jerry vs warm honey on brother — the emotional punchline.
* **Depth / blur:** Jerry in sharp foreground; brother mid; bokeh behind.
* **Characters & expression:** Jerry: ring-eyes -> dot-eyes (hollow). Brother: cheerful -> confused -> hurt.
* **Transition out:** No exit: the final shot holds with the brother's hurt face (motion ~0).
* **Narrative beat (my paraphrase):** Irony payoff: the hero no longer remembers who the boy is.
* **Measured:** luma **86.8**/255 (P5 17, P95 213) · saturation **0.63** · vignette corner÷centre **0.38** · bright-pixel share **8.2%** · dark-pixel share **18%** · motion **0.62** px/f · zoom divergence **-0.16** · sharpness **446**
* **Palette:** `#1e319b` 38% · `#17173b` 20% · `#857c9c` 15% · `#debe95` 13% · `#893027` 8% · `#c6cef2` 5%
