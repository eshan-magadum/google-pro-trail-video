---
name: every-memory-25d-video
description: Complete v3.0 30-FPS forensic analysis of BOTH "Every Memory Has a Price.mp4" (2,334 frames) and "Why Samurai Feared The Flying Thunder.mp4" (1,772 frames), Tactile Tri-Channel PBR Texture + 3D Freestyle Ink + Painterly Character Shading engine, Single-Frame Detail Standard, and Three.js + Canvas2D + FFmpeg pipeline to recreate vertical short-form animated stories from any script or SRT.
---

# 2.5D Hybrid Code Video Skill (v3.0 — Tactile PBR, 3D Ink & Painterly Studio Edition)

Use this skill whenever the user provides a **script, transcript, SRT, story idea, or plan** and asks to **plan, design, or generate a vertical (9:16) 30-FPS animated video in this exact 2.5D style using code** (Three.js 3D lit dioramas + procedural tri-channel PBR textures + 3D Freestyle ink outlines + Canvas2D painterly cel-shaded characters + headless Chromium WebGL2 + RGB-safe FFmpeg grading).

## Core Visual Truth (Validated Across Two Full Reference Shorts + 1:1 Surface Microscopy)
Both *Every Memory Has a Price* (`77.8s`, nocturnal/emotional) and *Why Samurai Feared The Flying Thunder* (`59.1s`, historical/action) prove that viral 2.5D Shorts rely on **FIVE non-negotiable pillars**:
1. **Richly Dressed 3D Diorama Worlds (NEVER Sparse Primitives or Empty Voids):** Wide-angle vertical perspective (`46–72°` vFOV), painted multi-layer atmospheric cloud skyboxes (`makePaintedCloudSkyDome`), textured rutted/foliage terrain (`scatterInstancedGrassTufts`) or ornate interior dressing (`>= 15 bespoke props` per set: patterned rugs, racks, crates, lanterns, hanging banners, doorways), real shadow-casting directional + warm practical point lights, and `>= 2` 3D foreground occluders per wide shot. Even physics/mechanism cutaways stay staged **inside the live 3D environment**, never inside an empty solid-color void!
2. **Tactile Tri-Channel PBR Surfaces + 3D Ink Outlines (NEW in v3.0 — ZERO Flat-Color Plastic Meshes!):** Every visible hero/midground 3D mesh MUST carry procedural **`map` + `bumpMap` + `roughnessMap`** (`starter_code/engine/pbr_materials.js` — weathered wood grain & knots, brushed/riveted brass & iron patina, diagonal twisted coils/rope, mossy chiseled stone masonry, draped woven cloth, layered foliage) plus **Blender-Freestyle 3D ink crease outlines (`addInkOutlines`)**, **real-time `PCFSoftShadowMap` shadows**, and subtle **baked corner AO**.
3. **Painterly Multi-Angle 2D/2.5D Cel Characters & Tactile Costumes (UPGRADED in v3.0):** Oversized round heads with multi-stop spherical cel+airbrush shading + paper tooth, thick `#120E1E` ink outlines, **multi-layered hand-inked hair locks** (root shadows + internal ink strands + curved specular highlights via `drawLayeredHairLocks`), rubber-hose stick limbs with round ball-hands (zero fingers), **woven/folded tactile clothing** (`applyClothWeaveAndFolds` + lapel/belt cast shadows + stitched hems), aged parchment/glass printed props, and **multi-angle body acting** (front, 3/4 lean, back-of-head turn, crouch/land, sit/lie).
4. **Natural Warm-vs-Cool Lighting Contrast (Do NOT Over-Blue Every Scene!):**
   - **Nocturnal Gloom / Sci-Fi / Horror (`Every Memory` mode):** Lifted saturated indigo shadows (`P05 RGB ~20,19,43`) contrasted with warm amber practical pools & red story signals.
   - **Historical / Daylight / Firelight / Warm Interiors (`Samurai` mode):** Natural warm twilight charcoal-violet shadows (`P05 RGB ~32,27,36`) contrasted with rich warm firelight, Edison lamps, wood, brass, and crimson-gold textiles (`P90 warmth R-B = +27 to +60`, practical bloom `~1.5–2.5%`).
5. **Zero Hard Cuts + High Visual Beat Density (`16–22` beats per 60 s) + Unified Paper Tooth:** Fresh camera angle, action beat, or visual reveal every **`2.0–3.5 seconds`**, linked seamlessly via the 5 zero-hard-cut transition families, finished with a subtle `2.5%` screen-space organic paper/film tooth overlay (`makePaperToothCanvas`) uniting 3D and 2D layers.

---

## Package Contents (v3.0 Read Order)
| File | Purpose |
|---|---|
| `references/01_Style_DNA_and_Technical_Spec.md` | Measured 2,334-frame technical fingerprint, color tokens, 16 style pillars, anti-patterns |
| `references/02_3D_vs_2D_Layer_Architecture.md` | **Dedicated 3D-vs-2D Planner:** exact rules for 3D sets/occluders vs 2D cel rigs/print props |
| `references/03_Frame_by_Frame_Master_Analysis.md` | Exhaustive 30-FPS breakdown of all 24 scenes in *Every Memory Has a Price* |
| `references/04_Camera_Motion_and_24_Transitions.md` | Motion physics, parallax, easing curves, and all 5 zero-hard-cut transition families |
| `references/05_Lighting_Color_Blur_and_Gloom.md` | Shadow-lift math, saturation, DOF blur profiles, bloom, vignette, light-signal cues |
| `references/06_Characters_Acting_and_Rig_Spec.md` | Proportions, line weights, full eye/brow/mouth/hair emotion state machine, limb kinematics |
| `references/07_Story_Structure_Pacing_Captions_Audio.md` | 8-act narrative curve, 2.8–2.9 wps pacing, 1–2 word caption geometry, `-14.1 LUFS` audio spec |
| `references/08_Transcript_to_Video_Planning_Guide.md` | Step-by-step workflow turning any user script/SRT into a complete production plan |
| `references/09_Second_Reference_Samurai_Audit_and_Video_Quality_Gap.md` | 30-FPS forensic audit of *Why Samurai Feared The Flying Thunder* (`1,772 frames`) & quality-gap diagnosis |
| `references/10_Single_Frame_Detail_Standard_for_Full_Videos.md` | Modular per-world architecture, 15-prop budget, anti-bluing palette rules, multi-angle acting & Stage 4B gate |
| `references/11_Tactile_PBR_Textures_3D_Ink_and_Painterly_Characters.md` | **NEW (v3.0):** 1:1 surface microscopy audit + mandatory tri-channel PBR (`map+bumpMap+roughnessMap`), 3D Freestyle ink outlines, real-time shadows, layered hair & woven/folded character cloth rules |
| `templates/` | `project_plan_template.md`, `3d_2d_layer_matrix_template.csv`, `shot_list_template.csv`, `caption_timeline_template.csv`, **`scene_detail_budget_checklist.csv` (v3.0)** |
| `starter_code/` | Working 2.5D Three.js + Canvas2D + Chromium + FFmpeg engine, **`engine/pbr_materials.js` (NEW v3.0)**, `engine/environment_helpers.js`, and **v3.0 `verify_video.py`** |
| `data/` | `frame_metrics_30fps_2334.csv`, `samurai_metrics_30fps_1772.csv`, `samurai_vs_emhap_vs_ours_comparison.json`, `texture_microscopy_metrics.json` **(NEW v3.0)**, `audio_envelope_30fps.csv`, `scene_summary_24_scenes.json`, `analysis_dashboard.png` |
| `assets/` | Visual proof atlas for *Every Memory*, `assets/samurai_reference/`, and **`assets/texture_audit/texture_microscopy_audit.png` (NEW v3.0)** |

---

## Mandatory 8-Stage Production Workflow (v3.0)

**Never skip Stages 1–4B when producing a full 10–75 s video:**

1. **Stage 1 — Transcript / SRT & Pacing Audit** (`references/07` & `08`):
   - Sync to exact SRT timestamps (or pace at `2.8–2.9 words/sec`), plus optional `1.0 s` (30-frame) frozen final hold.
   - Design **`16–22` distinct visual beats per 60 s** (`1` fresh camera angle, staging, or physical action every `2.0–3.5 s`).
2. **Stage 2 — 3D vs 2D Layer Plan, Prop & PBR Material Budget** (`references/02`, `10`, `11` + `templates/scene_detail_budget_checklist.csv`):
   - Assign every visual element to 3D Background, 3D Lighting, 3D Foreground Occluders, 2D Cel Rigs, 2D Print Props, or 2D VFX.
   - Commit to **`>= 15` bespoke props**, **`>= 3` ground surface layers**, **`>= 2` foreground occluders**, **`>= 2` HDR practical lights**, a **painted skybox / dressed ceiling**, and **ZERO flat-color 3D meshes** (every mesh assigned a tri-channel PBR material + 3D ink outlines on hero props!).
3. **Stage 3 — Camera, Palette Mode & Zero-Hard-Cut Transition Plan** (`references/04`, `05`, `09`):
   - Select appropriate palette mode per scene (`twilight_warm` / `warm_interior` / `gloom_indigo` / `cold_cobalt`) — **never tint warm/daylight scenes neon blue!**
   - Assign one of the 5 zero-hard-cut transition families to every seam.
4. **Stage 4A — Modular Per-World Build Using `pbr_materials.js` + `environment_helpers.js`** (`references/10`, `11`):
   - **Split every location into its own `worlds/world_<name>.js` (`>= 250 lines`)**.
   - Use `makeWoodPBR`, `makeBrushedMetalPBR`, `makeTwistedCoilPBR`, `makeWeatheredStonePBR`, `makeWovenClothPBR`, `makeFoliagePBR`, `addInkOutlines`, and `PCFSoftShadowMap`.
   - Build multi-angle painterly character rigs using `drawLayeredHairLocks` and `applyClothWeaveAndFolds`, plus weathered parchment/glass textures on printed dials/gauges, and composite subtle `makePaperToothCanvas` paper grain.
5. **Stage 4B — MANDATORY Full-Resolution Per-Scene Single-Frame Detail & Texture Gate** (`references/10`, `11`):
   - Render **ONE FULL-RESOLUTION (`720×1280` or `1080×1920`) PNG per scene**.
   - Inspect **every single full-res scene PNG individually** (checking BOTH composition AND close-up surface texture!) and run `python3 verify_video.py --audit-frame scene_XX.png` requiring **`edge_pct >= 12.0%`** (target `15–22%`) and accurate warm/cool temperature BEFORE rendering video chunks!
6. **Stage 5 — Deterministic Resumable Chunked 30-FPS Render** (`starter_code/render_frames.mjs`):
   - Render in parallel chunks across workers matching CPU cores, piping raw RGBA into `ffmpeg` (`libx264`, `yuv420p`, `bt709`, `+faststart`).
7. **Stage 6 — RGB-Safe Look-Grade, Bloom & Audio Mastering** (`starter_code/grade_and_finish.sh`):
   - Convert to `format=gbrp` before FFmpeg screen-blend bloom; when audio is enabled, master to **`-14.1 LUFS`, `LRA 1.9–2.5 LU`, `True Peak <= -1.5 dBTP`**.
8. **Stage 7 — Full-Video Automated QA Gate** (`starter_code/verify_video.py`):
   - Verify 9:16 resolution, constant `30.00 fps`, **zero hard cuts**, **whole-video `edge_pct >= 12.0%`**, warm-vs-cool dynamic range (`P90 warmth > 0` for twilight/warm modes), practical bloom (`>= 0.15%`), lifted shadows, vignette, freeze hold, and loudness.

---

## Non-Negotiable Technical Guardrails (v3.0)
- **NEVER ship flat untextured `MeshStandardMaterial({ color })` on hero/midground 3D objects** — ALWAYS attach procedural `map` + `bumpMap` + `roughnessMap` (`pbr_materials.js`) + `addInkOutlines` on hero geometry + `PCFSoftShadowMap`!
- **NEVER ship flat unshaded single-polygon character hair or flat solid-rectangle character clothes** — ALWAYS render layered inked hair locks (`drawLayeredHairLocks`), woven cloth grain & drapery folds (`applyClothWeaveAndFolds`), collar/belt cast shadows, and subtle paper tooth!
- **Never render a full video with sparse rooms (`edge_pct < 12%`) or empty solid-color cutaway voids.**
- **Never drown warm interiors, firelight, or daylight skies in monotonous blue (`P90 warmth < 0`).**
- **Never use stiff front-facing-only paper cutouts for every scene** — animate 3/4 turns, back-of-head turns, crouching/leaning, and real 3D prop interaction.
- **Never lower `UnrealBloomPass` threshold below `0.85–0.92`** so 2D/3D black ink lines and fine PBR micro-textures stay razor-sharp while practical lamps, fires, sparks, and signs bloom cleanly.
- **Never crush shadows to pure black `#000000`, never add hard cuts, and never put fingers on ball-hands.**
