"""Per-frame measurement of every frame of Video-95754.mp4.
Outputs per_frame_metrics.csv + scene cut list + timeline png."""
import cv2, numpy as np, glob, csv, json, os
FR = sorted(glob.glob("/tmp/v95/full/f*.jpg"))
FPS = 2997 / 100
OUT = "/tmp/v95/data"; os.makedirs(OUT, exist_ok=True)
rows = []; prev_g = None; prev_h = None; prev_small = None
for i, p in enumerate(FR):
    im = cv2.imread(p); H, W = im.shape[:2]
    g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(im, cv2.COLOR_BGR2LAB)
    b, gg, r = [im[..., k].astype(np.float32) for k in range(3)]
    luma = g.astype(np.float32)
    sat = hsv[..., 1].astype(np.float32)
    # hue mean weighted by saturation (circular)
    hue = hsv[..., 0].astype(np.float32) * 2 * np.pi / 180
    wgt = sat / 255.0
    hx, hy = (np.cos(hue) * wgt).sum(), (np.sin(hue) * wgt).sum()
    hue_deg = (np.degrees(np.arctan2(hy, hx)) % 360)
    edges = cv2.Canny(g, 80, 160)
    sharp = cv2.Laplacian(g, cv2.CV_64F).var()
    # vignette: centre vs corners
    c = luma[H//3:2*H//3, W//3:2*W//3].mean()
    k = np.concatenate([luma[:H//8, :W//6].ravel(), luma[:H//8, -W//6:].ravel(), luma[-H//8:, :W//6].ravel(), luma[-H//8:, -W//6:].ravel()]).mean()
    hist = cv2.calcHist([hsv], [0, 1], None, [30, 16], [0, 180, 0, 256]); cv2.normalize(hist, hist)
    small = cv2.resize(g, (180, 320))
    diff = flow_mag = flow_dx = flow_dy = 0.0; hist_corr = 1.0; zoom = 0.0
    if prev_g is not None:
        diff = float(np.abs(small.astype(np.float32) - prev_small.astype(np.float32)).mean())
        hist_corr = float(cv2.compareHist(prev_h, hist, cv2.HISTCMP_CORREL))
        fl = cv2.calcOpticalFlowFarneback(prev_small, small, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        flow_dx, flow_dy = float(np.median(fl[..., 0])), float(np.median(fl[..., 1]))
        flow_mag = float(np.linalg.norm(fl, axis=2).mean())
        # zoom estimate: divergence of flow relative to centre
        yy, xx = np.mgrid[0:320, 0:180].astype(np.float32)
        rx, ry = xx - 90, yy - 160; rn = np.sqrt(rx**2 + ry**2) + 1e-3
        zoom = float(((fl[..., 0] * rx + fl[..., 1] * ry) / rn).mean() / (rn.mean()) * 100)
    top = luma[:int(H*0.12)].mean(); bot = luma[int(H*0.88):].mean()
    rows.append(dict(frame=i + 1, t=round(i / FPS, 3), luma=round(luma.mean(), 1), luma_p5=float(np.percentile(luma, 5)),
                     luma_p95=float(np.percentile(luma, 95)), contrast=round(luma.std(), 1), sat=round(sat.mean(), 1),
                     hue_deg=round(float(hue_deg), 0), R=round(r.mean(), 1), G=round(gg.mean(), 1), B=round(b.mean(), 1),
                     warmth=round(float(r.mean() - b.mean()), 1), lab_a=round(float(lab[..., 1].mean() - 128), 1),
                     lab_b=round(float(lab[..., 2].mean() - 128), 1), edge_density=round(float((edges > 0).mean() * 100), 2),
                     sharpness=round(sharp, 0), vignette=round(float(c - k), 1), top_luma=round(top, 1), bot_luma=round(bot, 1),
                     frame_diff=round(diff, 2), hist_corr=round(hist_corr, 3), flow_mag=round(flow_mag, 2),
                     flow_dx=round(flow_dx, 2), flow_dy=round(flow_dy, 2), zoom_idx=round(zoom, 3)))
    prev_g, prev_h, prev_small = g, hist, small
keys = list(rows[0].keys())
with open(f"{OUT}/per_frame_metrics_all_frames.csv", "w", newline="") as f:
    w = csv.DictWriter(f, keys); w.writeheader(); w.writerows(rows)
# cut detection
cuts = [1]
for r in rows[1:]:
    if (r["hist_corr"] < 0.55 and r["frame_diff"] > 12) or r["frame_diff"] > 30:
        if r["frame"] - cuts[-1] > 4: cuts.append(r["frame"])
json.dump({"fps": FPS, "frames": len(rows), "candidate_cuts": cuts}, open(f"{OUT}/candidate_cuts.json", "w"), indent=1)
print("frames", len(rows), "cuts", len(cuts), cuts)
# timeline chart
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
t = [r["t"] for r in rows]
fig, ax = plt.subplots(5, 1, figsize=(16, 12), sharex=True)
for a, kk in zip(ax, ["luma", "sat", "warmth", "flow_mag", "frame_diff"]):
    a.plot(t, [r[kk] for r in rows], lw=.8); a.set_ylabel(kk)
    for cfr in cuts: a.axvline((cfr - 1) / FPS, color="r", lw=.4, alpha=.5)
ax[-1].set_xlabel("seconds"); plt.tight_layout(); plt.savefig(f"{OUT}/timeline_all_frames.png", dpi=80)
