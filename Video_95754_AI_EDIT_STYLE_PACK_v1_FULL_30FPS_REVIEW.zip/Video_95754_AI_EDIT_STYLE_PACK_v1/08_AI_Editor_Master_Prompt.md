# 08 — AI EDITOR MASTER PROMPTS & QA CHECKLIST

Copy and paste the prompts below when uploading **this ZIP pack + your new raw talking-head video** to an AI video editor / coding agent (Claude, GPT/Astra, Gemini, Remotion agent, etc.).

---

## PROMPT 1 — Master Director & Editor Brief (paste first with the ZIP + raw video)
```text
You are an expert short-form AI video director and motion-graphics engineer.
I have uploaded:
1. A reference style pack ZIP (`Video_95754_AI_EDIT_STYLE_PACK.zip`) containing a complete 30-FPS frame-by-frame reverse-engineering of `Video-95754.mp4` (1,093 frames, 18 shots, 72 caption chunks).
2. My new raw talking-head video (and/or script).

Before writing any code or rendering anything:
1. Read `00_START_HERE.md`, `01_Edit_DNA_Style_Bible.md`, `03_Animation_Motion_Library.md`, `04_Captions_and_Typography.md`, `05_Script_to_Visual_Method.md`, `06_Color_Lighting_Illustration_Style.md`, `07_Audio_Pacing_Rhythm.md`, and `edit_decision_list.json`.
2. Inspect the visual reference frames in `reference_frames/` and the cut strips in `transitions/`.

Your task is to edit my raw video to the EXACT same production quality, visual clarity, and smooth 30-FPS motion as `Video-95754.mp4` by following every rule in the pack:

A. AUDIO & PACING PREP
- Transcribe my raw video with word-level timestamps and trim out dead air / pauses > 150 ms so the narration flows at ~200–215 WPM.
- Normalize audio to -14.1 LUFS integrated, LRA < 2.5 LU, true peak -0.9 dBFS.
- Break the script into 15–22 visual beats (average shot length ~2.0 s, range 0.3–4.1 s). Every single cut MUST be a hard cut landing within 0–2 frames of a key word onset.

B. 3-LAYOUT ARCHITECTURE (720×1280 or 1080×1920 at 30 FPS)
- Alternate between the 3 layouts in `01_Edit_DNA_Style_Bible.md`:
  • `SPLIT` (~33% of runtime): Top 50% (y: 0..50%) = animated graphic; Bottom 50% (y: 50%..100%) = consistent medium crop of the speaker. Hard horizontal seam at y = 50% with NO border.
  • `FULL_GFX` (~54% of runtime): Full-screen animated graphic (speaker hidden). Hero subject in upper 2/3 (y ~ 35%–45%); bottom 30% is floor/desk/water/stage/rays.
  • `FULL_SPEAKER` (~12.5% of runtime): 1.75x punch-in on the speaker's face for signpost pivots ("For example,", "And it doesn't just...") and the final CTA.
- Never put two `SPLIT` shots back-to-back or two `FULL_SPEAKER` shots back-to-back.
- Choose `SPLIT` or `FULL_SPEAKER` whenever the speaker makes a strong physical hand gesture (pointing, pressing down, tapping temple, air-quotes) and sync the graphic event to that gesture frame.

C. 4 VISUAL WORLDS & SCRIPT-TO-METAPHOR TRANSLATION
- Follow `05_Script_to_Visual_Method.md`: turn every sentence into a concrete visual metaphor with a clear cause-and-effect state change (before -> action -> payoff).
- Use the 4 illustration worlds from `06_Color_Lighting_Illustration_Style.md`:
  • World A (Clean Product UI / Dark Editorial Document): white rounded cards (`#FFFFFF`, radius 18px, soft shadow), terracotta accent `#E8743B`, or dark document `#100F0B` with cream serif text and lavender `#7E82E8` blockquote rule + highlight box.
  • World B (Glossy 2.5D Infographic): low-poly faceted iceberg / layered diagram in cyan-to-navy water (`#3BD4F5` -> `#091F55`) with warm internal peach bloom (`#FFB870`) and 3D Fluent-style icons + bold navy sans labels (`#0E224D`).
  • World C (Flat Retro Editorial Cartoon): uniform 6px espresso-black outlines (`#1E1612`), cream diagonal-dash wallpaper (`#F8EFD8`), burnt-orange/rust desk band (`#D96B1F` / `#9C440B`) or purple theatre curtain (`#290F31`) or green cutting mat (`#1B5E3C`) or rotating royal-blue sunburst (`#033BB7` / `#2F6AE0`). Use Bold Italic Serif for all in-world skill/prompt/expert titles.
  • World D (Moody Night-to-Amber Discovery): `#0E0B1D` night sky warming to `#6E4832` amber as a searchlight beam ignites hanging Edison bulbs.
- Alternate dark/cool and bright/warm backgrounds across cuts so adjacent shots always have strong luma or colour-temperature contrast.

D. SMOOTH 30-FPS MOTION PRIMITIVES (`03_Animation_Motion_Library.md`)
- Nothing is ever static: every shot has continuous ambient motion (2–4% camera push/pull, sine float `±5px`, rotating sunburst rays, or drifting dust/caustic particles).
- Implement animations using the exact primitives P01–P26:
  • P01 Typewriter input at 1.2–1.5 frames/character with blinking caret.
  • P02 4-frame red strike-through (`#E03E2D`) before clearing bad text.
  • P03 4-frame mint highlighter sweep (`#8FE3B4`) on good keywords.
  • P04 SVG stroke-dashoffset red marker wavy underline + circle.
  • P06–P07 3D keycap press (`⌘V`) + spring-drop pasted card that pushes existing text down.
  • P09–P12 Grey-to-colour (30% -> 100%) sequential icon + label reveals with spring pop (`0.88 -> 1.08 -> 1.00`) spaced 12–13 frames apart (or 5 frames for checklists).
  • P11 Thin expanding pulse rings (10–16 frames, radius 20 -> 300px, opacity 0.9 -> 0) on every impact, paste, stamp, bulb ignition, and seal.
  • P15–P17 Gold verified seal stamp (4 frames, scale 1.45 -> 1.0) + diagonal shine sweep + 35-particle gravity confetti burst.
  • P18–P22 Smooth ease-in-out camera moves inside graphics (document zoom-out, iceberg underwater vertical pan, 3D door swing + walk-through zoom, 8-frame 3D Y-axis card flip, magnifying glass with 1.35x lens distortion).

E. WORD-SYNCED CAPTION CHIP & CTA (`04_Captions_and_Typography.md`)
- Chunk the transcript into 1–3 word chunks (never 4+ words; ~35% 1-word punch words, ~50% 2-word phrases, ~15% 3-word function groups; median duration 14 frames).
- Render in a single-line centred charcoal pill (`rgba(55,55,60,0.78)`, radius 15px, padding `10px 22px`), Inter/SF Pro Bold 45px (at 720w), pure white `#FFFFFF` with subtle dark stroke/shadow.
- Position the chip dynamically by layout:
  • In `SPLIT`: centred at `y = 49.4%` (`y = 632` at 1280h) directly ON the split seam.
  • In `FULL_GFX` and `FULL_SPEAKER`: centred at `y = 66.4%` (`y = 850` at 1280h).
- Caption transitions are instant 0-frame swaps synced to word onsets.
- In the final CTA shot (`FULL_SPEAKER`), when the speaker says the comment keyword, pop on a giant white Bold Display Serif `“KEYWORD"` (~94px at 720w, drop shadow `0 6px 18px rgba(0,0,0,0.85)`) at `y = 74.6%` (`y = 955` at 1280h) below the normal caption chip, and hold it until the last frame.

First, output a complete `edit_decision_list.json` for my new video following the exact schema of the reference `edit_decision_list.json`. Then build and render the full 30-FPS video.
```

---

## PROMPT 2 — Negative Prompt / Hard Constraints (paste if the AI drifts)
```text
STRICT NEGATIVE RULES — DO NOT DO ANY OF THESE:
1. NO transition effects between shots (no cross-dissolves, no whip-pans, no zoom blurs, no glitch transitions). Every cut between shots is a 0-frame hard cut on a word onset. All camera motion happens INSIDE shots.
2. NO stock video or photoreal AI video clips. Every visual overlay is crisp vector/2.5D UI or editorial illustration from Worlds A, B, C, or D.
3. NO static slides. Every single frame of a graphic must have active motion (camera drift, typing, bobbing, rotating rays, moving belt, or multi-stage state change) AND a new micro-event at least every 15 frames (0.5 s).
4. NO karaoke multi-colour bouncing captions, NO emojis inside the caption chip, and NO 2-line caption wraps. The caption chip is always 1–3 words on a single line in the translucent charcoal pill.
5. NO caption position mistakes: never leave the caption at the bottom during a `SPLIT` shot (it MUST sit on the y=50% seam), and never leave it at y=50% during a `FULL_GFX` or `FULL_SPEAKER` shot (it MUST drop to y=66.4%).
6. NO generic sans-serif for in-world titles: prompt names, skill names, expert quotes, and card headers inside World C graphics MUST use Bold Italic Old-Style Serif.
7. NO outro / end-screen card. End on the `FULL_SPEAKER` CTA punch-in with the giant serif `“KEYWORD"` locked on screen so the reel loops seamlessly back into Shot 1.
```

---

## 12-Point QA Checklist (verify before accepting a rendered output)
- [ ] **1. Frame rate & resolution:** Constant 30 FPS (or 29.97 FPS), vertical 9:16 (720×1280 or 1080×1920), no dropped or stutter frames.
- [ ] **2. Layout balance:** ~33% `SPLIT`, ~54% `FULL_GFX`, ~12.5% `FULL_SPEAKER`; no back-to-back `SPLIT` or back-to-back `FULL_SPEAKER` shots.
- [ ] **3. Cut sync:** All shot cuts land within ±2 frames of the spoken word onset.
- [ ] **4. Split seam:** `SPLIT` seam is crisp at `y = 50%` with zero border, and the speaker crop in the bottom half is identical across every `SPLIT` shot.
- [ ] **5. Caption chip spec:** 1–3 words per chunk, single line, sentence case with punctuation preserved, charcoal pill `rgba(55,55,60,0.78)`, instant 0-frame swap.
- [ ] **6. Caption Y-position switch:** `y = 49.4%` on the seam in every `SPLIT` shot; `y = 66.4%` in every `FULL_GFX` and `FULL_SPEAKER` shot.
- [ ] **7. Event density:** A visible change occurs every ≤ 15 frames (0.5 s) and a major animation payoff occurs every 30–45 frames (1.0–1.5 s).
- [ ] **8. Motion smoothness:** Easing curves match `03_Animation_Motion_Library.md` (spring pop on icons/bubbles/seals, ease-in-out on camera pans, linear on belts/rays) — no robotic linear slides on UI cards.
- [ ] **9. Pulse rings (`P11`):** Thin expanding rings fire on key impacts/activations (paste, stamp, insert, bulb light, card flip, verified seal).
- [ ] **10. Typography contrast:** Bold Italic Serif used for in-graphic titles/quotes vs clean geometric sans for UI/captions vs monospace for skill slugs.
- [ ] **11. Colour & luma wave:** Adjacent full-screen shots contrast in brightness or warmth; World C cartoons have uniform 5–7 px dark outlines `#1E1612`.
- [ ] **12. CTA lock & audio:** Giant white serif `“KEYWORD"` locks at `y = 74.6%` during the final CTA; integrated loudness is −14 ± 1 LUFS with LRA < 2.5 LU.
