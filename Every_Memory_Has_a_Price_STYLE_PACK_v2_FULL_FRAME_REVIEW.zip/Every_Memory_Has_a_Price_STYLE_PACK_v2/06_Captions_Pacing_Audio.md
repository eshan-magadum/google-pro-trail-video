# 06 — CAPTIONS, PACING, VOICE & SOUND

## Captions (measured from every frame + OCR)
| Property | Value |
|---|---|
| Position | Horizontally centred (x ≈ 360 of 720); text band y ≈ 881–925 → **~70 % down the frame** |
| Size | Text height ≈ 36–45 px at 720 × 1280 → font size ≈ **52–56 px** at 720 wide (≈ 7.5 % of frame width). At 1080 × 1920 use ≈ 80–84 px |
| Fill | Pure white (BGR 252,253,253) |
| Outline | Heavy **black stroke ≈ 4 px at 720 p** (≈ 7–8 % of font size) + faint soft drop shadow *(observed)* |
| Face | Heavy geometric/neo-grotesque bold sans (Inter ExtraBold / Montserrat ExtraBold / Arial Black class) *(observed)* |
| Case | Natural sentence case — capital only at sentence starts and names ("Kid,", "Jerry,") |
| Chunking | **1–2 words per caption** (rarely 3, e.g. "the surgery,") |
| Chunk duration | Median **0.33 s**; 10th–90th percentile 0.10–0.53 s; ≈ 218 stable chunks in 77.8 s |
| Style | Word-by-word, synced to speech; punctuation kept (commas, full stops); no emoji, no karaoke colour highlight, no background box |
| Collision handling | Captions sit over lit scenery (props/sets) — the black stroke keeps them readable on the white pool and the dark shop alike |

`data/caption_chunk_timing.csv` lists chunk start/end/duration (OCR-derived, ≈ 95 % reliable; text itself is not reproduced).

## Narration pacing
* ≈ 215–230 spoken words in 77.8 s → **≈ 2.8–2.9 words/s (≈ 165–175 wpm)**: brisk, urgent storytelling pace (OCR over-counts because chunks repeat; this figure is from a hand-reconstructed script).
* Sentences are short (6–12 words). Punchlines land at the end of a caption and the visual **changes with the meaning** (e.g. the word "pays" arrives as the extractor starts to move).
* Story structure (beat map):
  1. **0–5 s HOOK**: a stark claim + a close-up of the glowing card + a grinning stranger.
  2. **5–16 s WORLD**: rules of this society, shown in 4 locations in 11 s.
  3. **16–28 s CONTRAST**: two sides of one wall (rich vs poor), mirror structure.
  4. **28–35 s THE MECHANIC**: the gauge makes the rule visual ("the happier the memory, the more it pays").
  5. **35–47 s STAKES**: the brother's illness + the cherished frog memory.
  6. **47–59 s ESCALATION**: selling bigger and bigger — whole years — with a ledger as proof.
  7. **59–66 s CLIMAX**: the shopkeeper warns him; the final memory goes in a gold flare.
  8. **66–78 s TWIST / PAYOFF**: the cure, and the irony that the cure erased his own reason.
* The ending line is left **unfinished** (trailing "…") and the frame freezes → a loop-bait for Shorts replays.

## Scene-length rhythm
Short (0.6–0.95 s): S01, S02, S04, S05 · Medium (1.9–4.5 s): S03, S06–S16, S18, S20, S22 · Long (4.7–6.6 s): S17, S19, S21, S23, S24 → **long holds only on the emotional beats**.

## Audio (measured; I could not listen — all statements below come from measurements)
| Metric | Value |
|---|---|
| Integrated loudness | −14.1 LUFS |
| Loudness range | 1.9 LU (heavily compressed, very even) |
| True peak | −2.0 dBTP |
| RMS (mono) | ≈ −17 dBFS average |
| Spectrum | Spectral centroid mostly 300–700 Hz with 40–80 % of energy under 250 Hz → **a close, warm, bass-forward voice-over over a low-register music/ambience bed**; brighter spots (centroid 1.2–1.9 kHz) at 0 s, 18 s, 50 s, 54 s, 70 s suggest effects/stings or a lighter music moment at scene changes |
| Duration | Audio is 0.09 s longer than video (77.89 vs 77.80 s) |

**To rebuild the mix**
1. Voice-over: single, close-mic, warm male narration (EQ: gentle low-shelf +2 dB at 120 Hz, de-ess at 6–8 kHz, compression 3:1).
2. Music: low-register, slow, minor/ambient bed ~ −24 dB under the voice; allow it to swell briefly into the gold flare (65 s) and at the cure.
3. SFX: rain bed in the alley/street scenes; cash-register/odometer clicks on price counters; a "whoosh" per camera swing; a sharp electric hum when the helmet lowers; a silence-then-rise before the flare.
4. Master to **−14 LUFS, true peak ≤ −1.5 dBTP** (matches the reference and YouTube's normalisation).
