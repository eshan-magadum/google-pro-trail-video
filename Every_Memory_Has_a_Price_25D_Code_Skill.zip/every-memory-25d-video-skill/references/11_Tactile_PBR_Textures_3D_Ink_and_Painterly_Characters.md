# Reference 11: Tactile PBR Textures, 3D Ink Outlines & Painterly Characters (Skill v3.0 Standard)

## 1. Microscopic Forensic Finding (Why Objects & Characters Looked "Plain Smooth")
A 1:1 magnified surface-crop audit comparing **Every Memory Has a Price**, **Why Samurai Feared The Flying Thunder**, and our v2.0 `teleport_preview_v2` (see `assets/texture_audit/texture_microscopy_audit.png`) revealed **six specific surface-realism gaps** that separate tactile, cinematic 2.5D worlds from smooth CG primitives:

1. **Flat Solid-Color 3D Materials (`MeshStandardMaterial({ color })` without Maps):**
   - In v2.0, walls and floors had textures, **but hero 3D props** (console body/deck, brass dome, copper coils, wooden crates, pine cones, stone merlons, barrels, bench, banner) used flat single-color `MeshStandardMaterial`s with **zero `map`, zero `bumpMap`, and zero `roughnessMap`**.
   - In both references, **every visible surface** has physical tactile relief: diagonal twisted hemp rope grooves, wood knots & end-grain, spun/brushed brass rings with oxidation patina, weathered stone cracks, and woven cloth drape folds catching grazing light!
2. **Missing 3D Freestyle / Grease-Pencil Ink Linework:**
   - In *Every Memory* and *Samurai*, hero 3D props (bed frames, consoles, brass lamps, wooden chests, tent seams, gauge housings) feature crisp dark-ink `#141020` crease/contour outlines unifying 3D geometry with bold 2D inked characters.
3. **Missing Real-Time 3D Contact Shadows & Baked Corner AO:**
   - Enabling `renderer.shadowMap.enabled = true` (`THREE.PCFSoftShadowMap`) on key directional lights plus baking subtle dark edge/crevice AO into procedural textures grounds every table, console, crate, and pillar onto the floor.
4. **Flat Unshaded Character Clothes & Hair Polygons:**
   - In *Every Memory* (`44.0 s` close-up), character hair is NOT a flat orange zigzag — it consists of **overlapping hand-inked layered locks with dark root shadows, internal strand ink lines, and curved copper-gold specular highlights**.
   - In *Samurai* (`11.0 s`, `31.0 s`), clothes and armor are NOT flat solid rectangles — they feature **woven linen crosshatch grain, drapery fold shadow troughs, stitched hems, layered lapel/belt cast shadows, and subtle watercolor/paper tooth**.
5. **Sterile Vector Printed Props (Gauges, Signs, Blueprints):**
   - Reference gauges use **aged cream parchment paper grain, metallic inner bezel cast shadow, subtle printed serial details, and diagonal curved glass cover reflections** — never pure sterile digital white!
6. **Flat Geometric Nature (Cones & Solid Planes):**
   - Pine trees, rocks, and banners must use **layered needle/foliage PBR maps, mossy granite masonry PBR maps, and woven draped cloth PBR maps**, unified across the full frame by an ultra-subtle **`2.5%` screen-space organic paper/film tooth overlay**.

---

## 2. Mandatory Skill v3.0 Texture & Shading Rules
1. **ZERO Flat-Color Hero/Midground 3D Meshes:** Every visible 3D prop MUST use a **tri-channel PBR material (`map` + `bumpMap` + `roughnessMap`)** via `starter_code/engine/pbr_materials.js`:
   - Wood props -> `makeWoodPBR(...)`
   - Brass / Copper / Riveted Iron props -> `makeBrushedMetalPBR(...)`
   - Helical Copper Windings / Braided Rope -> `makeTwistedCoilPBR(...)`
   - Stone Slabs / Parapets / Pillars / Bollards -> `makeWeatheredStonePBR(...)`
   - Banners / Tents / Blankets -> `makeWovenClothPBR(...)`
   - Pine Trees / Foliage -> `makeFoliagePBR(...)`
2. **3D Freestyle Ink Outlines on Hero Props:** Attach `addInkOutlines(mesh, { thresholdDeg: 24, opacity: 0.65–0.78 })` to major structural/hero 3D meshes (consoles, crates, workbenches, battlement merlons, pillars, furniture, gauge housings).
3. **Real-Time Shadow Mapping:** Enable `renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;` on key lights (`1024×1024`, soft bias `-0.0006`), marking floors/terraces `receiveShadow = true` and major props `castShadow = true`.
4. **Painterly Layered Character Rigs:**
   - Hair MUST use `drawLayeredHairLocks(...)` (multi-lock ink strands + root shadows + curved highlights).
   - Clothing MUST call `applyClothWeaveAndFolds(...)` inside the clipped torso/coat silhouette + paint cast shadows under collars, lapels, and belts.
   - Skin/Head MUST include subtle spherical airbrush+cel shading AND subtle paper/tooth grain.
   - Printed dials/gauges MUST include aged parchment grain, inner bezel shadow ring, and diagonal glass specular highlight.
5. **Unified Organic Paper Tooth Finish:** Composite `makePaperToothCanvas(W, H)` at subtle opacity (`~0.16–0.22` over `alpha 0..14` pixels = ~2.5% screen grain) as the final atmospheric step so 3D PBR surfaces and 2D cel characters inhabit the exact same tactile illustrated film plane!
