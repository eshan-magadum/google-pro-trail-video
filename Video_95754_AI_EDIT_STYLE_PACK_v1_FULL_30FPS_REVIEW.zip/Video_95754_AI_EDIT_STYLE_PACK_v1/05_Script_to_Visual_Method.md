# 05 — SCRIPT-TO-VISUAL TRANSLATION METHOD

This is the most important file for making a **new** video at this level. The AI editor did not just slap random B-roll over the voiceover — it ran a strict **Script → Metaphor → State Change** transformation on every clause.

## 1. The complete mapping of `Video-95754.mp4`
| Shot | Spoken clause | Rhetorical role | How the editor visualized it | The state change (animation payoff) |
|---|---|---|---|---|
| **S01** | "Anthropic engineer just built the most…" | **Authority hook** | SPLIT: the actual header artwork from the engineer's blog post + a clean white `Anthropic` source pill above the speaker. | Subtle push-in on the source card while the speaker gestures. |
| **S02** | "…powerful prompt that I have ever seen," | **Show the artifact** | FULL_GFX: dark-mode close-up of the exact blockquote from the post so the viewer sees it's real. | Slow drift/push-in; holds long enough to read the first lines. |
| **S03** | "…but nobody is using it." | **Scarcity / hidden gem** | FULL_GFX: camera zooms out to the whole long essay to show the prompt is *buried* at the bottom. | Fast pull-out + scroll, then a purple highlight box draws around the small paragraph. |
| **S04** | "When prompting, most of us just describe the task." | **Common mistake ("surface level")** | SPLIT: a Claude chat box sitting on the **tip of an iceberg** above water, typing a generic task (`Make a slide deck for our Q3 review.`). | Typewriter animation on the surface tip while suggestion chips float on little ice floes. |
| **S05** | "Well, in fact, we should be using the deeper meaning behind the prompt." | **Core thesis ("go deeper")** | FULL_GFX: camera **dives underwater** down the massive hidden body of the iceberg, where the 4 steps of the prompt live inside the ice. | Continuous vertical pan down + warm internal glow + 4 grey icons light up in 3D colour one by one every 13 frames. |
| **S06** | "For example," | **Signpost / reset** | FULL_SPEAKER: 0.67 s punch-in on the speaker's face. | Hand rises to introduce the example (cleans the visual palate before switching art styles). |
| **S07a** | "instead of saying to Claude, 'fix this bug'," | **Bad example (symptom-chasing)** | FULL_GFX (World C cartoon): typing `fix this bug` while a hand with a **fly-swatter** smashes ladybugs on a phone screen. | Swatter slams 3× → screen glass **cracks** more each time → bugs multiply → red strike-through crosses out `fix this bug`. |
| **S07b** | "say to Claude, 'keep this app bug-free'." | **Good example (system-level goal)** | Same scene: retypes `keep this app bug free` and highlights `bug free` in green. | Golden sparkles + mint shockwave ring heal the cracks, knock bugs off, drop the swatter onto the desk, and leave a green shield around the phone. |
| **S08** | "Paste this prompt in before any task." | **How to use it (single action)** | SPLIT (World A UI): giant 3D `⌘` + `V` keycaps above a task prompt (`Plan our product launch.`). | Keycaps depress with an orange glow → `✳ be-ambitious` card (blurred body) drops in and pushes the task down + peach pulse ring. |
| **S09** | "And that's why this Anthropic skill is so powerful." | **Hype / power metaphor** | FULL_GFX (World C cartoon): a `SKILL.md / be-ambitious` cartridge hovering over an orange retro power-console. | Anthropic badge stamps onto cartridge → cartridge slots in → 6 LEDs fill → needle pins into the red → machine vibrates with lightning + rotating sunburst rays. |
| **S10** | "Just paste it in before any task," | **Scale / repeatability** | SPLIT (World A UI): an automated **stamp press** above a **conveyor belt** of different tasks (`Q3 review deck`, `Launch email`, `Checkout bug`, `Product roadmap`). | Belt scrolls continuously; press slams every 24 frames, stamping an orange `✳ be-ambitious` tab onto every passing card. |
| **S11** | "and it tells you what a top…" | **Anticipation / access** | FULL_GFX (World C theatre): a spotlighted wooden stage door with a brass `Expert` plaque. | Door swings open in 3D, flooding with blinding light + god-rays, and the camera rushes through the doorway. |
| **S12** | "…expert would say," | **Personification** | FULL_GFX: a cartoon grey-bearded professor at a Claude-branded lectern under the spotlight. | Raises index finger → speech bubble pops in (`Reproduce it first.`) → mouth flaps. |
| **S13** | "things that you would never have thought about." | **Discovery / blind spots** | SPLIT (World D night): a dark room full of unlit hanging light bulbs (`W` filaments) in the dark. | A searchlight beam sweeps across → 1 bulb lights up → then all 13 bulbs cascade on with gold rings and the whole sky warms from navy to amber. |
| **S14** | "And it doesn't just give you advice." | **Pivot / contrast setup** | FULL_SPEAKER: 1.17 s tight punch-in; speaker makes a sceptical face on "advice". | Facial expression carries the contrast before the next graphic. |
| **S15** | "It actually reviews the whole prompt," | **Inspection / critique** | SPLIT (World C desk): an index card (`Why is checkout so slow?`) on a green cutting mat. | A magnifying glass pans across with real lens distortion → a red marker draws a wavy underline under `checkout` and circles `so slow?`. |
| **S16** | "so you're getting the expert version of it." | **Transformation + reward** | FULL_GFX (royal blue sunburst): the index card **flips 180° in 3D** to become the gold-bordered `Expert version` card. | 3 checklist items light up (`Raw traces`, `Profile it`, `Load test`) → gold verified seal stamps on the corner → shine sweep + confetti burst. |
| **S17** | "(…of it.)" | **Lead-magnet preview** | FULL_GFX: 8-frame flash of a curled document `✦ The Prompt` stamped `EXCLUSIVE`. | Gives the viewer a tangible object they are about to ask for. |
| **S18** | "Want the prompt? Comment 'deeper' and I'll send it over." | **Direct CTA** | FULL_SPEAKER: tight punch-in + giant serif `“DEEPER"` locked below the caption chip, synced to air-quotes. | Holds the keyword on screen for the final 1.8 s so viewers can read and type it immediately. |

---

## 2. The 7 translation rules for ANY new script
When the AI receives a new raw video + script, it must follow this exact decision tree for every sentence:

1. **Break the script into 1.5–4.0 s visual beats (15–22 shots per 35–45 s reel).**
   - Put a **hard cut on the exact onset frame** of the key word that starts each new thought.
2. **Assign the layout using the alternation law:**
   - **Shot 1 (Hook, 0–2 s):** always `SPLIT` — show the real source / proof / headline card on top + the speaker on the bottom.
   - **Pivot / signpost phrases** (`"For example,"`, `"Here's the crazy part,"`, `"And it doesn't just..."`): use a `FULL_SPEAKER` punch-in (0.7–1.2 s) so the viewer reconnects with the human face and the next graphic hits harder.
   - **Final CTA (last 2.5–3.5 s):** always `FULL_SPEAKER` punch-in with the giant serif `"KEYWORD"` locked at `y = 955`.
   - **Everything else (~85% of the video):** alternate between `SPLIT` (when the speaker has a great hand gesture or facial reaction, or when showing a clean product UI action) and `FULL_GFX` (when a metaphor needs a full vertical stage: diving, opening a door, a cartoon machine, a 3D card flip).
3. **Never illustrate words literally when a concrete physical metaphor exists:**
   - *Surface vs depth* → **Iceberg** (chat box on the tip, dive underwater to reveal stacked layers).
   - *Quick fix vs root-cause fix* → **Fly-swatter cracking a screen** vs **green shield shockwave + dropping the swatter**.
   - *Using a template/skill power* → **Retro cartridge slotting into a machine** with LEDs, gauge needle in the red, lightning, sunburst.
   - *Applying across many tasks* → **Industrial stamp press over a moving conveyor belt** of task cards.
   - *Getting expert insight* → **Stage door labeled "Expert" swinging open into light** → **Professor at a lectern with a speech bubble**.
   - *Blind spots / ideas you missed* → **Flashlight beam in the dark igniting a cascade of hanging Edison bulbs**.
   - *Critiquing / editing text* → **Index card on a green cutting mat + magnifying glass lens pass + red marker underline & circle**.
   - *Upgrading basic to pro* → **3D Y-axis card flip** into a gold-bordered checklist + **verified seal stamp + confetti**.
   - *Giving away a resource* → **8–15 frame flash of a paper sheet titled `✦ The [Resource]` with a red `EXCLUSIVE` stamp** right before the CTA punch-in.
4. **Every quoted prompt or user action must be shown as live UI, not static text:**
   - Type it at 1.2–1.5 frames/character (`P01`), cross out bad versions with a 4-frame red bar (`P02`), highlight key words with a 4-frame green sweep (`P03`), or drop pasted blocks in with `⌘V` keycaps (`P06–P07`).
5. **Every list of 3–4 items must reveal sequentially on the spoken rhythm:**
   - Start all items as **30% opacity grey silhouettes**, then pop them into full colour one by one (`P09` + `P10` + `P11` pulse ring) spaced by 12–13 frames (for spoken points) or 5 frames (for rapid checklists).
6. **Every "before → after" contrast must happen inside the SAME world so the payoff reads:**
   - Either mutate the scene in place (S07: broken cracked phone → healed shielded phone; S13: cold dark navy room → warm lit amber room) or connect two adjacent shots with the same background (S11→S12 stage; S15→S16 card flip; S16→S17 blue sunburst).
7. **Sync graphics to the speaker's physical body language whenever in `SPLIT` or `FULL_SPEAKER`:**
   - Scan the raw video for hand raises, downward presses, temple taps, pointing, and air-quotes, and schedule the matching graphic event (paste drop, magnifier/marker, `"KEYWORD"` pop) on the exact frame the hands hit their pose.
