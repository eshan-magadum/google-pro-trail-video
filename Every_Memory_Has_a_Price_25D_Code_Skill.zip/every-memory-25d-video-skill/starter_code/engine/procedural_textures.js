// Reusable Procedural Canvas2D Textures for 3D Three.js Diorama Sets (Zero external images).
import * as THREE from 'three';
import { mulberry32 } from './hybrid_scene_base.js';

function makeCanvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}

function toTex(canvas, { srgb = true, repeat = [1, 1] } = {}) {
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat[0], repeat[1]);
  tex.anisotropy = 8;
  tex.needsUpdate = true;
  return tex;
}

export function makeBrickTextures({ seed = 101, repeat = [1, 1.4] } = {}) {
  const [c, g] = makeCanvas(512, 1024);
  const [bc, bg] = makeCanvas(512, 1024);
  const rng = mulberry32(seed);
  g.fillStyle = '#24193B';
  g.fillRect(0, 0, c.width, c.height);
  bg.fillStyle = '#2E2E2E';
  bg.fillRect(0, 0, bc.width, bc.height);

  const rows = 36, cols = 8;
  const bh = c.height / rows, bw = c.width / cols;
  for (let r = 0; r < rows; r++) {
    const off = (r % 2) * (bw * 0.5);
    for (let col = -1; col <= cols; col++) {
      const x = col * bw + off, y = r * bh;
      const v = rng();
      g.fillStyle = `rgb(${Math.round(70 + v * 32)},${Math.round(46 + v * 22)},${Math.round(88 + v * 28)})`;
      g.fillRect(x + 3, y + 3, bw - 6, bh - 6);
      const bv = Math.round(160 + v * 65);
      bg.fillStyle = `rgb(${bv},${bv},${bv})`;
      bg.fillRect(x + 3, y + 3, bw - 6, bh - 6);
    }
  }
  return { map: toTex(c, { repeat }), bumpMap: toTex(bc, { srgb: false, repeat }) };
}

export function makeWetSidewalkTexture({ seed = 303, repeat = [4, 3] } = {}) {
  const [c, g] = makeCanvas(1024, 1024);
  const rng = mulberry32(seed);
  const grad = g.createLinearGradient(0, 0, 0, 1024);
  grad.addColorStop(0, '#2C3168');
  grad.addColorStop(1, '#1E2356');
  g.fillStyle = grad;
  g.fillRect(0, 0, 1024, 1024);

  // Concrete paving slabs
  g.strokeStyle = 'rgba(12,14,42,0.55)';
  g.lineWidth = 6;
  for (let i = 0; i <= 4; i++) {
    const p = i * 256;
    g.beginPath(); g.moveTo(p, 0); g.lineTo(p, 1024); g.stroke();
    g.beginPath(); g.moveTo(0, p); g.lineTo(1024, p); g.stroke();
  }
  // Subtle damp mottling
  for (let i = 0; i < 320; i++) {
    g.fillStyle = rng() > 0.5 ? 'rgba(95,115,220,0.05)' : 'rgba(15,15,45,0.06)';
    g.beginPath();
    g.arc(rng() * 1024, rng() * 1024, 24 + rng() * 85, 0, Math.PI * 2);
    g.fill();
  }
  return toTex(c, { repeat });
}

export function makeGlowingSignTexture(title = 'MEMORIES', subtitle = 'BOUGHT & SOLD') {
  const [c, g] = makeCanvas(1024, 512);
  const grad = g.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#FFF1C8');
  grad.addColorStop(0.55, '#FFD07A');
  grad.addColorStop(1, '#E89B54');
  g.fillStyle = grad;
  g.fillRect(0, 0, 1024, 512);

  // Soft interior shelf silhouettes
  g.fillStyle = 'rgba(95,48,38,0.22)';
  for (let y = 90; y < 440; y += 85) {
    g.fillRect(48, y, 928, 14);
  }
  g.strokeStyle = '#3A1E24';
  g.lineWidth = 14;
  g.strokeRect(20, 20, 984, 472);

  g.fillStyle = '#3B1822';
  g.textAlign = 'center';
  g.font = '900 112px "DejaVu Serif", Georgia, serif';
  g.fillText(title, 512, 235);
  g.font = '700 46px "DejaVu Sans", Arial, sans-serif';
  g.fillText(subtitle, 512, 325);
  return toTex(c);
}

export function makeCubbyWallTexture({ seed = 404 } = {}) {
  const [c, g] = makeCanvas(1024, 1024);
  const rng = mulberry32(seed);
  g.fillStyle = '#12122B';
  g.fillRect(0, 0, 1024, 1024);
  const cols = 8, rows = 10;
  const cw = 1024 / cols, ch = 1024 / rows;
  for (let r = 0; r < rows; r++) {
    for (let col = 0; col < cols; col++) {
      const x = col * cw + 8, y = r * ch + 8;
      g.fillStyle = '#1F2048';
      g.fillRect(x, y, cw - 16, ch - 16);
      // Tiny glowing memory jars/chips inside ~45% of cubbies
      if (rng() < 0.45) {
        const hue = rng() < 0.6 ? '#F2B86B' : '#789EFF';
        g.fillStyle = hue;
        g.globalAlpha = 0.35 + rng() * 0.5;
        g.fillRect(x + 18, y + 20, cw - 52, ch - 42);
        g.globalAlpha = 1.0;
      }
    }
  }
  return toTex(c);
}
