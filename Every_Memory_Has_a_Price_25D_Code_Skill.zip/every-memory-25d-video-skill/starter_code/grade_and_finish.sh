#!/usr/bin/env bash
# RGB-Safe Look-Grade, Halation Bloom & -14 LUFS Mastering Script
# Fixes the classic FFmpeg YUV screen-blend magenta bug by forcing `format=gbrp` before bloom!
#
# Usage:
#   ./grade_and_finish.sh <input.mp4> <output.mp4> <mode: gloom|warm|cold> [audio.wav]
set -euo pipefail

IN="${1:?Input video required}"
OUT="${2:?Output video required}"
MODE="${3:-gloom}"
AUDIO="${4:-}"

case "$MODE" in
  gloom)
    # Lifted indigo shadows (#0F0D25), cool-violet midtones, warm practical highlights
    GRADE="colorbalance=rs=-0.06:gs=-0.05:bs=0.14:rm=-0.02:gm=-0.01:bm=0.05:rh=0.05:gh=0.02:bh=-0.04,eq=contrast=1.06:brightness=0.01:saturation=1.18:gamma=1.04"
    BLOOM_OPACITY="0.22"
    ;;
  warm)
    # Golden-hour honey memory / healed ward warmth
    GRADE="colorbalance=rs=0.04:gs=0.01:bs=-0.05:rm=0.06:gm=0.03:bm=-0.06:rh=0.08:gh=0.04:bh=-0.06,eq=contrast=1.04:brightness=0.02:saturation=1.12:gamma=1.06"
    BLOOM_OPACITY="0.26"
    ;;
  cold)
    # Final twist cold cobalt hollow grade (S24)
    GRADE="colorbalance=rs=-0.10:gs=-0.05:bs=0.22:rm=-0.06:gm=-0.02:bm=0.12:rh=-0.02:gh=0.00:bh=0.05,eq=contrast=1.07:brightness=0.00:saturation=1.22:gamma=1.02"
    BLOOM_OPACITY="0.18"
    ;;
  *)
    echo "Unknown mode: $MODE (use gloom, warm, or cold)" >&2
    exit 1
    ;;
esac

# Crucial: convert to planar RGB (gbrp) BEFORE split/blend so screen-blend never shifts neutral chroma to magenta!
VFILTER="${GRADE},format=gbrp,split[a][b];\
[b]lutyuv=y='if(gt(val,220),val,0)':u=128:v=128,format=gbrp,gblur=sigma=18[gl];\
[a][gl]blend=all_mode=screen:all_opacity=${BLOOM_OPACITY},format=yuv420p"

if [[ -n "$AUDIO" && -f "$AUDIO" ]]; then
  echo "==> Grading (${MODE}) + Mastering Audio (-14.0 LUFS / -1.5 dBTP)..."
  ffmpeg -y -loglevel error -i "$IN" -i "$AUDIO" \
    -filter_complex "[0:v]${VFILTER}[v];[1:a]loudnorm=I=-14.0:LRA=2.0:TP=-1.5[a]" \
    -map "[v]" -map "[a]" \
    -c:v libx264 -preset slow -crf 15 -r 30 \
    -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 \
    -c:a aac -b:a 128k -ar 44100 \
    -shortest -movflags +faststart "$OUT"
else
  echo "==> Grading (${MODE}, silent)..."
  ffmpeg -y -loglevel error -i "$IN" \
    -vf "$VFILTER" \
    -an -c:v libx264 -preset slow -crf 15 -r 30 \
    -pix_fmt yuv420p -colorspace bt709 -color_primaries bt709 -color_trc bt709 \
    -movflags +faststart "$OUT"
fi

echo "Done: $OUT"
