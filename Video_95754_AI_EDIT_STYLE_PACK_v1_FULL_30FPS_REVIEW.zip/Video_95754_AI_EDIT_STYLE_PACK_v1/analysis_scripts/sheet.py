"""Contact sheets: every frame, labelled with frame number + timestamp."""
from PIL import Image, ImageDraw, ImageFont
import glob, os, sys
FR = sorted(glob.glob("/tmp/v95/full/f*.jpg")); FPS = 29.97
cols, rows_ = int(sys.argv[1]), int(sys.argv[2]); tw = int(sys.argv[3]); out = sys.argv[4]
th = int(tw * 16 / 9); per = cols * rows_; os.makedirs(out, exist_ok=True)
try: font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", max(10, tw // 9))
except Exception: font = ImageFont.load_default()
for s in range(0, len(FR), per):
    sheet = Image.new("RGB", (cols * tw, rows_ * (th + 2)), (255, 0, 255))
    d = ImageDraw.Draw(sheet)
    for j, p in enumerate(FR[s:s + per]):
        im = Image.open(p).resize((tw, th)); x, y = (j % cols) * tw, (j // cols) * (th + 2)
        sheet.paste(im, (x, y)); n = s + j + 1
        lab = f"{n} {(n-1)/FPS:.2f}s"; d.rectangle([x, y, x + len(lab) * tw // 15 + 4, y + tw // 8], fill=(0, 0, 0))
        d.text((x + 2, y), lab, fill=(255, 255, 0), font=font)
    sheet.save(f"{out}/sheet_{s+1:04d}-{min(s+per, len(FR)):04d}.jpg", quality=85)
print("ok", len(FR))
