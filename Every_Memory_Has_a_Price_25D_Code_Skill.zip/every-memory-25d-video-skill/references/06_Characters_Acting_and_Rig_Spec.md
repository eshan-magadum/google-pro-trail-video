# 06 — Characters, Acting, Micro-Expressions & 2D Rig Specification

Every character in *Every Memory Has a Price* is a **flat 2D hand-drawn cel-shaded actor** mounted inside the lit 3D world (`starter_code/engine/cel_character_rig.js`). Their simplicity is intentional: oversized round heads + minimalist eyes/brows remain instantly legible at 720p mobile scale even during wide camera moves.

---

## 1. Shared Proportions & Line-Weight Ratios
| Element | Exact Ratio / Rule | Code Parameter (`1024×1536` Canvas) |
|---|---|---|
| **Head Size** | Huge circle/oval — **`40–45%` of total standing height** | `rx = 202`, `ry = 192` centered at `(512, 432)` |
| **Silhouette Ink Outline** | Thick pure-black (`#120E1E`), **`~0.9–1.1%` of video width** (`~6–8 px` at 720p; `~10–12 px` at 1080p) | `inkW = 18` at 1024w (`lineCap = 'round'`, `lineJoin = 'round'`) |
| **Interior / Prop Outlines** | Thinner ink lines (`~40–50%` of silhouette weight) | `7–9 px` for vest stripes, facial features, small props |
| **Torso** | Simple bean/oval in **1 flat primary color** + 1 graphic detail (vest stripe, necktie, hospital dots, chest badge) | Bezier bean `y = 615..985` + single shadow crescent |
| **Limbs & Hands** | **Thin rubber-hose stick arms & legs** with **round solid black ball-hands** — **ZERO fingers** | Quadratic Bezier stroke (`inkW`) + solid filled circle `r = inkW * 1.15` |
| **Face Shading** | Flat peach (`#F0DFD6`) or chalk-white + **one soft lavender crescent shadow** (`#B29CC6`) + subtle warm key rim — **NEVER 3D shading** | 2 clipped `RadialGradient`s inside head ellipse |
| **Hair** | Solid orange (`#D95B26`) with **signature dark zig-zag interior shading strokes** + 2–3 pale highlight strokes | `hairState: 'spiky'` (healthy) vs `'limp'` (sick) |
| **Nose** | **Omitted** (clean minimalist face maximizes eye & brow readability) | Do not draw noses |

---

## 2. The Visual Emotion Code (State Machine)
In this style, **character state is encoded in clean graphic symbols** rather than realistic facial muscles. Every state below is built directly into `starter_code/engine/cel_character_rig.js`:

| Signal | Graphic Shape | Exact Emotional Meaning | Observed Frames in Reference |
|---|---|---|---|
| **Double-ring eyes + small pupil** | White circle w/ ink ring + dot pupil (`eyes: 'ring'`) | **Alive, present, attentive** | Jerry `f7–f2202` |
| **Wide double-ring eyes** | Enlarged sclera + tiny dot pupil (`eyes: 'wide_ring'`) | Alarm, shock, sudden realization | Jerry `f7–28`, `f1050–1060`, `f1285`; Stranger `f1897+` |
| **One eye closed (2–6 f)** | Left dash + right ring (`eyes: 'wink_left'`) | Heavy blink, startle, nervous flinch | Jerry `f2–3`; Stranger `f1840–1846`; Brother `f2044–2048` |
| **Half-lid eyes** | Horizontal upper eyelid cutting circle (`eyes: 'half_lid'`) | Exhausted, numb, sly, smug, resolute | Rich lounger `S09`; Jerry `f1141`, `f1449`, `f1889` |
| **Flat dash / closed eyes** | Straight or softly curved line (`eyes: 'dash_closed'`) | Blink (`2–4 f`), deep sigh, serene resignation, bliss | Extractor customer `S06`; Elders `f790, f808`; Jerry `f1481–1500`, `f2154–2158` |
| **Plain EMPTY DOT eyes (no ring)** | Solid black dots only (`eyes: 'empty_dot'`) | **HOLLOW — the memory / soul is gone!** | **Jerry `f2203–f2334` (the climax visual twist!)** |
| **Squeezed-X / pinched-arc eyes** | Upward pinched arcs (`eyes: 'squeezed_x'`) | Pure affection, warmth, unconditional trust | Healed brother `f2116–2130` |
| **Squiggly eyes** | Tiny wavy squiggle inside eye (`eyes: 'squiggly'`) | Confusion, creeping hurt | Brother `f2257–2284` |
| **Wavy zig-zag mouth** | Horizontal sine/tilde stroke (`mouth: 'wavy_anxious'`) | Anxiety, dread, disoriented confusion | Jerry `f1306–1320`, `f2145–2150` |
| **Blue sweat drop at temple** | Outlined cyan teardrop (`extras.sweatDrop`) | Acute panic / pressure | Landlord `S07`; Jerry `f1302–1320` |
| **Single tear below eye** | Small pale-blue droplet (`extras.tear`) | Quiet grief / breaking point | Jerry `f1399–1405` |
| **Vertical cheek tremor lines** | 2 shaky ink arcs beside face (`extras.tremorLines`) | Unease, guilt, reluctance | Unhooded stranger `f1777–1846` |
| **Limp flat hair vs Spiky hair** | Drooping cap vs springy spikes (`hairState: 'limp'/'spiky'`) | **Sick / drained vs Healed / joyful** | Brother `f1979–2005` (limp) -> `f2008–2012` (springs spiky!) |
| **Blue-white outline halo** | Glowing lavender aura around head (`extras.drainHalo`) | Active memory drain / hollowing out | Jerry `f1607–1640` |
| **Glowing amber pupils** | Gold pupils inside dark hood (`extras.amberEyeGlow`) | Predatory greed / transaction peak | Hooded stranger `f901–948` |

---

## 3. Cast Breakdown & Recurring Motifs
1. **Jerry (Protagonist):** Spiky orange hair, mustard-yellow vest over white center stripe, **small green frog badge on chest** (visual foreshadowing of his brother's frog!), stick black legs. Carries 80% of the facial acting.
2. **Little Brother (2 Designs):**
   - *Healthy Street (S14 & S16 Lake):* Red shirt + green frog-cap + live green frog hopping onto his cap.
   - *Hospital (S15, S20, S23, S24):* Pale blue-green dotted hospital gown, matching orange hair (**limp when sick -> springs spiky when cured**), green frog plush perched on the bedpost.
3. **Hooded Stranger (Shopkeeper):** Oversized deep-navy hood with thin pale-blue rim outline, chalk-white oval face, wide toothy grin + glowing amber pupils during sales (`S03, S13`); **unhooded in S21 (`f1773–1776`)** revealing a plain, worried, sympathetic round white face with tremor lines.
4. **World Archetypes (Supporting Cast):**
   - *Deli Landlord & Woman (S07):* Brownish-grey suit + crimson tie (angry pointing, sweat drop) vs blue coat worried woman + pedaling/crashing bike kid.
   - *Rich Side (S09–S11):* Straw-hat sunglasses lounger, white-jacketed butler w/ tray, Hawaiian-shirt snorkel guy — all share smug half-lidded flat expressions.
   - *Poor Side Elders (S12):* Curly-grey elder woman w/ earrings, bald man w/ round glasses — serene blank closed-eye smiles clutching framed photos.

---

## 4. Frame-Accurate Acting Timelines

### Jerry's Complete Arc (`f0001`–`f2334`)
* `f0001–0006`: Wary squint (`f1`) -> 2-frame single-eye wink/blink (`f2–3`) -> half-lid (`f4–6`) -> wide ring eyes (`f7–28`).
* `f1050–1060`: Wide-eyed alarm catching collapsing brother.
* `f1093–1148`: Tender closed-eye smile (`f1093–1128`) -> deadpan half-lid (`f1141–1145`) -> gentle small smile (`f1148+`).
* `f1285–1325`: Wide eyes (`f1285`) -> deadpan (`f1286`) -> **wavy zig-zag mouth + sweat drop (`f1302–1320`)** -> flat dash (`f1321`) -> tiny `"o"` (`f1325`).
* `f1355–1405`: Eyes glance sideways/up (`f1355–1368`) -> **single blue tear (`f1399–1405`)**.
* `f1449–1500`: Sly half-lid (`f1449`) -> sigh eyes shut (`f1459`) -> wide neutral (`f1462`) -> **serene closed-eye resignation (`f1481–1500`)**.
* `f1513–1640`: Wide eyes -> squint (`f1537`) -> tired dash (`f1543`) -> sideways deadpan (`f1561`) -> **head droops back, eyes shut + blue-white drain halo (`f1573–1640`)**.
* `f1861–1900`: Calm blink (`f1861–1863`) -> **resolute angled brows & half-lids (`f1889–1900`)**.
* `f2143–2334`: Cold cobalt ring-eyes + wavy confused mouth (`f2145–2150`) -> flat blinks (`f2154`, `f2173`) -> **`f2203` PERMANENT SWITCH TO EMPTY DOT EYES** -> hollow blank stare past his hurt brother until final freeze (`f2305–2334`).

### Acting & Animation Economy Rules (Why It Feels Cinematic Without Complex Walk Cycles)
1. **One Clear Emotion Per Beat:** Hold each facial state `0.8–2.5 s` so viewers feel it; switch instantaneously on a spoken word or blink (`2–4 f`).
2. **The Camera & Props Do the Heavy Motion:** Characters rarely walk (only when story demands: bike crash `S07`, bouncing kid `S14`, frog leap `S16`). Instead, **camera push-ins sell decisions**, **pull-backs sell reveals**, and **props perform** (dome lowering, odometer rolling, gauge needle sweeping, ball-hand entering to press/hold/present objects).
3. **Micro-Idle Life:** Add tiny `1–2%` breathing sway or head-tilt drift (`±1.5°`) on holds so characters feel alive even when static — until the intentional 100% motionless freeze in the final `1.0 s`.
