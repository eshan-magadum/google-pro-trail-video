// Easing curves and zero-hard-cut transition math for the Every Memory Has a Price 2.5D style.
// Rule: ZERO hard cuts. Every scene boundary uses one of the 5 approved transition families.

export function clamp(x, lo = 0, hi = 1) {
  return Math.max(lo, Math.min(hi, x));
}

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function smoothstep(edge0, edge1, x) {
  const t = clamp((x - edge0) / (edge1 - edge0));
  return t * t * (3 - 2 * t);
}

export function easeInOutCubic(t) {
  t = clamp(t);
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

export function easeOutQuart(t) {
  t = clamp(t);
  return 1 - Math.pow(1 - t, 4);
}

export function easeInOutSine(t) {
  t = clamp(t);
  return -(Math.cos(Math.PI * t) - 1) / 2;
}

// Compute normalized progress u in [0, 1] for a frame within [fStart, fEnd]
export function windowProgress(frame, fStart, fEnd) {
  return clamp((frame - fStart) / Math.max(1, fEnd - fStart));
}

// 1. Camera-Led Whip-Pitch with brief Ghost Double-Exposure (Reference: T1 f25-35)
export function evalWhipPitch(frame, fStart, fEnd, poseA, poseB) {
  const u = easeInOutCubic(windowProgress(frame, fStart, fEnd));
  const ghostAlpha = Math.sin(u * Math.PI) * 0.35; // peaks mid-swing for ~3 frames
  return {
    pos: [lerp(poseA.pos[0], poseB.pos[0], u), lerp(poseA.pos[1], poseB.pos[1], u), lerp(poseA.pos[2], poseB.pos[2], u)],
    target: [lerp(poseA.target[0], poseB.target[0], u), lerp(poseA.target[1], poseB.target[1], u), lerp(poseA.target[2], poseB.target[2], u)],
    rollDeg: lerp(poseA.rollDeg || 0, poseB.rollDeg || 0, u),
    fov: lerp(poseA.fov || 72, poseB.fov || 72, u),
    ghostAlpha,
  };
}

// 2. Light-Led Gold/White Blow-Out Transition (Reference: T8 f557-566, T22-23 f1957-1992)
// Returns overlay opacity + color for peak white-gold flash across the scene seam
export function evalBlowOutFlash(frame, fStart, fPeak, fEnd, tint = [255, 244, 210]) {
  if (frame < fStart || frame > fEnd) return { alpha: 0, color: tint, sceneSwitch: frame >= fPeak };
  let alpha = 0;
  if (frame <= fPeak) {
    alpha = Math.pow(windowProgress(frame, fStart, fPeak), 2.1);
  } else {
    alpha = 1 - Math.pow(windowProgress(frame, fPeak, fEnd), 0.75);
  }
  return { alpha: clamp(alpha), color: tint, sceneSwitch: frame >= fPeak };
}

// 3. Downward Caustic Seam Wipe (Reference: T7 f470-481)
// Returns wipeY in [0..1] (fraction down screen) and leading-edge white-cyan glow band
export function evalSeamWipe(frame, fStart, fEnd) {
  if (frame < fStart) return { active: false, progress: 0, bandWidth: 0 };
  if (frame > fEnd) return { active: false, progress: 1, bandWidth: 0 };
  const u = easeInOutSine(windowProgress(frame, fStart, fEnd));
  return { active: true, progress: lerp(0.42, 1.05, u), bandWidth: 0.085 };
}

// 4. Warm <-> Cold Flicker Cycle (Reference: S19 f1501-1640, period ~43 frames / 1.43s)
export function evalLightPulseCycle(frame, periodFrames = 43) {
  const phase = ((frame % periodFrames) / periodFrames) * Math.PI * 2;
  // Soft square-ish wave alternating cool lavender (0) and warm orange (1)
  return smoothstep(-0.35, 0.35, Math.sin(phase));
}

// 5. Pixel Mosaic Breakdown Overlay (Reference: S22 f1930-1956)
export function drawPixelMosaicOverlay(ctx, sourceCanvas, W, H, intensity) {
  if (intensity <= 0.01) return;
  const blockSize = Math.max(4, Math.round(lerp(4, 34, intensity)));
  const sw = Math.max(1, Math.floor(W / blockSize));
  const sh = Math.max(1, Math.floor(H / blockSize));
  const tmp = document.createElement('canvas');
  tmp.width = sw;
  tmp.height = sh;
  const tg = tmp.getContext('2d');
  tg.imageSmoothingEnabled = false;
  tg.drawImage(sourceCanvas, 0, 0, sw, sh);

  ctx.save();
  ctx.globalAlpha = clamp(intensity * 0.92);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(tmp, 0, 0, W, H);
  ctx.restore();
}
