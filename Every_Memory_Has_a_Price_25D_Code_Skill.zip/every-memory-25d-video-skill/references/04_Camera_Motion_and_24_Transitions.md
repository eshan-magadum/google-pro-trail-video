# 04 — Camera Movement, Motion Physics & All 24 Zero-Hard-Cut Transitions

Measured from 3×3 grid phase-correlation optical flow, consecutive frame diffs, and direct frame-by-frame inspection of all 2,334 frames (`assets/transition_strips/`).

---

## 1. Camera Optics & Motion Physics
| Parameter | Measured Behavior | Three.js Code Setting |
|---|---|---|
| **Vertical FOV / Lens** | Wide-angle architectural staging (`~18–24 mm` equiv) for streets/rooms; tighter (`~35–50 mm`) for macros & intimate holds | `PerspectiveCamera(72–76, W/H, 0.1, 120)` wide; `48–56` macro/portrait |
| **Camera Rig Motion** | Smooth, heavily damped tripod/crane/dolly curves — **ZERO handheld shake, ZERO jitter** | `easeInOutCubic` for whips/dolly bursts; `easeInOutSine` for slow drifts |
| **Motion Speed Profile** | Slow holds: `0.35–0.9 px/f`; normal dollies: `1.5–4.5 px/f`; whip transitions (T1, S18, S22): `8–16 px/f` for `0.3–0.5 s` | Keep camera target & position synced smoothly across every frame (`30.0 fps` on ones) |
| **Dutch Roll** | Subtle (`2–5°`) in pawn shop & tense street; dramatic (`20–25°`) in S08 wall climb and S14 brother collapse (`f1046–1068`) | `camera.rotateZ(THREE.MathUtils.degToRad(rollDeg))` |
| **Motion Blur** | **Virtually zero artificial motion blur** — speed is communicated via wide-angle 3D perspective & parallax (except intentional 3-frame ghost blend on T1 `f28–30`) | Keep renderer sharp; add optional `0.35` previous-frame ghost blend only on whip transitions |
| **3D Parallax Spread** | Highest during pull-throughs (`S04: 23.7 px`), macros (`S02: 19.3 px`), and foreground-occluded rooms (`S15: 10.6 px`); lowest on static holds (`S23: 0.78 px`) | Place foreground occluders at `z = camZ - 1.5..2.5`, 2D actors at mid `z`, walls far back |

---

## 2. The 5 Reusable Zero-Hard-Cut Transition Families

**Rule:** There are **ZERO hard cuts** in the entire 77.80 s reference video. Every scene transition belongs to one of these 5 families (implemented in `starter_code/engine/camera_transitions.js`):

1. **Family A — Camera-Led Continuous Motion (`T01`, `T02`, `T06`, `T17`):**
   - Camera physically swings, pitches, pulls up, or tilts up within the SAME continuous 3D world space (optional 3-frame ghost double-exposure during rapid whip-pitch).
   - *Code:* `evalWhipPitch(frame, fStart, fEnd, poseA, poseB)` or single continuous camera spline across two story beats.
2. **Family B — Persistent Object / Shape Match-Cut (`T10`, `T11`, `T12`, `T13`, `T14`):**
   - A key prop (frog, Polaroid, circular gauge ring) stays locked at identical screen coordinates `(x, y)` while the 3D background cross-dissolves behind it (often combined with a shallow-DOF rack focus!).
   - *Code:* Keep prop mesh/billboard pinned in screen-NDC space while blending Scene A render target -> Scene B render target over `10–14` frames.
3. **Family C — Face-Position Match Dissolve (`T15`, `T16`, `T18`, `T24`):**
   - Character's round head stays at the exact same `(x, y)` position across a `6–12` frame cross-dissolve while location, outfit, or lighting temperature flips completely (most iconic: `T24` 6-frame warm brother -> cold cobalt Jerry!).
   - *Code:* Align both characters' head centers to exact screen `(0.50, 0.43)`, crossfade `6–10` frames, optionally step-flip palette preset simultaneously.
4. **Family D — Light-Led Blow-Out / Color Wash (`T05`, `T08`, `T19`, `T22`, `T23`):**
   - An emissive practical light (extractor lamp, resort sun, rising memory chip) blooms radially until frame luminance peaks near white/gold (`luma 190–245`), seamlessly hiding the scene swap underneath the peak flare.
   - *Code:* `evalBlowOutFlash(frame, fStart, fPeak, fEnd, [255, 244, 210])` switching scenes at `frame === fPeak`.
5. **Family E — Physical Occluder / Glass / Refraction Wipe (`T03`, `T04`, `T07`, `T09`, `T20`, `T21`):**
   - A 3D storefront glass pane pulls across the lens (`T03`), rain-spotted glass dissolves (`T04`), a glowing caustic water seam blurs & wipes downward (`T07`), vertical blurred light-streaks sweep across (`T09`), or a printed ledger slides up (`T21`).
   - *Code:* 3D foreground transparent plane or 2D shader/canvas seam wipe (`evalSeamWipe`) with leading-edge glow band + progressive Gaussian blur on the outgoing half.

---

## 3. Complete 24-Transition Frame-Accurate Specification
| # | Seam | Exact Frames (Time) | Duration | Family | Frame-Accurate Mechanics (Verified Visually) |
|---|---|---|---:|---|---|
| **T01** | S01 -> S02 | `f0025–0035` (`0.80–1.13s`) | 11 f (`0.37s`) | A (Camera) | Push-in on Jerry -> ~70° whip-pitch down onto wooden counter; Jerry's face blurs & ghosts 3 frames (`f28–30`) over counter; macro settles `f36` |
| **T02** | S02 -> S03 | `f0047–0060` (`1.53–1.97s`) | 14 f (`0.47s`) | A (Camera) | Continuous pull-up/back (no cut): glowing card shrinks, cash register enters, vignette darkens (`luma 130->40`), stranger slides in far-left `f55` |
| **T03** | S03 -> S04/05 | `f0151–0166` (`5.00–5.50s`) | 16 f (`0.53s`) | E (Glass) | 3D camera dollies **backward through the shop's glass window** (`f153–164` glass edge sweeps left->right); interior shrinks into `MEMORIES` storefront window in rainy alley |
| **T04** | S05 -> S06 | `f0196–0204` (`6.50–6.77s`) | 9 f (`0.30s`) | E (Glass) | Rain-spotted storefront window glass dissolves into lit lavender extractor parlor |
| **T05** | S06 -> S07 | `f0259–0264` (`8.60–8.77s`) | 6 f (`0.20s`) | D (Light) | Post-flash lavender-white shop haze cross-dissolves smoothly into dark indigo Deli street |
| **T06** | S07 -> S08 | `f0397–0432` (`13.20–14.37s`) | 36 f (`1.20s`) | A (Camera) | Continuous 3D tilt-up from crashed bike kid past circular hanging banner & cables into 25° Dutch-rolled towering wall |
| **T07** | S08 -> S09 | `f0470–0481` (`15.63–16.00s`) | 12 f (`0.40s`) | E (Wipe) | Horizontal refraction seam appears at `45%` height (`f472`) & wipes downward; resort sky/pool appear above a glowing white crest while night wall below blurs progressively (`f474–478`) |
| **T08** | S09 -> S10 | `f0557–0566` (`18.53–18.83s`) | 10 f (`0.33s`) | D (Light) | High-key resort pool blows out to near-white (`f562–566`) and resolves into sunlit Bahamas dome-extractor window room |
| **T09** | S11 -> S12 | `f0685–0720` (`22.80–23.97s`) | 36 f (`1.20s`) | E (Streaks) | Couch dissolves into flamingo pool water (`f685–693`), then vertical blurred white-blue light-streak blinds (`f705–720`) sweep across into poor-side dusk bench (`f716–720` ghost) |
| **T10** | S12 -> S13 | `f0825–0836` (`27.47–27.83s`) | 12 f (`0.40s`) | B (Shape) | Woman lifts framed photo (`f820–828`); large circular brass `HAPPINESS` dial fades up at lower center (`f826–834`) becoming S13 |
| **T11** | S13 -> S14 | `f0946–0956` (`31.50–31.83s`) | 11 f (`0.37s`) | B (Shape) | Glowing gold gauge ring fades out as an iris ring over the deep-indigo night street (`f950–953`) |
| **T12** | S14 -> S15 | `f1078–1092` (`35.90–36.37s`) | 15 f (`0.50s`) | B (Object) | Heavy rack-defocus blurs street (`f1066–1080`) while **razor-sharp green frog stays locked at `(50%, 51%)`** as street dissolves into hospital bed footboard |
| **T13** | S15 -> S16 | `f1162–1189` (`38.70–39.60s`) | 28 f (`0.93s`) | B (Object) | Camera pushes past Jerry onto bedside Polaroid (`"the frog! :)"` w/ diagonal glare `f1165–1179`); drawing cross-dissolves into live animated boys (`f1181–1187`) as white border fades out |
| **T14** | S16 -> S17 | `f1264–1280` (`42.10–42.63s`) | 17 f (`0.57s`) | B (Object) | Reverse Polaroid: golden lake shrinks back inside white Polaroid frame (`f1266–1272`), dims to night blue, clipped onto hospital IV pole |
| **T15** | S17a -> S17b | `f1326–1336` (`44.17–44.50s`) | 11 f (`0.37s`) | C (Face) | Corridor Jerry face ghosts out at left while lamp-lit pawn desk Jerry face emerges at right |
| **T16** | S17 -> S18a | `f1412–1418` (`47.03–47.23s`) | 7 f (`0.23s`) | C (Face) | Desk Jerry face ghosts softly over maroon birthday card macro |
| **T17** | S18a -> S18b | `f1433–1452` (`47.73–48.37s`) | 20 f (`0.67s`) | A (Camera) | Fast pull-back from card macro revealing olive gauge box on pole; dark ball-hand swings in from right to press box (`f1442–1447`), Jerry swings into corridor |
| **T18** | S18 -> S19 | `f1498–1512` (`49.90–50.37s`) | 15 f (`0.50s`) | C (Face) | Red-lit `OPERATING` hall Jerry ghosts at identical upper-center head position into rainy `WE BUY SUMMERS` street carrying stacked boxes |
| **T19** | S19 -> S20a | `f1636–1648` (`54.50–54.90s`) | 13 f (`0.43s`) | D (Light) | Warm-orange sign-lit face dissolves smoothly into cold indigo hospital sickbed |
| **T20** | S20a -> S20b | `f1678–1716` (`55.90–57.17s`) | 39 f (`1.30s`) | E/A | Sickbed dissolves to giant cold-lit Jerry holding open ledger (`f1678–1692`); camera pushes straight in (`f1693–1716`) until `MEMORY SAVINGS` page fills frame |
| **T21** | S20 -> S21 | `f1737–1748` (`57.87–58.23s`) | 12 f (`0.40s`) | E (Overlay) | Ledger page dissolves upward into the pawn shop interior looking out through mirrored `SEIROMEm` glass |
| **T22** | S21 -> S22 | `f1902–1976` (`63.37–65.83s`) | 75 f (`2.50s`) | A + D | Lavender dome drops on Jerry (`f1902–1920`); camera whips up tube (`f1926–1932`); backlit `MC-4-2018` chip flies out and blooms radially to **peak gold-white blow-out (`f1969–1973`)** |
| **T23** | S22 -> S23 | `f1976–1992` (`65.83–66.37s`) | 17 f (`0.57s`) | D (Light) | Gold blow-out resolves through a soft white-gold flare into the warm sunlit morning hospital ward |
| **T24** | S23 -> S24 | `f2137–2143` (`71.20–71.40s`) | **7 f (`0.23s`)** | C + D | **Signature Emotional Twist:** Healed warm-cream brother face ghosts directly onto Jerry's face at the exact center while lighting snaps instantaneously to cold cobalt (`b-r: -43 -> +47`) |
