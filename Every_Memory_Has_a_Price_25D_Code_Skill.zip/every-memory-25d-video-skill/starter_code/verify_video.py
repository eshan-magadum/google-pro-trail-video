#!/usr/bin/env python3
"""
Automated QA Verifier for Every-Memory-Has-a-Price Style 2.5D Code Videos.
Checks container spec, 30 FPS constant rate, zero hard cuts, lifted indigo shadows,
saturation, vignette range, optional ending freeze, and optional -14 LUFS loudness.

Usage:
  python3 verify_video.py out/final.mp4 [--mode gloom|warm|cold] [--expect-freeze]
"""
import argparse
import json
import re
import subprocess
import sys
import numpy as np


def ffprobe_info(path):
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
        text=True,
    )
    return json.loads(out)


def decode_frames(path, w=180, h=320):
    raw = subprocess.check_output([
        "ffmpeg", "-v", "error", "-i", path,
        "-vf", f"scale={w}:{h}:flags=area",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-",
    ])
    arr = np.frombuffer(raw, dtype=np.uint8)
    n = arr.size // (h * w * 3)
    return arr[: n * h * w * 3].reshape(n, h, w, 3)


def check_lufs(path):
    proc = subprocess.run(
        ["ffmpeg", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"],
        stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True,
    )
    m_i = re.search(r"I:\s+(-?\d+\.\d+)\s+LUFS", proc.stderr)
    m_tp = re.search(r"Peak:\s+(-?\d+\.\d+)\s+dBFS", proc.stderr)
    return (float(m_i.group(1)) if m_i else None, float(m_tp.group(1)) if m_tp else None)


def check(label, ok, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: {detail}")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--mode", default="gloom", choices=["gloom", "warm", "cold"])
    ap.add_argument("--expect-freeze", action="store_true")
    args = ap.parse_args()

    info = ffprobe_info(args.video)
    vs = next(s for s in info["streams"] if s["codec_type"] == "video")
    astreams = [s for s in info["streams"] if s["codec_type"] == "audio"]
    w, h = int(vs["width"]), int(vs["height"])
    num, den = map(int, vs["r_frame_rate"].split("/"))
    fps = num / den
    dur = float(info["format"]["duration"])

    ok = True
    ok &= check("Vertical 9:16 resolution", w * 16 == h * 9 and w >= 720, f"{w}x{h}")
    ok &= check("Constant 30 FPS", abs(fps - 30.0) < 0.01, f"{fps:.2f} fps, {dur:.2f} s")

    frames = decode_frames(args.video)
    n = len(frames)

    # Zero hard cuts check (no isolated 1-frame diff spike > 4x local median & > 28)
    diffs = np.abs(frames[1:].astype(np.float32) - frames[:-1].astype(np.float32)).mean(axis=(1, 2, 3))
    hard_cuts = []
    for i in range(len(diffs)):
        lo, hi = max(0, i - 4), min(len(diffs), i + 5)
        med = float(np.median(diffs[lo:hi]))
        if diffs[i] > max(28.0, 4.0 * med):
            hard_cuts.append((i + 1, round(float(diffs[i]), 1), round(med, 1)))
    ok &= check("Zero hard cuts", len(hard_cuts) == 0, f"detected={hard_cuts[:5]}")

    # Color / Shadow / Vignette check on mid-video sample
    mid = frames[n // 2].astype(np.float32)
    luma = 0.2126 * mid[..., 0] + 0.7152 * mid[..., 1] + 0.0722 * mid[..., 2]
    cmax, cmin = mid.max(-1), mid.min(-1)
    sat = np.where(cmax > 1.0, (cmax - cmin) / np.maximum(cmax, 1.0), 0.0)
    H, W = luma.shape
    ch, cw = H // 6, W // 6
    corners = np.concatenate([
        luma[:ch, :cw].ravel(), luma[:ch, -cw:].ravel(),
        luma[-ch:, :cw].ravel(), luma[-ch:, -cw:].ravel(),
    ])
    center = luma[H // 3 : 2 * H // 3, W // 3 : 2 * W // 3]
    vig = float(corners.mean() / max(center.mean(), 1e-3))

    dark = mid[luma <= np.percentile(luma, 5)]
    dr, dg, db = float(dark[:, 0].mean()), float(dark[:, 1].mean()), float(dark[:, 2].mean())

    ok &= check("Mean saturation", 0.30 <= float(sat.mean()) <= 0.80, f"sat={sat.mean():.3f}")
    ok &= check("Vignette corner/center", 0.15 <= vig <= 1.15, f"ratio={vig:.3f}")
    if args.mode in ("gloom", "cold"):
        ok &= check(
            "Lifted indigo/cobalt shadows (P05 B>R & lifted)",
            db > dr and db > dg and db > 12,
            f"P05 RGB=({dr:.1f}, {dg:.1f}, {db:.1f})",
        )

    if args.expect_freeze and n >= 30:
        end_std = float(frames[-28:].astype(np.float32).std(axis=0).mean())
        ok &= check("Ending 1s freeze hold", end_std < 0.5, f"pixel_std={end_std:.3f}")

    if astreams:
        lufs, tp = check_lufs(args.video)
        if lufs is not None:
            ok &= check("Audio Loudness (-14 LUFS +/-2.5)", -16.5 <= lufs <= -11.5, f"{lufs:.1f} LUFS, peak {tp:.1f} dBFS")

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
