// Example 5-second (150-frame @ 30 FPS) True 2.5D Hybrid Scene Demo.
// Demonstrates: 3D lit wet rainy street + glowing shop window + 2D cel character billboard
// with frame-accurate blinking/expression change + smooth eased dolly + gold blow-out + captions.
import * as THREE from 'three';
import { Hybrid25DStage } from './engine/hybrid_scene_base.js';
import { createCharacterTexture } from './engine/cel_character_rig.js';
import {
  makeBrickTextures,
  makeWetSidewalkTexture,
  makeGlowingSignTexture,
} from './engine/procedural_textures.js';
import { easeInOutCubic, lerp, evalBlowOutFlash } from './engine/camera_transitions.js';

const params = new URLSearchParams(window.location.search);
const W = Number(params.get('w')) || 720;
const H = Number(params.get('h')) || 1280;

const stage = new Hybrid25DStage({ width: W, height: H, fov: 74, preset: 'gloom_indigo' });

// --- 3D BACKGROUND SET ---
const sidewalk = new THREE.Mesh(
  new THREE.PlaneGeometry(36, 26),
  new THREE.MeshStandardMaterial({ map: makeWetSidewalkTexture(), roughness: 0.94, metalness: 0.0 })
);
sidewalk.rotation.x = -Math.PI / 2;
sidewalk.position.set(0, 0, 6);
sidewalk.receiveShadow = true;
stage.scene.add(sidewalk);

// Soft wet storefront window reflection on sidewalk (no clearcoat specular blobs!)
stage.addWetReflectionDecal({ x: 0.5, z: 2.2, width: 10.5, depth: 5.5 });

// Left brick building wall
const brick = makeBrickTextures();
const brickWall = new THREE.Mesh(
  new THREE.BoxGeometry(6, 14, 2.2),
  new THREE.MeshStandardMaterial({ map: brick.map, bumpMap: brick.bumpMap, bumpScale: 0.05, roughness: 0.85 })
);
brickWall.position.set(-5.5, 7, -0.5);
stage.scene.add(brickWall);

// Main glowing storefront facade + emissive sign window
const facade = new THREE.Mesh(
  new THREE.BoxGeometry(10, 14, 2),
  new THREE.MeshStandardMaterial({ color: '#39418B', roughness: 0.82 })
);
facade.position.set(1.5, 7, -1.2);
stage.scene.add(facade);

const shopWin = new THREE.Mesh(
  new THREE.PlaneGeometry(6.6, 3.3),
  new THREE.MeshBasicMaterial({ map: makeGlowingSignTexture('MEMORIES', 'BOUGHT & SOLD') })
);
shopWin.position.set(0.8, 2.55, -0.18);
stage.scene.add(shopWin);

// Warm practical spill light from shop window
const shopLight = new THREE.PointLight('#FFCC7D', 5.4, 13, 1.5);
shopLight.position.set(0.8, 2.6, 1.6);
stage.scene.add(shopLight);

// 3D Foreground Occluder (dark street railing post that passes in front of 2D character!)
const railPost = new THREE.Mesh(
  new THREE.BoxGeometry(0.14, 1.55, 0.14),
  new THREE.MeshStandardMaterial({ color: '#141634', roughness: 0.6 })
);
railPost.position.set(-1.35, 0.78, 4.35);
stage.scene.add(railPost);

// --- 2D CEL CHARACTER BILLBOARDS (Depth-sorted inside 3D scene) ---
const texWary = createCharacterTexture({ eyes: 'ring', brows: 'worried', mouth: 'dot' });
const texBlink = createCharacterTexture({ eyes: 'wink_left', brows: 'worried', mouth: 'dot' });
const texAlarm = createCharacterTexture({
  eyes: 'wide_ring', brows: 'raised', mouth: 'wavy_anxious', extras: { sweatDrop: true },
});

const hero = stage.addCharacterBillboard(texWary, {
  x: 0.15, y: 1.52, z: 2.55, width: 2.1, height: 3.15, shadowW: 1.05,
});

// Caption schedule (1-2 words per chunk)
const CAPTIONS = [
  [2, 22, 'Every'],
  [23, 45, 'memory'],
  [46, 70, 'has a'],
  [71, 102, 'price.'],
  [103, 149, 'Every single one.'],
];

function getCaption(f) {
  for (const [s, e, text] of CAPTIONS) {
    if (f >= s && f <= e) return text;
  }
  return '';
}

// Deterministic per-frame render entry point invoked by render_frames.mjs
window.renderFrame = function renderFrame(frame) {
  // Smooth eased push-in + subtle lateral parallax orbit (frames 0..149)
  const u = easeInOutCubic(Math.min(1, frame / 130));
  const camX = lerp(-2.2, 0.45, u);
  const camY = lerp(2.25, 1.95, u);
  const camZ = lerp(6.8, 4.75, u);
  stage.setCameraPose([camX, camY, camZ], [0.25, 1.85, 0.6], lerp(-2.5, 0.0, u));

  // Frame-accurate character acting beats
  if (frame >= 18 && frame <= 21) {
    hero.mesh.material.map = texBlink;
  } else if (frame >= 72) {
    hero.mesh.material.map = texAlarm;
  } else {
    hero.mesh.material.map = texWary;
  }
  hero.mesh.material.needsUpdate = true;

  // Gold blow-out transition near end (frames 128..149)
  const flash = evalBlowOutFlash(frame, 128, 144, 155, [255, 240, 195]);

  stage.renderFrame({
    frame,
    rain: true,
    rainCount: 44,
    flashOverlay: flash,
    caption: getCaption(frame),
  });
};

// Render initial preview frame if opened directly or with ?frame=N
const initialFrame = Number(params.get('frame')) || 15;
window.renderFrame(initialFrame);
window.__SCENE_READY__ = true;
