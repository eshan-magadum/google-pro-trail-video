# 01 — MASTER STYLE BIBLE
**Reference:** `Every_Memory_Has_a_Price.mp4` — every number below was measured from the file (all 2,334 frames), not guessed. Where something is my visual interpretation instead of a measurement, it is marked *(observed)*.

---
## A. Technical fingerprint (measured)
| Item | Value |
|---|---|
| Resolution / aspect | 720 × 1280, **9:16 vertical** (Shorts/Reels/TikTok) |
| Frame rate | **30 fps constant** (2,334 frames, 77.8 s) |
| Codec | H.264 Main L3.1, yuv420p, BT.709 limited range, ~1.04 Mbps |
| Audio | AAC-LC, 44.1 kHz stereo, 128 kbps, **−14.1 LUFS integrated**, loudness range only 1.9 LU, true peak −2.0 dBTP |
| Scenes | **24 scenes**, average 3.2 s, shortest 0.6 s (S04), longest 6.6 s (S24) |
| Hard cuts | **ZERO** (confirmed by viewing every frame). 24 transitions, each a 0.2–2 s camera move, wipe, match-cut or dissolve |
| Animation smoothness | **Full 30 fps motion** — only 35 of 2,333 frame pairs are near-duplicates, so it is NOT animated 'on twos'; the only true freeze is the ending |
| Film grain | **None** (measured high-frequency noise ≈ 0.15 / 255). Source is clean, smooth, gradient-rich |
| Letterboxing | None — full-bleed vertical |
| Captions | Burned-in, 100 % of the runtime, 1–2 words at a time (see doc 06) |

**Rebuild target:** generate at 1080×1920 / 30 fps / H.264 (the reference is a low-res 720p encode; you can exceed it).

---
## B. The one-sentence look
> **A 2.5D "stick-figure comic" cast — flat, thick-black-outlined, round-headed characters — dropped into richly lit, painterly 3D-rendered dioramas, shot with a wide-angle virtual camera that never cuts, only glides, swings and dissolves; gloom is built from saturated indigo shadows + tiny warm practical lights + rain + vignette, and it is punished against false-cheerful blown-out tropical brightness.**

## C. The 8 pillars (copy these into every prompt)
1. **Character/world style split.** Characters = flat cel colour + heavy black ink outline (~6–8 px at 720 p, ≈ 1 % of frame width), tiny minimalist faces. Worlds = lit 3D with soft gradients, volumetric haze, reflections, depth-of-field, bloom. The contrast between "2D drawing" and "3D light" IS the style.
2. **Gloom = saturated darkness, not grey.** Dark scenes measured: luma 42–75 (of 255), HSV saturation **0.55–0.69** (S14 0.66, S17 0.63). Shadows are deep indigo `#0F0D25`, never neutral black. 69 % of pixels in the darkest scene sit below luma 40.
3. **Warm practical lights as the only hope.** Amber door windows, lamp pools, glowing memory cards, gold gauge. Warm peach highlights `#D9C5BE` over indigo shadows = the split-tone signature.
4. **Gold = memory/value.** Everything that is a memory glows gold: card, gauge, extractor helmet, final flare. Blue/indigo = loss, the real world. Cream/honey = love. Teal = clinical/commerce. Tropical cyan+cream = hollow wealth.
5. **Light tells the story.** Light moves from cold-dark → fake-bright → cold → gold flash → warm hope → cold-blue emptiness. In the final scene the **warm light sits on the cured brother and cold light sits on Jerry**, who has lost the memory of him.
6. **Never cut — travel.** Camera swings off a character onto a prop, tilts up a wall into the next world, dives into pool water, follows an extractor tube into a flare. The edit is one continuous "camera thought".
7. **Slow holds, short bursts.** Median motion is tiny (drift 0.2–0.6 px/frame on holds); transitions spike to 4–10 px/frame for ~0.3–0.6 s. The last second is a total freeze (motion 0.008 px/frame).
8. **Rhythm by narration.** ~2.8 words/s voice-over (≈ 165–175 wpm). Each caption chunk lasts ≈ 0.33 s. Visual beats are timed to meaning ("rent", "sold", "pays").

9. **Match everything.** Transitions hold a *prop* (frog, polaroid, dial ring) or a *face position* steady while the world changes around it (v2 finding: 24 transitions in 4 families — see doc 03).
10. **Light is a signal.** Props and skin pulse with light to mark story beats: amber window pulse on 'money', gold flood of the gauge, red OPERATING bleed, face colour cycling cold/warm every ~1.45 s, gold blow-out, cold flip.
11. **Eyes and hair are an emotion code** (v2 finding): double-ring eyes = alive; dash eyes = tired/serene; **dot eyes = hollow**; wavy zig-zag mouth = anxious/confused; limp hair = sick, spiky hair = healed.
12. **A repeatable machine:** the extraction device (dome descends → halo → card rises → bloom → counter ticks → dome lifts) appears three times and gets bigger each time, ending in a pixel mosaic and a gold blow-out.

## D. Measured look numbers
| Class | Scenes | Luma | Saturation | P5 / P95 | Corner÷Center (vignette) | Bright-pixel % (>235) |
|---|---|---|---|---|---|---|
| Deep gloom | S03 S13 S14 S15 S17 S21 | 42–79 | 0.48–0.66 | 8–19 / 122–234 | 0.25–0.42 | 0.5–12 % |
| Mid-night | S01 S05 S07 S08 S19 S22 | 68–85 | 0.48–0.58 | 18–34 / 155–226 | 0.21–0.55 (S08 ≈ 1.0: bright sky fills the top corners) | 1–10 % |
| False-bright | S09 S10 S11 | 155–179 | 0.34–0.42 | 52–66 / 221–244 | 0.91–0.99 (none) | 17–46 % |
| Honey hope | S16 S23 | 127–142 | 0.46 | 39–57 / 218–224 | 0.47–0.67 | 12–19 % |

Overall: mean luma 93/255 (low-key film), mean saturation 0.52, shadow-tint `#1D192F`, mid `#5F5A75`, highlight `#E0D1C8`, Lab mean a +12 / b −13 (a magenta-blue cast over the whole film).

## E. Things you did not list but that matter (I added them)
* **Aspect/safe zones** — captions live at ~70 % of frame height; keep faces in the upper 60 % so they never collide.
* **Lens** — wide-angle (≈ 18–24 mm equivalent): strong converging perspective on counters, alley and corridor; characters near the lens get big-head distortion.
* **Camera height** — counter-level low angles for menace; ~80° top-down for the macro of the memory card; eye-level for emotional beats.
* **Dutch tilt** — ±8–20° on the wall tilt (S08), the night street (S14) and the bench (S12) to signal "something is wrong with this world".
* **Rain & wet reflections** on the dark side only; pool caustics on the rich side only — weather and surface = class divide.
* **Recurring motifs** — frog (badge on the vest, hopping, plush), glowing memory card, brass gauge, round-head silhouette, helmet extractor, red "SOLD" stamps, ledger book, "OPERATING" sign.
* **In-world typography** — arched gold shop lettering on teal/navy, "DELI GROCERY", "HAPPINESS" dial, "BAHAMAS" odometer, "MEMORY SAVINGS" ledger, red bench ad, **"WE BUY SUMMERS" in maroon slab-serif caps on a mustard board with a script sub-line "cash today, any grade"**, a blue handwritten "the frog!" on the polaroid, an "OPERATING" sign that turns red. Text is a flat graphic *inside* the lit 3D scene (catching its light), never a UI overlay.
* **No grain, no shake, no motion blur** — the polish comes from gradients, bloom and vignette.
* **Hold-then-freeze ending** — final 30 frames are identical (luma std 0.03).
* **Colour temperature flip as a plot beat** — 71.1–71.4 s: warm 141 luma → cold 76 luma in 0.4 s.
* **Over-clean "luxury" look on the rich side** — deep focus, clipped highlights, plastic gloss — intentionally colder emotionally than the grungy gloom.

## F. What would break the look (avoid)
Photoreal faces · gritty film grain · handheld shake · neutral black/grey shadows · pastel desaturated gloom · hard jump cuts · dark-mode captions in thin fonts · anime shading on faces · muddy brown "sepia" nostalgia (the warm scene is *cream-gold with blue edges*, not brown).
