# 07 — GPT-6.2 ASTRA MASTER PROMPTS (copy / paste)
**Read first — what Astra can and can't do.** From the third-party guides I found (not an official statement; please check your own account), Astra is a *planning/writing/reasoning* model: it accepts text + images and outputs text (and, in some set-ups, images), but it **does not natively render video**. So the workflow is: **Astra writes the script, shot list and prompts → an image generator makes keyframes → an image-to-video model animates each keyframe → you assemble, grade, caption and mix in an editor** (CapCut / DaVinci Resolve / Premiere). Everything below is written for that pipeline. If your Astra does render images, use PROMPT 3 directly.

**Upload with the prompts:** `reference_frames/*.jpg` (24 key frames), `sheets/overview_00–04.jpg`, and `data/timeline_all_2334_frames.png`. Astra accepts image input, so it can *see* the style.

---
## PROMPT 1 — DIRECTOR BRIEF (paste first, with the reference images attached)
```
You are my lead director, storyboard artist and prompt engineer for a 9:16 vertical animated short.

GOAL
Produce a 75–80 second animated short with EXACTLY the same look, pacing, camera language, lighting, colour grade and emotional feel as the attached reference frames. I will generate the images and clips with external tools; you plan everything and write every prompt.

STYLE (non-negotiable)
- 2.5D stylised animation: characters are flat cel-coloured, round-headed stick figures with thick black ink outlines (≈1% of frame width), stick limbs with ball hands, minimalist faces (double-ring eyes or dot eyes, thin expressive eyebrows, tiny mouth). Environments are painterly lit 3D dioramas with volumetric haze, rain, wet reflections, bloom and smooth gradients.
- Gloom is made from SATURATED deep-indigo shadows (RGB ≈16,13,38), lifted indigo blacks (never pure black), tiny warm practical lights (amber windows, lamp pools, gold glowing objects), strong vignette (corners ≈30% of centre brightness), faces lit like lanterns. Do NOT desaturate to get gloom.
- Contrast scenes: false-cheerful over-bright tropical scenes (blown highlights, turquoise water, no vignette, saturation ≈0.4).
- Gold = value/memory. Blue/indigo = loss. Cream-honey with royal-blue edges = love/hope. Teal = clinical/commerce.
- No film grain, no handheld shake, no photorealism, no anime shading.

CAMERA
- Wide-angle (≈20 mm) virtual camera. NEVER hard-cut: every scene change is a camera swing, wipe, dive, match-cut or dissolve of 0.25–2 s. Holds are slow (push-ins, parallax drifts). Bursts of fast eased movement only at transitions. Last second freezes.

TIMING
- 24 scenes, 30 fps, 9:16, narration ≈ 2.8 words/second, captions 1–2 words at a time (≈0.33 s each), white bold sans with a heavy black outline, centred at 70% of frame height.

ACTING & CONTINUITY CODES (non-negotiable)
- Eyes: double-ring eyes = alive; flat dash eyes = tired/serene/blink; plain dot eyes = hollow/forgotten; one closed eye = wink/flinch. Wavy zig-zag mouth = anxious/confused. Sweat drop = panic, single tear = grief.
- Hair: limp and flat when sick, spiky and springing when healthy.
- Memories glow gold; when a memory is extracted a dome/helmet descends with a halo, a card rises with a bloom flash, a counter ticks, the dome lifts. Use this device three times, each bigger than the last (the last ends in a pixel-block mosaic and a full gold blow-out).
- Transitions must hold a prop (frog, polaroid, dial ring) or a face position steady while the world changes; use light (white blow-out, red bleed, gold flood, cold flip) as transitions too.
- Faces' skin tone may pulse cold lavender <-> warm orange (~1.45 s) under flickering sign light when a character is being drained.

DELIVERABLES (in this order, in clear sections)
1. Logline + 3 alternative original story premises that fit this style (a society where something intangible has a price; a twist ending using light/colour as the punchline).
2. After I choose, the full narration script (~215 words) with a word-by-word caption timeline.
3. A 24-row shot list: scene #, start/end time, location, characters, action, camera move, lighting, palette hexes, expression, transition out.
4. For each shot: an IMAGE PROMPT (first frame) and a MOTION PROMPT (image-to-video).
5. A continuity bible: character descriptions, repeated props, colour tokens.
6. Sound design cues and a final mix spec (−14 LUFS, true peak ≤ −1.5 dBTP).
7. A QA checklist to review each generated clip against the reference.

Ask me at most ONE question if you must, otherwise start with deliverable 1.
```

## PROMPT 2 — STYLE LOCK (prefix for EVERY image prompt)
```
STYLE LOCK: vertical 9:16, 2.5D stylised animation. Flat cel-coloured round-headed stick-figure characters with thick pure-black ink outlines, stick limbs with ball hands, minimalist faces (double-ring eyes, thin expressive brows, tiny mouth), orange zig-zag-shaded hair. Placed in a painterly, lit 3D-rendered diorama with a wide-angle (≈20 mm) camera, volumetric haze, rain and wet reflections where relevant, soft bloom around lights, smooth gradient backdrops. Gloomy scenes: saturated deep-indigo shadows (#0F0D25) with lifted indigo blacks, a few tiny warm practical lights (amber, gold), warm peach highlights (#D9C5BE), strong vignette. Bright scenes: blown cream highlights, turquoise and cobalt, over-clean and glossy, no vignette. Gold glow on every memory object. Clean image, no grain, no photorealism, no text artefacts.
```

## PROMPT 3 — CHARACTER LOCK (generate these first, reuse as reference images)
```
Character sheet, 9:16 composition, plain neutral background, turnaround-style: 
(1) PROTAGONIST — round-headed stick-figure teenage boy: big circular peach-white head with a single soft lavender shade shape, orange spiky hair with zig-zag line shading and three pale highlight strokes, double-ring eyes, thin brows, tiny dot mouth; bean-shaped torso in a yellow vest with a white centre stripe over a white shirt, a tiny green frog badge on the chest; thin black stick legs and arms with round ball hands; thick black outline. Show 8 expressions: wary, wide-eyed alarm, one-eye wink, tender smile with closed eyes, deadpan half-lids, shock with a sweat drop and wavy mouth, single tear, and HOLLOW (plain dot eyes, no rings).
(2) LITTLE BROTHER — same design, smaller, pale blue-green dotted hospital gown; expressions: sleepy, beaming, ecstatic open mouth, excited "o".
(3) HOODED SHOPKEEPER — enormous black-navy hood with a pale-blue rim line, chalk-white oval face, huge toothy grin, glowing amber pupils; second version: same hood, round pale worried face, raised brows, small "o" mouth.
(4) SUPPORTING CAST — bald round-headed assistant; elder woman with curly grey hair and earrings; elder man bald with round glasses; rich lounger in a straw hat and sunglasses; butler in a white jacket; Hawaiian-shirt man with snorkel mask.
Same line weight, same colours, same proportions across all.
```

## PROMPT 4 — NEGATIVE LIST (append to every prompt, or use the negative-prompt field)
```
photorealistic skin, realistic human proportions, anime eyes, film grain, noise, handheld shake, motion-blur smear, fisheye, pure black shadows, grey desaturated shadows, brown sepia filter, flat lighting, pastel washed-out look, text artefacts, extra fingers, extra limbs, watermark, logo, subtitles inside the image, split panels, borders, low resolution, over-sharpened, HDR halos
```

## PROMPT 5 — MOTION MASTER (prefix for every image-to-video clip)
```
Animate this exact image. Keep the characters' flat colours, thick black outlines, proportions and the scene's colours identical. Camera: smooth, eased, wide-angle, no shake; slow push-in or parallax drift unless the shot says otherwise; fast move only where specified. Minimal character performance: blinks, brow shifts, small head tilts, simple mouth shapes. Light sources softly pulse/bloom. Rain, steam, dust or caustics move gently where present. No cuts, no new characters, no style change, no morphing of faces.
```

## PROMPT 6 — QA / REVIEW (use after each clip, attaching the clip's frame and the matching reference frame)
```
Compare my generated frame with the reference frame. Score 1–5 on: (a) outline weight and flatness of characters, (b) indigo shadow colour and lifted blacks, (c) warm practical lights, (d) vignette strength, (e) bloom softness, (f) depth/blur correct for this scene type, (g) palette match (list the hex differences), (h) camera angle/lens match, (i) expression match, (j) overall gloom/hope feeling. Then give a corrected prompt for any item below 4.
```
