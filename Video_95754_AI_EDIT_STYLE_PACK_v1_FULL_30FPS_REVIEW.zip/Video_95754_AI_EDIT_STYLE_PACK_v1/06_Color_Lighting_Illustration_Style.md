# 06 — COLOR, LIGHTING & ILLUSTRATION STYLE GUIDE

Every colour hex below is measured directly from the frames (`data/scenes.json` + full-resolution pixel sampling).

## 1. The 4 Visual Worlds — exact design recipes

### World A — Clean Product UI & Editorial Dark Docs (S01, S02, S03, S04 top, S08, S10)
- **Light UI canvas (S04, S08, S10):**
  - Base background: warm off-white `#F7F6F3` to `#F4F9F8` with a soft radial warm peach/amber bloom (`#FFE3C2` at 35% opacity, radius 320 px) behind the central widget and a subtle 25% corner vignette (`#D8D2C7`).
  - Subtle background texture: `1 px` grid lines at `#E9E4DC` (spacing 80 px) + decorative curved dashed trajectory lines in `#E8A88A` (`4 px` dash / `6 px` gap) with tiny 4-point diamond stars.
  - Cards: pure white `#FFFFFF`, border `1.5 px solid #E8D5C8` (or `#E4E6EB`), corner radius `16–22 px`, soft elevation shadow `0 12px 32px rgba(20, 15, 30, 0.08)`.
  - Brand accent: Claude terracotta orange **`#E8743B`** / **`#F27B43`** (asterisk icon, rounded send button, stamp head, keycap active outline).
- **Dark Document canvas (S01 top, S02, S03):**
  - Background: deep warm charcoal `#100F0B` with a very subtle central radial lift to `#1C1B18` (vignette +15 luma in centre).
  - Lead-in label: muted grey `#8E8D8A`. Body serif text: warm cream `#E8E6DF`.
  - Blockquote rule & highlight box (S02–S03): lavender-indigo **`#7E82E8`** (`4 px` left bar in S02; `2.5 px` rounded highlight border with `8 px` outer glow in S03).

### World B — Glossy 2.5D Infographic / Iceberg (S04–S05)
- **Sky (above water):** `#F4F9F8` with soft radial white glow `#FFFFFF` in the centre and cool grey-beige vignette `#C9C8C2` at top corners.
- **Water surface & depth gradient:**
  - Waterline (`y ≈ 440` in S04, rises off top in S05): bright cyan `#3BD4F5` with animated white/cyan caustic ripple polygons (`opacity 0.25–0.45`).
  - Underwater vertical gradient (S05): top `#28B5E8` → mid `#0866C6` → deep `#084597` → bottom abyss **`#091F55`**.
- **Iceberg body:** low-poly faceted vector mesh filled with translucent icy gradients (`#EBF9FA` → `#BCE6F2` → `#89CBE3`), facet edges drawn with crisp `2 px` white lines (`rgba(255,255,255,0.85)`).
- **Internal "deeper meaning" bloom (f288+):** radial gradient centred inside the middle of the iceberg (`#FFB870` → `#FFD9A8` → transparent, radius 220 px, blend mode normal/screen at 65% opacity).
- **Icons:** **Microsoft Fluent 3D Emoji** style (soft plastic specular highlights, rich gradients) + bold navy labels **`#0E224D`**.

### World C — Flat Retro Editorial Cartoon (S07, S09, S11, S12, S15, S16, S17)
This is the signature illustration style of the edit. Keep these 6 rules locked whenever generating or drawing World C assets:
1. **Uniform thick ink outlines:** every object, card, hand, machine, and character has a **`5–7 px` dark espresso-black outline (`#1E1612`)** with `stroke-linejoin: round` and `stroke-linecap: round`.
2. **Warm paper-and-rust room (S07, S09):**
   - Upper 70% wall: warm cream `#F7E8CD` to `#F8EFD8` with a repeating **diagonal dash pattern** (`12 px` dashes tilted `-45°`, `#E2D3B8`, spaced every ~70 px) + a soft diagonal window-light beam (`+10` luma) + corner vignette.
   - Lower 30% desk (`y = 855 → 1280`): two-tone burnt orange / rust — top trim strip (`38 px` tall) in bright terracotta **`#D96B1F`** bounded by `5 px` black lines, main desk surface in deep rust gradient **`#A84A0E` → `#7D3408`**.
3. **Palette inside World C objects:**
   - Primary orange: `#F67644` (console body, play button, send button, card headers).
   - Warm cream surface: `#FFFDF7` / `#FAF5E6` (phone screen, card faces, dial face, speech bubble).
   - Ocean blue accent: `#165A8A` & `#2979B5` (music app waves, fly-swatter mesh `#3D8EC9`).
   - Mint success green: `#6FD89C` (highlighter, shield outline, gauge safe arc, check badges).
   - Alert red: `#E03E2D` (ladybugs, strike-through, marker ink, gauge red zone, `EXCLUSIVE` stamp).
   - Gold / amber: `#F5B841` / `#E0961F` (impact stars, lectern medallion, `Expert version` double border, verified coin seal).
4. **Theatre variant (S11–S12):**
   - Curtain backdrop: deep plum-purple **`#290F31`** with vertical fold stripes in `#381742` and `#1E0A24`.
   - Stage floor (`y = 810 → 1280`): warm mahogany wood `#5C2A0E` → `#381705` with horizontal plank lines.
   - Spotlight: additive warm cone from `(360, -40)` widening to `width 460 px` on the floor (`rgba(255, 232, 185, 0.28)` + floor ellipse `#C99B68` + floating dust dots).
5. **Cutting-mat variant (S15):**
   - Background: drafting-table green **`#1B5E3C`** with a `1 px` grid (`#2E7D56`, 45 px cells) and subtle 45° diagonal measurement lines.
6. **Reward sunburst variant (S16–S17):**
   - Background: royal blue radial gradient (centre `#185ADB` → edges `#032B88`) overlaid with 28 alternating wedges (`#2F6AE0` vs `#0A3AA6`) rotating slowly around `(360, 520)`.

### World D — Night-to-Amber Bulb Scene (S13)
- Starts in deep midnight navy **`#0E0B1D`** with tiny muted stars (`#3E4A6B`); unlit bulbs are slate grey-blue `#5D708C` with dark caps `#3B3A3F`.
- Searchlight cone: soft blurred cream beam `rgba(255, 245, 210, 0.32)`.
- Lit bulbs: core `#FFF394`, mid `#FFC940`, outer bloom `#FF8C24`.
- Global sky transition (f815–830): background cross-fades to warm smoky amber **`#4A312A` → `#6E4832`** as all 13 bulbs ignite.

---

## 2. Per-shot measured colour & brightness table
| Shot | Layout | Mean Luma | Contrast (σ) | Mean Sat | Warmth (R−B) | Top 4 k-means hex colours |
|---|---:|---:|---:|---:|---:|---|
| **S01** | SPLIT | 66.1 | 63.3 | 80.1 | +2.9 | `#11100e` `#40383c` `#b29289` `#7a6164` |
| **S02** | FULL_GFX | 25.5 | 38.7 | 67.6 | +1.7 | `#100f0b` `#1a191b` `#474646` `#7b7a79` |
| **S03** | FULL_GFX | 23.4 | 31.8 | 73.5 | +2.0 | `#100f0b` `#494847` `#2a2926` `#6c6b68` |
| **S04** | SPLIT | 149.4 | 96.4 | 78.7 | +3.0 | `#f4f9f8` `#130c0e` `#a57370` `#d1ccd0` |
| **S05** | FULL_GFX | 140.4 | 78.6 | 142.6 | −59.7 | `#e4f1ed` `#091f55` `#a2d2de` `#084597` |
| **S06** | SPEAKER | 82.3 | 62.6 | 122.1 | +18.3 | `#100909` `#c2867e` `#915b59` `#442e32` |
| **S07** | FULL_GFX | 167.9 | 74.1 | 114.5 | +48.1 | `#f8efd8` `#9c450c` `#d8c9b0` `#251915` |
| **S08** | SPLIT | 150.8 | 96.5 | 70.7 | +9.9 | `#f7f6f3` `#10090a` `#a5716c` `#44303e` |
| **S09** | FULL_GFX | 152.1 | 75.5 | 136.6 | +63.9 | `#9c440b` `#f7e8cd` `#d4c4ab` `#f67644` |
| **S10** | SPLIT | 145.7 | 96.0 | 75.7 | +9.6 | `#f6f7f5` `#0f090b` `#3b2f41` `#ae746b` |
| **S11** | FULL_GFX | 71.0 | 57.6 | 178.1 | +32.8 | `#471d07` `#290f31` `#8a3e15` `#fdf4c5` |
| **S12** | FULL_GFX | 66.5 | 55.4 | 171.1 | +28.3 | `#471e08` `#290f31` `#825f5a` `#f7f4ef` |
| **S13** | SPLIT | 60.7 | 52.8 | 138.6 | +11.4 | `#0e0b1d` `#4a313a` `#99685b` `#d0a3af` |
| **S14** | SPEAKER | 84.6 | 62.6 | 120.9 | +19.5 | `#c2877f` `#100909` `#8e5a58` `#402b2e` |
| **S15** | SPLIT | 98.4 | 75.1 | 129.4 | +8.0 | `#1b5e3c` `#100a0a` `#faf7e8` `#3f2e3e` |
| **S16** | FULL_GFX | 110.0 | 82.8 | 165.3 | −72.8 | `#033bb7` `#fcfbf4` `#2f5dbe` `#163075` |
| **S17** | FULL_GFX | 95.3 | 72.1 | 181.4 | −94.5 | `#053ab2` `#3d66ca` `#2a50ae` `#162b67` |
| **S18** | SPEAKER | 81.2 | 61.9 | 122.8 | +14.8 | `#1a1011` `#bc8078` `#7b4c48` `#3b3890` |

### Notice the deliberate brightness & temperature contrast wave
The editor alternates **dark/cool** and **bright/warm** blocks so every cut feels fresh to the eye:
- `S01–S03` **Dark** (luma 66 → 23) → `S04–S05` **Bright cool cyan** (luma 149, warmth −60) → `S07–S10` **Bright warm cream/orange** (luma 150–168, warmth +48 to +64) → `S11–S13` **Dark theatrical purple/navy** (luma 61–71) → `S15` **Mid green** (luma 98) → `S16–S17` **Vibrant royal blue** (luma 110, warmth −73 to −95) → `S18` **Warm speaker close-up**.
- **Rule for new edits:** never place two full-screen graphics with the same background colour back-to-back unless they are two halves of one continuous scene (like S02→S03, S11→S12, S16→S17).
