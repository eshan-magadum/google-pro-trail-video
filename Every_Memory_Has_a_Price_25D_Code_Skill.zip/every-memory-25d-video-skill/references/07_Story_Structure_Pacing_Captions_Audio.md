# 07 — Story Structure, Pacing, Captions & 30-Hz Audio Mix Spec

Measured directly from the `44.1 kHz` stereo audio stream (`data/audio_envelope_30fps.csv`), `ffmpeg ebur128` loudness audit, and frame-by-frame caption inspection across all 2,334 frames.

---

## 1. Narrative Beat Grammar (The 8-Act Short-Form Formula)
*Every Memory Has a Price* runs `77.80 s` (`~220` spoken words -> **`2.83 words/sec`**, `~170 wpm`) across **24 scenes** structured into 8 escalating emotional acts:

| Act | Time Window | % Runtime | Avg Scene Len | Dramatic Function | Visual / Light Signature |
|---|---|---:|---:|---|---|
| **1. Hook** | `0.0–5.2 s` (`S01–S03`) | `6.7%` | `1.7 s` | Provocative premise + glowing hero artifact + grinning dealer | Dark gloom + pulsing card & amber door window |
| **2. World** | `5.2–16.0 s` (`S04–S08`) | `13.8%` | `2.2 s` | Rapid tour of rules across 4 linked urban spaces | Rainy indigo streets, warm Deli spill, Dutch wall climb |
| **3. Contrast** | `16.0–27.6 s` (`S09–S12`) | `14.9%` | `2.9 s` | Mirror juxtaposition: Bright Rich Side vs Stark Poor Side | High-key cyan daylight (`luma 170`) vs sharpest dusk bench |
| **4. Mechanic** | `27.6–31.7 s` (`S13`) | `5.3%` | `4.1 s` | Visual device (`HAPPINESS` gauge + `$` odometer) makes the rule tangible | Silver dial floods gold + amber dealer eyes |
| **5. Stakes** | `31.7–47.2 s` (`S14–S17`) | `20.0%` | `3.9 s` | Personal love + crisis + warm cherished flashback + darkest decision | Deep blue collapse -> rack-focus frog -> golden lake -> single tear |
| **6. Escalation** | `47.2–58.0 s` (`S18–S20`) | `13.9%` | `3.6 s` | Rising sacrifice quantified by red alarm, flickering drain & `SOLD` ledger | Red `OPERATING` bleed -> 1.43s warm↔cold flicker -> gold `YEAR 2018` row |
| **7. Climax** | `58.0–65.9 s` (`S21–S22`) | `10.1%` | `3.9 s` | Quiet confrontation (antagonist unhooded & humanized) -> ultimate sacrifice | Mirrored shop window -> dome descent -> full gold-white blow-out |
| **8. Twist & Hold** | `65.9–77.8 s` (`S23–S24`) | `15.3%` | **`5.9 s`** | Warm victory -> instantaneous cold-cobalt ironic reveal -> `1.0 s` freeze | Longest holds (`5.5s` & `6.4s`); warm cream -> cold flip -> dot eyes -> freeze |

### Scene-Duration Pacing Rule
* **Fast world-building & transitions (`0.4–2.0 s`):** `S01, S02, S04, S05, S06` — build kinetic momentum early.
* **Medium narrative beats (`2.4–4.4 s`):** `S03, S07–S16, S18, S20, S22` — steady storytelling pulse.
* **Long emotional holds (`4.8–6.4 s`):** `S17, S19, S21, S23, S24` — **slow down ONLY on emotional devastation and payoff!**

---

## 2. Caption Specification (Exact Measured Geometry)
| Property | Exact Specification (`720×1280`) | Scaled Master (`1080×1920`) |
|---|---|---|
| **Position** | Centered `x = 50%` (`360 px`), vertical center **`y = 70.5%`** (`~902 px`) | `x = 540 px`, `y = 1354 px` |
| **Font Family** | Heavy geometric/neo-grotesque bold sans (`Inter ExtraBold`, `Montserrat ExtraBold`, `Liberation Sans Bold`, `Arial Black`) | Same |
| **Font Size** | **`54–56 px`** (`~7.5–7.8%` of frame width) | **`81–84 px`** |
| **Text Fill** | Pure clean white (`#FCFDFD`) | `#FCFDFD` |
| **Outline / Shadow** | Thick pure-black stroke **`~8 px` (`14–15%` of font size)**, round line-join + subtle drop shadow (`blur 9px`, `alpha 0.45`) | Stroke `~12 px`, blur `14px` |
| **Chunking** | **1–2 words per chunk** (3 words max only for tight articles like `"the surgery,"`) | 1–2 words per chunk |
| **Chunk Duration** | Median **`0.33 s`** (`10 frames`); 10th–90th percentile `0.10–0.53 s` (`3–16 frames`) | Synced word-for-word to VO |
| **Capitalization & Punctuation** | Natural sentence case (capitalize sentence starts & names only); keep commas and periods | Same |
| **Forbidden Styling** | ❌ NO background pill/box, ❌ NO yellow/green karaoke highlight, ❌ NO emojis, ❌ NO ALL-CAPS shouting, ❌ NO bounce scaling | Keep dead-still & legible |

---

## 3. Measured 30-Hz Audio Telemetry & Mix Blueprint

### A. EBU R128 Loudness Measurements (`Every Memory Has a Price.mp4`)
| Metric | Measured Value | Target for New Videos |
|---|---|---|
| **Integrated Loudness (I)** | **`-14.1 LUFS`** | **`-14.0 LUFS` (±0.5 LU)** |
| **Loudness Range (LRA)** | **`1.9 LU`** (`-15.0` to `-13.0 LUFS`) | **`1.8–2.5 LU`** (tightly leveled so mobile listeners hear every whisper) |
| **True Peak (TP)** | **`-2.0 dBFS`** | **`<= -1.5 dBTP`** |
| **Per-Frame Mono RMS** | Mean **`-19.3 dBFS`** (ranges `-25.2 dB` opening breath to `-16.8 dB` punchlines) | Keep VO consistent `-18` to `-15 dBFS` |
| **Spectral Balance** | Dominant energy below `250 Hz` (`40–80%`) + warm vocal band `250–3500 Hz`; spectral centroid mostly `300–700 Hz` with bright transient spikes (`1.2–1.9 kHz`, `onset_flux > 1.3`) at key transitions | Close-mic warm voice + deep sub/low-mid ambient score |

### B. Measured High-Transient SFX / Beat Peaks (From `audio_envelope_30fps.csv`)
| Scene | Max Onset Flux | Story / Visual Beat Synced to Audio Transient |
|---|---:|---|
| **S02** (`f32–53`) | `1.64` | Whip-down whoosh + glowing card shimmer on `"price."` |
| **S03** (`f54–157`) | `1.65` | Counter chime / sparkle + amber door pulse on `"money"` |
| **S07** (`f264–396`) | `1.64` | Rain bed + bicycle rattle & crash impact (`f375–378`) |
| **S08** (`f397–480`) | `1.80` | Upward whoosh tilt + rushing water-wipe crest (`f472–481`) |
| **S13** (`f829–952`) | `1.49` | Mechanical gauge tick + golden chime swell + odometer clicks |
| **S14** (`f953–1080`) | `1.56` | Frog hop + collapse thud (`f1046`) + muffled rack-defocus drop |
| **S19** (`f1501–1644`) | `1.66` | Neon sign hum/flicker synced to 1.43 s light cycle + rain |
| **S21** (`f1743–1901`) | `1.57` | Quiet tense silence -> cloth hood pull-back -> solemn chord |
| **S23** (`f1979–2142`) | **`1.87`** | Swelling warm morning sunrise chord out of gold blow-out (`f1976`) |
| **S24** (`f2143–2334`) | `1.33` | Cold hollow chord drop at `f2137` -> lingering sparse piano note over 30-frame freeze |

### C. Sound-Design Mix Recipe (How to Build Matching Audio)
1. **Narration (Hero Track):** Single calm, intimate, close-mic voice at `~165–175 wpm`. EQ: subtle warm low-shelf `+2 dB @ 120 Hz`, clean de-esser `6–8 kHz`, gentle `3:1` compression so every syllable sits cleanly at `-15 LUFS`. Short `6–12` word sentences with `0.2–0.4 s` dramatic breaths before twists.
2. **Ambient Music Bed:** Slow, sparse, low-register minor piano/pad sitting **`-22` to `-26 dB`** beneath narration (never competing with vocal frequencies). Drop to near-silence right before climax (`S21–S22`), swell gently into the gold blow-out (`S22 -> S23`), then strip down to one cold, hollow sustained note at the `T24` cold flip!
3. **Foley & Transition SFX (Subtle, Never Cartoonish):**
   - Soft air whoosh on camera whips (`T01`, `T06`, `T17`, `T22`).
   - Gentle rain bed in outdoor night streets (`S05, S07, S14, S19`).
   - Mechanical clicks / chimes on hero props (odometer roll, gauge dial, glowing card, lamp switch).
4. **Master Chain:** Run `starter_code/grade_and_finish.sh` which applies FFmpeg `loudnorm=I=-14.0:LRA=2.0:TP=-1.5` and encodes `AAC-LC 44.1 kHz 128k`.
