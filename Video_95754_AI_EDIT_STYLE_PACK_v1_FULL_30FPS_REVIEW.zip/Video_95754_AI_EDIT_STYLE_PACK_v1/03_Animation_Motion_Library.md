# 03 — ANIMATION & MOTION LIBRARY (30 FPS primitives)

Every graphic in `Video-95754.mp4` is built from a small kit of 2D/2.5D motion primitives. There is **no frame-by-frame hand animation** and **no video-diffusion clip**: everything can be rendered with CSS/SVG/Canvas/Remotion/After Effects transforms, stroke-dashoffset, masks, and particle emitters. Use these exact frame counts (at 30 fps) and curves so the motion feels the same.

## 1. Easing curves used
| Name | CSS / cubic-bezier | Where used |
|---|---|---|
| **Ease-out (fast in, soft settle)** | `cubic-bezier(0.22, 1, 0.36, 1)` | Camera pans/zooms, door open, pulse rings, label slides, highlight sweep |
| **Spring pop (overshoot)** | `cubic-bezier(0.34, 1.56, 0.64, 1)` or damping 14 / stiffness 220 | Icon reveal pop, speech bubble pop, pasted card drop, verified seal stamp |
| **Ease-in-out (smooth camera)** | `cubic-bezier(0.65, 0, 0.35, 1)` | Iceberg sink (S05), document pull-out (S03), flashlight sweep (S13), magnifier pass (S15) |
| **Snap impact (ease-in → instant stop)** | `cubic-bezier(0.55, 0, 1, 0.45)` | Fly-swatter slam, stamp press down-stroke, cartridge insert |
| **Linear** | `linear` | Conveyor belt, rotating sunburst rays, slow ambient drift, confetti fall |

## 2. Always-on motion (never leave a graphic still)
Every graphic has at least one of these running the whole shot:
- **Ambient camera push-in:** scale `1.00 → 1.035` over the shot (or `1.04 → 1.00` pull-out), linear.
- **Idle float / bob** (cards, cartridge, "The Prompt" sheet, speech bubble): `y(t) = A·sin(2π·t / T)`, `A = 4–6 px`, `T ≈ 45 frames (1.5 s)`, optional tilt `±0.8°`.
- **Sunburst rotation** (S09, S16, S17): 24–32 radial wedges rotating at **0.25–0.4°/frame** (~8–12°/s), opacity 0.25–0.45.
- **Water caustics / dust motes** (S04, S05, S11, S12): 15–30 small dots (2–5 px, opacity 0.25–0.6) drifting upward at 0.3–0.8 px/frame.

## 3. Text & UI primitives
| # | Primitive | Frames | Spec |
|---|---|---|---|
| **P01** | **Typewriter input** (S04, S07) | **1.2–1.5 fr / char** | Reveal 1 character every 1–2 frames. Keep a `2 px` vertical caret `#111` or `#e8743b` at the right edge of the text; blink 15 fr on / 15 fr off when idle, solid while typing. Optional placeholder text disappears on the frame the 1st character appears. |
| **P02** | **Animated red strike-through** (S07 f422–426) | **4–5 fr** | A `5 px` rounded red `#e03e2d` horizontal bar across the text mid-height; `width: 0% → 100%` left-to-right, ease-out. Hold 5 frames, then clear text on a single frame. |
| **P03** | **Green highlighter sweep** (S07 f483–486) | **4 fr** | Mint `#8fe3b4` rounded pill behind the target words ("bug free"); `scaleX: 0 → 1` from left origin in 4 frames, ease-out. |
| **P04** | **Wavy red underline + circle** (S15 f915–933) | **6 fr + 8 fr** | SVG path (`stroke: #e03e2d`, `stroke-width: 5`, `stroke-linecap: round`). Animate `stroke-dashoffset: length → 0`. A marker sprite follows the path tip `(x(t), y(t))` tilted 40°, then exits right in 4 frames. Pause 4 frames between the underline and the ellipse around the next words. |
| **P05** | **Rounded highlight box draw-on** (S03 f143–148) | **6 fr** | Rounded rect (`stroke: #8b8cf0`, `2.5 px`, soft outer glow `8 px`), `stroke-dashoffset` draw-on + fill opacity `0 → 0.08`. |
| **P06** | **Keycap press** (S08 f523–530) | **8 fr** | Key moves `y: 0 → +5 px`, bevel shadow shrinks `6 px → 2 px`, scale `1 → 0.94`, orange border glow `opacity 0 → 1` over 3 fr, hold 2 fr, release over 3 fr. |
| **P07** | **Pasted card drop + push-down** (S08 f531–536) | **6 fr** | New card: `y: -80 → 0`, `opacity: 0 → 1`, `scale: 0.95 → 1.02 → 1.0` (spring). Existing prompt line moves `y: 0 → +210 px` over the same 6 frames with the same curve, so it looks physically pushed down. |
| **P08** | **Blurred-body "secret prompt" card** (S08) | static | Monospace header with orange asterisk (`✳ be-ambitious`), body is 7 lines of real text blurred with Gaussian σ≈3.5 px or pixelated blocks so the viewer sees "a block of prompt" without reading it (creates curiosity for the CTA). |

## 4. Reveal & activation primitives
| # | Primitive | Frames | Spec |
|---|---|---|---|
| **P09** | **Grey-to-colour icon activation** (S05, S16) | **5 fr** | Before reveal: desaturated + brightness 0.7 + opacity 0.28. On trigger frame: cross-fade to full colour over 3 fr while scaling `0.88 → 1.08 → 1.00` over 5 fr (spring). Fire a **P11 pulse ring** behind it. |
| **P10** | **Label rise-fade** (S05, S16) | **4–5 fr** | Starts 1 frame after its icon: `opacity: 0 → 1`, `y: +8 px → 0`, ease-out. |
| **P11** | **Expanding pulse ring** (S05, S07, S08, S09, S10, S13, S16) | **10–16 fr** | Thin circle (`stroke 2–3 px`, no fill, colour = peach `#f4a37c` / gold `#f5b841` / mint `#6fd89c`). `radius: 20 px → 220–340 px` (ease-out), `opacity: 0.9 → 0` (linear). The universal "something just happened" punctuation mark in this video — used 15+ times. |
| **P12** | **Staggered list cadence** (S05, S16) | **12–13 fr** or **5 fr** step | For spoken concepts (S05): trigger every **12–13 frames (0.42 s)**. For fast checklist items (S16): trigger every **5 frames (0.17 s)**. Never reveal a list all at once. |
| **P13** | **Speech bubble pop** (S12 f742–746) | **5 fr** | Transform origin at the bubble tail tip. `scale: 0.5 → 1.06 → 1.00`, `rotation: -6° → -3°`, `opacity: 0 → 1` in 2 fr. While the character talks, add a tiny wobble `rotation: -3° ± 0.5°` at 6 Hz. |
| **P14** | **2-frame mouth flap** (S12 f745–773) | loop | Alternate mouth closed / half-open / wide-open every 3–4 frames while speech bubble is active. Raise index finger 4 frames *before* the bubble pops (anticipation). |
| **P15** | **Verified seal stamp** (S16 f972–975) | **4 fr** | Gold coin badge starts at `scale: 1.45`, `opacity: 0`, lands at `scale: 0.95 → 1.00` on the card corner in 4 frames; triggers a gold **P11 ring**, a **P16 shine sweep**, and **P17 confetti**. |
| **P16** | **Diagonal shine sweep** (S16 f974–977) | **4 fr** | A white rotated gradient bar (`width 60 px`, `45°`, `opacity 0.55`) clipped to the card/title moves `x: -100 → +600 px`. |
| **P17** | **Confetti burst** (S16 f975–1003) | **28 fr** | ~35 particles (6×12 px rectangles + 6 px dots in `#f67644 #f5c242 #45b8ac #e03e2d #ffffff`) spawn along the top edge of the card with initial velocity `vy = -4..-1 px/fr`, `vx = -3..+3`, gravity `+0.25 px/fr²`, angular velocity `±8°/fr`, fade out over the last 6 frames. |

## 5. Camera & transition-inside-shot primitives
| # | Primitive | Frames | Spec |
|---|---|---|---|
| **P18** | **Document zoom-out + scroll** (S03 f122–150) | **28 fr** | Place the S02 blockquote inside a tall full-article layout (2500 px high). Animate container `scale: 1.0 → 0.42` and `y: -600 → 0` with `ease-in-out`, then draw **P05** around the blockquote. |
| **P19** | **Iceberg vertical dive** (S04→S05 f246–300) | **54 fr** | Build one tall canvas (~720 × 2200 px): sky + chat box at top (y 0–550), waterline at y 550, underwater berg + 4 icons at y 550–1700, deep navy water below. In S04 show the top in the 720×640 split pane. At f246 switch to full-screen 720×1280 and pan the camera `y: 0 → +520 px` over 54 frames (`ease-in-out`). |
| **P20** | **Door swing + light flood + walk-through zoom** (S11 f715–732 → S12) | **6 fr + 12 fr** | Door leaf in a 3D perspective container (`perspective: 900px`, `transform-origin: left`): `rotateY: 0° → -78°` over 6 frames (ease-out). Inside the frame: bright cream radial gradient + god-ray fan behind the frame (`opacity: 0 → 0.7`). Then camera `scale: 1.0 → 1.32` centred on the doorway over 12 frames (ease-in) and hard-cut at peak brightness to S12 on the same stage. |
| **P21** | **3D Y-axis card flip** (S16 f936–944) | **8 fr** | Front card ("Why is checkout so slow?"): `scaleX: 1.0 → 0.0` over 4 frames (ease-in, f936–940). At `scaleX = 0` swap to back card ("Expert version") and animate `scaleX: 0.0 → 1.04 → 1.00` over 4 frames (ease-out, f941–944). Fade in the sunburst rays during the second half of the flip, and fire a gold **P11 ring** on frame 944. |
| **P22** | **Magnifying glass lens pass** (S15 f883–912) | **30 fr** | Glass sprite moves `x: 160 → 560 px` across the text (`ease-in-out`). Inside the circular lens mask (radius ~68 px), render a second copy of the card scaled **1.35×** around the lens centre so the letters visibly magnify as the lens passes over them. |

## 6. Physics & state-machine primitives (the metaphor payoffs)
| # | Primitive | Spec |
|---|---|---|
| **P23** | **Swat → crack accumulation → heal + drop** (S07) | Swatter pivots around right-side wrist (`rotate: +25° → -5°` in 3 fr on each slam). Each slam adds: (a) a 5-point yellow impact star for 4 fr, (b) 1 new SVG crack group on the screen, (c) 1–2 new crawling bugs. On "bug free" (f488): fire **P11 mint ring** (`r: 40 → 360` in 10 fr) + 6 golden swoosh arcs; set all cracks `opacity → 0`; knock bugs outward along radial vectors; release the swatter with gravity (`y += v`, `v += 1.4 px/fr²`, `rotate += 5°/fr`) so it falls onto the desk. Leave a `4 px` mint glow border around the phone. |
| **P24** | **Conveyor + periodic stamp press** (S10) | Cards spaced by 240 px move at `x -= 4 px/fr` (linear). Every 24 frames, when a card is centred at `x = 360`, the piston extends `y: 0 → +48 px` in 3 fr, holds 2 fr, retracts in 4 fr; the card acquires an orange top-tab child element (`✳ be-ambitious`) and a **P11 ring** fires at the contact point. |
| **P25** | **Cartridge insert → 5-channel power-up** (S09) | Idle hover (`y = ±5 px` sine) → insert `y: 0 → +95 px` clipped by the slot mask in 6 fr → fire ring → light 6 LEDs sequentially (2 fr per LED, `#3a2218 → #ffcf4a` + outer glow) → gauge needle `rotate: -65° → +58°` over 9 fr (overshoot `+62°`) → console shake `x = ±3 px, y = ±2 px` random at 30 Hz + 4 yellow lightning zig-zags flashing on/off every 2 fr → sunburst rays `opacity: 0 → 0.4` behind. |
| **P26** | **Searchlight sweep + bulb ignition cascade + global warm shift** (S13) | Trapezoid beam (`fill: rgba(255,244,200,0.22)`, Gaussian blur 18 px, pivot at `(540, 640)`) sweeps `angle: -35° → +20°` over 35 fr. When the beam axis passes a bulb, and then in a fast 15-frame cascade across all remaining bulbs (1–2 fr apart): bulb fill `#5c6e8a → #ffe066`, add radial glow (`r = 70 px`, `#ff9d2e`, opacity 0.55) + small **P11 gold ring**. As the lit-bulb count goes from 2 → 13 (f815–830), cross-fade the sky background from navy `#0e0b1d` to warm brown/amber `#4a3122`. |
