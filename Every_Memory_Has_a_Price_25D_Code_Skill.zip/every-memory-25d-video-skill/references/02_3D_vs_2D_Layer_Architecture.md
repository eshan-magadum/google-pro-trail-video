# 02 — 3D vs 2D Layer Architecture & Planning Bible

> **Purpose:** This is the master engineering guide for deciding **what belongs in 3D behind/around the scene** versus **what belongs in 2D** so that every generated video achieves the exact physical depth, lighting, and flat-cel charm of *Every Memory Has a Price*.

---

## 1. The Core Hybrid Principle: "Lit 3D Stage, Flat 2D Actors"

Why does *Every Memory Has a Price* look dramatically richer than standard 2D explainer animation, yet warmer and more iconic than pure 3D CGI?
Because it strictly separates **Spatial Reality (3D)** from **Graphic Storytelling (2D)** across 6 composited depth planes:

```text
[Z = FARTHEST]
  Layer 1 (3D) : Sky dome / distant city skyline bokeh / horizon & exponential fog
  Layer 2 (3D) : Architectural set & terrain (walls, floors, counters, streets, pools, rooms, shelves)
  Layer 3 (3D) : 3D Practical lights, shadow maps, volumetric cones, & painterly wet reflection decals
  Layer 4 (2D-in-3D) : Depth-sorted 2D Cel Characters & 2D Hero Props (RGBA billboards w/ contact shadows)
  Layer 5 (3D) : Foreground 3D Occluders (railings, glass panes, counter edges, bedposts, door jambs)
  Layer 6 (2D Screen HUD) : Selective post-bloom, diagonal rain, dust/halos, vignette, flash, 1-2 word captions
[Z = NEAREST / LENS]
```

**The Golden Rule of Integration:**
> **2D characters live physically INSIDE the 3D z-buffer (`Layer 4`), NOT pasted flat on top of a background image.**
> Because they sit between `Layer 2` (3D background) and `Layer 5` (3D foreground occluders), a camera dolly automatically creates true parallax, a railing or bedpost naturally passes in front of a character's stick legs, and a glowing 3D shop window naturally sits behind their silhouette.

---

## 2. Explicit Classification Matrix: What Goes in 3D vs What Goes in 2D

### A. ALWAYS BUILD IN 3D (Three.js Geometry, PBR Materials & Lights)
| Category | Specific Elements | Why 3D Is Mandatory | Code Implementation Rule |
|---|---|---|---|
| **Architecture & Interiors** | Pawn shop walls, cubby-shelf grid, wooden counter, hospital rooms, checkerboard corridors, brick townhouses, deli facades, awning canopies, door jambs, window recesses | Wide-angle vertical perspective (`68–76°` vFOV) + smooth camera pitch/dolly/orbit require true foreshortening and parallax | `BoxGeometry` / `PlaneGeometry` with procedural Canvas2D `map` + `bumpMap` (`MeshStandardMaterial`, `roughness: 0.78–0.92`) |
| **Ground, Floors & Water** | Wet concrete sidewalks, tiled alley floors, hospital checkerboard tile, wooden docks, resort pool decks, pool water surfaces | Ground planes establish vanishing points, cast-shadow reception, and tilt-down camera sweeps (S01->S02, S07, S14) | Matte-wet `MeshStandardMaterial` (`roughness: 0.94, metalness: 0`) + custom soft `AdditiveBlending` reflection decals (**never** clearcoat!) |
| **3D Lighting & Shadows** | Cool indigo/periwinkle night fill (`HemisphereLight`), shadow-casting moonlight/sunlight (`DirectionalLight`), localized warm practical spill (`PointLight` / `SpotLight`) | Gives the environment true three-dimensional volume, wall falloff, and glowing pools of warm light in cold darkness | Enable `PCFSoftShadowMap` (2048px); keep practical point light decay `1.4–1.6` so warm pools stay localized |
| **3D Practical Fixtures** | Hanging dome lamps, brass extractor domes & ceiling tubes, wall sconces, cash registers, wooden benches, hospital beds, IV poles, glowing shop windows | Rotating or dollying past lamps, counters, and extractor domes sells solid physical space | Group fixtures as 3D meshes with emissive bulb cores (`color > 1.0` or `MeshBasicMaterial` above bloom threshold `0.89`) |
| **3D Foreground Occluders** | Stoop iron handrails, storefront glass panes (T02), hospital bed footboards (S15/S23), desk corners (S17), hooded foreground silhouettes (S17) | Passing *in front of* 2D characters is the #1 visual cue that proves the world is 3D | Place at Z closer to camera than `Layer 4` billboards; camera movement creates dramatic foreground parallax |
| **3D Spatial Glass & Mirrored Signage** | Storefront windows with readable signage from outside (S04/S05) and **mirrored** lettering from inside (S21 `SEIROMEm`), translucent glass edges | Pulling backward *through* the shop glass (T02 `f153–164`) is only believable with real 3D transparent planes | `MeshPhysicalMaterial` or `MeshBasicMaterial` (`transparent: true, opacity: 0.18–0.35`, `DoubleSide`) with UV-flipped text when viewed from behind |
| **Depth Fog & Sky Backdrop** | Exponential night fog (`FogExp2`), distant glowing city skyline bokeh band, sunlit resort sky dome, twilight gradient sky | Separates foreground/midground from background and lifts deep distant shadows into saturated indigo | `scene.fog = new THREE.FogExp2('#161D4C', 0.014–0.018)` |
| **Mechanical Hero Props (When Rotating in Perspective)** | Rotating brass `HAPPINESS` gauge housing (S13), copper extractor dome + tube (S10/S22), floating backlit memory chip `MC-4-2018` (S02/S22), rolling odometer drum (S10) | Camera tilts around/up these props; 3D bevels catch warm rim light while their **face artwork** stays crisp 2D CanvasTexture | Build outer casing in 3D geometry; paint crisp 2D gauge dial / chip artwork / digits on procedural `CanvasTexture` |

### B. ALWAYS BUILD IN 2D (Canvas2D RGBA Billboards, Textures & Screen Overlays)
| Category | Specific Elements | Why 2D Is Mandatory | Code Implementation Rule |
|---|---|---|---|
| **All Characters** | Jerry, Little Brother, Hooded Stranger, Landlord, Bike Kid, Rich Loungers, Butler, Poor Elders, Bystanders | Thick uniform black ink outlines (`~1%` width), oversized flat-cel round heads, stick limbs, and expressive face swaps MUST stay crisp graphic 2D — never 3D models | Draw on high-res `1024×1536` RGBA Canvas2D (`cel_character_rig.js`), mount on `PlaneGeometry` with `MeshBasicMaterial` (`alphaTest: 0.05`, Y-axis billboard) |
| **Facial Expressions & Micro-Acting** | Double-ring eyes, empty dot eyes (hollow), dash eyes, squeezed-x eyes, arched brows, wavy anxious mouth, toothy grin, sweat drop, tear, tremor lines, spiky vs limp hair | Fast, clean, frame-accurate graphic swaps (e.g. 2-frame wink `f2–3`, instant dot-eye switch `f2203`) read immediately on mobile screens | State-driven redraw or pre-baked texture cache swapped on exact frame numbers (`hero.mesh.material.map = texState`) |
| **Limb & Ball-Hand Gestures** | Stick arms/legs, round black ball-hands pressing buttons (S18), holding ledger (S20), offering Polaroid (S24), pedaling/crashing bike (S07), frog hopping (S14/S16) | Rubber-hose simplicity with zero fingers is the signature charm | Draw quadratic Bezier ink limbs (`lineCap = 'round'`) + filled ink circle ball-hands |
| **Flat Print Artifacts & In-World Graphics** | Framed elder photos (S12), `"the frog! :)"` Polaroid print & white border (S15–S17), `"MEMORY SAVINGS"` ledger page & `SOLD` stamps (S20), birthday card (S18), `"WE BUY SUMMERS"` & `"MEMORIES BOUGHT & SOLD"` graphic layouts | Crisp typography and flat illustration detail look sharpest as 2D Canvas artwork (either mapped onto a 3D card plane or filling screen HUD) | Render at 2× resolution on Canvas2D; mount on 3D plane when physically tilted/held, or draw directly on HUD overlay during full-frame macro reads (S20 ledger) |
| **Weather & Atmospheric Particles** | Crisp diagonal falling rain streaks (S05, S07, S19), tiny floating light sparkles/dust motes (S03, S13, S17), water-splash droplets (S16) | Thin uniform diagonal streaks with gradient alpha tails read cleanly at 720p/1080p without noisy 3D aliasing | Draw procedurally on the 2D HUD overlay canvas with deterministic seeded RNG (`mulberry32`) + frame velocity |
| **Emotional VFX & Light Overlays** | Blue-white memory-drain head halo (S19 `f1607–1640`), diagonal Polaroid specular glare (T08), downward caustic wipe glow band (T04), radial indigo vignette, gold/white blow-out flashes (T08/T22) | Graphic overlays give exact artistic control over luminance peaks and color storytelling | Composite on the 2D overlay canvas after `EffectComposer.render()` |
| **Captions** | 1–2 word centered storytelling captions (`y = 70%`) | Must stay 100% razor-sharp, unbloomed, and unaffected by 3D camera roll or DOF blur | Always draw LAST on the 2D overlay canvas (`#FCFDFD` fill + `#07060D` thick stroke) |

---

## 3. Five Technical Bridges That Fuse 3D and 2D Seamlessly

If you simply drop 2D sprites into a 3D scene naively, they look "pasted on." Use these 5 verified engineering rules (proven in `deli_scene/` and `starter_code/`):

1. **Tint-Only Character Lighting (Zero 3D Face Shading):**
   - Give every 2D character billboard `THREE.MeshBasicMaterial` (so 3D `PointLight`s never create bumpy gradients across their flat faces), AND multiply `material.color` by a subtle scene-matched ambient tint (`#DED6EC` in gloom, `#F5E5D5` in warm honey, `#B9C8F0` in cold cobalt, `#E6B8BE` in red corridor).
   - Inside the 2D character canvas itself, bake **one soft lavender shadow crescent** on the shadow side + **one subtle warm rim gradient** matching the scene's key light direction.
2. **Bloom Threshold Firewall (`0.88–0.90`):**
   - Keep `UnrealBloomPass` threshold at `0.88–0.90` (`strength: 0.20–0.26`).
   - Because 2D character billboard tints stay slightly below pure white (`<= 0.88` luminance), **only** emissive 3D shop windows, lamps, and glowing cards trigger bloom — 2D characters and ink outlines stay 100% crisp!
3. **Grounded Contact Shadows:**
   - Every grounded 2D character billboard spawns a tiny horizontal `PlaneGeometry` at `y = groundY + 0.015` with a soft radial indigo shadow (`rgba(10,12,34,0.58)` -> `0`) directly beneath their stick feet. Without this, 2D characters look like they are floating.
4. **Matte-Wet Reflections (Zero Clearcoat Balls):**
   - Never put `clearcoat: 1.0` on wet streets under `PointLight`s (creates artificial white polka-dot highlights). Keep ground `roughness: 0.94, metalness: 0.0` and place soft `AdditiveBlending` radial gradient planes (`addWetReflectionDecal`) aligned underneath glowing windows and streetlights.
5. **Selective DOF Separation (Blurring 3D Behind Sharp 2D):**
   - In shallow-DOF shots (S01, S02, S15, S17, S23, S24), keep the focal 2D character or hero prop razor-sharp while softening the distant 3D background wall (either via pre-blurred background textures on distant wall planes, a depth-masked post-blur pass, or a two-layer composite where background 3D renders with CSS/shader Gaussian blur `8–24 px` before foreground 2D/3D renders sharp on top!).

---

## 4. Complete 24-Scene 3D-vs-2D Breakdown of `Every Memory Has a Price.mp4`

| Scene | 3D Background Set | 3D Lighting & Wet Reflections | 3D Foreground Occluders | 2D Characters & Hero Props | 2D Particles / VFX / HUD | DOF Mode |
|---|---|---|---|---|---|---|
| **S01** Hero Intro (`f1–31`) | Pawn shop wood counter, dark walls, hanging ceiling lamp, back door | Cool indigo fill + warm counter spill + lamp halo | None (camera swings past Jerry) | Jerry (blinking->wide eyes), hooded stranger behind counter, glowing card edge | Soft vignette, 3-frame ghost blend on T1 whip, captions | Shallow (`39×` ctr/brd) |
| **S02** Card Macro (`f32–53`) | Counter wood surface, heavily blurred cash register & shelf depth | Pulsing warm card point light (`f43–46`) + glossy counter sheen | Blurred counter rim | Crisp 2D glowing memory card graphic on 3D chip plane | Pulse bloom halo, vignette, captions | **Extreme Macro Shallow (`159×`)** |
| **S03** Pawn Counter (`f54–157`) | Full shop interior: backlit cubby-shelf wall, register, amber door window | Deep indigo room (`#1B1731`) + pulsing amber door window (`f112–140`) | Counter corner | Hooded stranger (widening toothy grin, glowing amber pupils) | Tiny counter sparkle (`f126–130`), heavy vignette (`0.41`), captions | Shallow (`25×`) |
| **S04** Glass Wipe (`f158–168`) | Shop interior shrinking into 3D storefront window box | Transitional blue alley fill + warm interior glow | **3D Storefront Glass Pane** sweeping across lens | Jerry visible behind glass shrinking into window | Subtle glass specular streak, captions | Moderate (`14×`) |
| **S05** Rainy Alley (`f169–203`) | 3D brick alley canyon, wet tiled walkway, distant bokeh skyline, glowing `MEMORIES` lightbox | Saturated indigo (`#1B1D58`) + warm storefront & far skyline spill + wet tile reflections | Alley wall corners | Small silhouetted figures inside window reflection | **Diagonal 2D rain streaks**, vignette, captions | Moderate (`5.4×`) |
| **S06** Extractor Shop (`f204–263`) | Checkerboard tile floor, barber-style extractor chair, glowing overhead dome lamp, window | Lavender-white bright interior (`luma 110`) + massive bloom flash (`f238–246`) | Rain-spotted entry glass (T04) | Customer in chair (closed happy eyes), bald assistant, rising glowing card/jar | Lavender-white bloom wash (`f238–246`), captions | Shallow (`6.0×`) |
| **S07** Deli Street (`f264–396`) | Brick townhouse, concrete stoop, Deli Grocery facade, glowing grocery interior, red awning, upper windows, wet sidewalk, alley fence | Periwinkle night fill + broad warm Deli window spill + smooth wet sidewalk reflection decal | **3D Stoop Iron Handrail** (occludes landlord's arm/legs!) | Angry landlord, worried woman, background bystander, pedaling/crashing bike kid | **Diagonal 2D rain streaks**, indigo vignette, captions | Moderate (`7.0×`) |
| **S08** Dutch Wall Climb (`f397–480`) | Towering Dutch-tilted (`~25°`) brick/concrete city wall, row of warm wall sconces, hanging emblem banner, purple sky | Indigo sky + warm orange sconce cones + dramatic top light shafts | Wall ledges / cables | Tiny fallen bike kid at bottom-left for 3D continuity | God-ray sheen, downward caustic wipe leading edge (T04), captions | Deep-to-Moderate (`3.6×`) |
| **S09** Rich Pool (`f481–564`) | Resort pool, turquoise water plane w/ animated caustics, sun deck, pink hedge, palm trees, floodlight sun-wheels, resort wall | Bright daylight sun (`luma 167`, zero heavy vignette `1.02`) | Pool coping foreground | Sunhat lounger w/ sunglasses, white-jacket butler leaning in w/ tray | Animated caustic water shimmer, white blow-out transition (T08), captions | Deep Focus (`sharp_all 895`) |
| **S10** Bahamas Dome (`f565–648`) | Bright resort room window, copper extractor dome descending on 3D ceiling pipe, golden 3D odometer pedestal | High-key sunlit room (`luma 176`, bloom `29%`) + golden dome rim halo | Odometer pedestal rising into foreground | Hawaiian-shirt guy w/ snorkel & closed blissful eyes; rolling 2D digit wheels (`0299 -> 300+`) | Dome rim glow, rolling digit motion blur (`f616`), captions | Deep Focus (`sharp_all 912`) |
| **S11** Couch Pull-Back (`f649–720`) | Sunlit living room, cream sofa, wide glass window overlooking pool & pink flamingo float | Bright cyan-cream daylight (`luma 170`) | Sofa arm / table corner | Relaxed guy on couch, pink flamingo in pool | Vertical blurred white-blue light-streak sweep (T09 `f705–720`), captions | Deep -> Blur Wipe |
| **S12** Poor Bench (`f721–828`) | Weathered chain-link fence, brick wall, red `"MEMORIES BOUGHT & SOLD"` sign, wooden park bench | Dusk violet-mauve (`#281838` -> warm peach `#F6B182`) | Vertical foggy light columns (`f721–780`) | Curly-grey elder woman, bald glasses man, 3rd figure exiting left; **2D framed photos** (lifted `f820–828`) | Clean crisp render (sharpest scene in film: `sharp_all 1,905`!), captions | **Crispest Deep Focus** |
| **S13** Happiness Gauge (`f829–952`) | Backlit memory cubby wall, counter, buckets left/right, **3D brass gauge housing** & odometer box | Dark indigo (`#15142D`) -> **full golden dial flood (`f893–900`)** | Gauge bezel & top knob | Hooded stranger (bored droop -> huge toothy grin + glowing amber eyes `f901+`); crisp 2D dial face, swinging needle, `$` odometer | Gold sparks (`f866–884`), iris-ring dissolve out (T11), captions | Shallow (`8.6×`, `66×` vert) |
| **S14** Night Street (`f953–1080`) | Night city street, overhead pennant string lights, glowing shop windows, fire hydrant, wet pavement reflection | Deep saturated indigo (`#151B5E`, `shadow_sat 0.78`) + warm shop windows | Foreground wet curb | Jerry (alarmed), Green-cap Little Brother (bouncing -> collapse `f1046`), Landlord, **hopping green frog** | Heavy rack-defocus bokeh (`f1066–1080`) isolating sharp frog, captions | Moderate -> **Heavy Rack DOF** |
| **S15** Hospital Bed (`f1081–1176`) | Dim indigo hospital ward, bed headboard, bedside cabinet, warm glowing bedside lamp orb, wall monitors | Deep night blue (`#191344`) + intimate warm amber lamp orb between brothers | **3D Dark Metal Bed Footboard** + persistent foreground frog! | Sick brother in dotted gown (sad droop `f1117+`), Jerry sitting right (tender smile -> deadpan); **2D Polaroid** on stand | Diagonal white specular glare on Polaroid (`f1165–1179`), captions | Shallow (`28×` ctr/brd) |
| **S16** Golden Lake (`f1177–1272`) | 3D wooden dock extending over reflective lake, golden-hour low sun, distant treeline, foreground reeds & lily pads | Warm golden-hour sunlight (`luma 125`, honey sky + cool teal water) | Foreground 2D/3D reeds & lily pads | Child Jerry (red shirt w/ net), Little Brother (green cap), **leaping animated frog** (`f1201–1237`) | Water ripples, spray droplets, Polaroid white border slide-off / re-frame (T13/T14), captions | Moderate-Deep (`8.5×`) |
| **S17** IV Pole & Desk (`f1273–1418`) | Dark hospital corridor w/ IV stand + round gauge -> transitions to dark pawn desk w/ single desk lamp | Darkest gloom (`luma 45.5`, `#11112D`, `vig 0.34`) + focused peach desk-lamp cone | **Dark silhouette of Hooded Stranger** in far-left foreground! | Jerry (wide eyes -> wavy anxious mouth + sweat drop `f1302–1320` -> sideways glance + single tear `f1399–1405`), Polaroid clipped to IV pole | Tiny glowing desk sparkles (`f1343`, `f1385`), face-position dissolve, captions | Shallow (`20×`) |
| **S18** OPERATING Hall (`f1419–1500`) | Teal-and-white checkerboard hospital corridor, double doors, overhead fluorescent light, olive gauge box on pole, **`OPERATING` lightbox** | Cool clinical teal (`luma 124`) -> **RED `OPERATING` bleed (`f1484–1498`)** washing wall & floor | Olive gauge pole foreground | 2D Birthday card macro -> black **ball-hand** pressing box (`f1442`) -> Jerry (sly -> sigh -> serene closed eyes `f1481–1500`) | Red crimson bloom wash, orange/blue overlay dissolve (T18), captions | Shallow-Moderate (`10×`) |
| **S19** WE BUY SUMMERS (`f1501–1644`) | Rainy night street, slanted mustard `"WE BUY SUMMERS / cash today, any grade"` sign, hanging spot lamp, dark pavement | **1.43s alternating Warm Orange ↔ Cold Lavender light pulse** (`f1513–1640`) | None (tight portrait) | Jerry carrying stacked memory boxes (wide eyes -> tired half-lid -> head droops back eyes closed `f1573+`) | **Diagonal rain** + growing **blue-white memory-drain halo** around head (`f1607–1640`), captions | Shallow (`7.1×`) |
| **S20** Sickbed & Ledger (`f1645–1742`) | Dim blue sickroom bed -> giant close-up over open book | Cold indigo (`#12102E`, `shadow_sat 0.71`) + subtle shimmer on gold ledger row | Book edges | Sick brother sunk in pillows, giant worried Jerry holding ledger with ball-hand; **crisp 2D `"MEMORY SAVINGS"` ledger** (`2025..2019 SOLD`, **`YEAR 2018 ⭐ 🐸` gold**, `2017–2016 SOLD`) | Subtle gold row shimmer (`f1709–1740`), upward dissolve to shop (T21), captions | Shallow -> Flat Crisp Read |
| **S21** Unhooded Shop (`f1743–1901`) | Inside pawn shop looking OUT through glass window (**mirrored** `SEIROMEm / dlos & thguob`), overhead lavender dome lamp, red chair arms | Cold lavender interior (`#150F28`, `vig 0.27`, bloom `8.4%`) | Red chair arms at bottom edge | Stranger **pulling hood back** (`f1773–1776`) revealing round worried white face (tremor lines + wink/flinch `f1840–1846` -> shocked); Jerry resolute (`f1889+`) | Tremor strokes, cold lavender rim glow, captions | Shallow (`6.2×`) |
| **S22** Climax Extraction (`f1902–1978`) | Lavender dome lamp descending on Jerry, vertical tube, dark cubby-grid wall & mirrored shop letters receding behind | Deep navy (`#121331`) -> **full Gold-White Radial Blow-Out (`f1957–1976`, peak `f1969–1973`)** | Blue pipe at bottom-left | Jerry under dome -> **3D/2D glowing backlit memory chip (`MC-4-2018`)** rising & blooming into screen | Swirling letters + expanding gold-white radial flare, captions | **Heavy Shallow (`40×`)** |
| **S23** Morning Ward (`f1979–2142`) | Sunlit hospital ward, royal-blue window mullions, wall covered in get-well drawings (**heavily blurred**), red bedspread, bed headboard | Warm golden-cream morning sunlight (`luma 137`, `b-r = -43.1`, plum shadows `#351834`) | Red bedspread foreground | Healed brother waking: **limp hair -> springs into spikes (`f2008–2012`)**, beaming grin, arms behind head, holding Polaroid, squeezed-x smile (`f2116–2130`); frog plush on bedpost | Soft morning bloom, 6-frame face-match cross-dissolve (T24), captions | **Heavy BG Blur (`280×` vert)** |
| **S24** Cold Cobalt End (`f2143–2334`) | Same hospital room (heavily blurred wall & windows) — **instant cold cobalt light flip** (`b-r = +47.3`) | Deep cold cobalt (`#161C5F`, `shadow_sat 0.807` highest in film!), diagonal faint window light shafts (`f2265+`) | Red bed foreground | Jerry right (wavy mouth `f2145` -> blinks -> **ring eyes turn to EMPTY DOTS `f2203+`**); ball-hand enters w/ Polaroid; warm little brother left-bottom (happy -> squiggle -> **hurt sad frown `f2285–2334`**) | Diagonal faint light shafts, **30-frame motionless freeze hold (`f2305–2334`)**, captions (`"one."`) | **Heavy BG Blur (`97×` vert)** |

---

## 5. Quick Decision Tree for Any New Scene Element

When planning a new scene from a user's script, run every noun/element through this 4-step filter:

1. **Does it define the physical space, ground, wall, lighting, or perspective lines?**
   - **YES -> 3D Mesh + Procedural Texture + 3D Lights** (`Layer 1–3`).
2. **Will the camera pass close to it or orbit around it to create foreground depth over a character?**
   - **YES -> 3D Foreground Occluder** (`Layer 5`, e.g., railing, window frame, table edge, tree branch, doorway).
3. **Is it a living character, creature, facial reaction, stick-limb gesture, or flat printed graphic (photo, note, ledger, card)?**
   - **YES -> 2D High-Res Canvas2D Art** (`Layer 4` depth-sorted billboard with `MeshBasicMaterial` + ground contact shadow + tint `< 0.88`).
4. **Is it weather, lens/emotional overlay, light-flash transition, or spoken caption?**
   - **YES -> 2D Screen HUD Overlay Canvas** (`Layer 6`, drawn cleanly after `EffectComposer.render()`).
