#!/usr/bin/env node
// Deterministic 2.5D Frame Renderer via Headless Chromium + SwiftShader WebGL2.
// Usage:
//   Single preview PNG: node render_frames.mjs --preview --frame=15 --w=720 --h=1280
//   Full 30-FPS MP4:    node render_frames.mjs --frames=150 --fps=30 --w=720 --h=1280 --out=out/raw.mp4
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, v] = a.replace(/^--/, '').split('=');
    return [k, v === undefined ? true : v];
  })
);

const W = Number(args.w) || 720;
const H = Number(args.h) || 1280;
const FPS = Number(args.fps) || 30;
const PREVIEW = Boolean(args.preview);
const TOTAL_FRAMES = PREVIEW ? 1 : (Number(args.frames) || 150);
const START_FRAME = Number(args.frame) || 0;
const OUT_PATH = path.resolve(__dirname, args.out || (PREVIEW ? 'out/preview.png' : 'out/raw.mp4'));
const CHROMIUM = process.env.CHROMIUM_BIN || '/usr/bin/chromium';

fs.mkdirSync(path.dirname(OUT_PATH), { recursive: true });
const framesDir = path.join(__dirname, 'out', '_frames');
if (!PREVIEW) fs.mkdirSync(framesDir, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
};

const server = http.createServer((req, res) => {
  const urlPath = (req.url || '/').split('?')[0];
  const filePath = path.join(__dirname, urlPath === '/' ? 'index.html' : urlPath);
  if (!filePath.startsWith(__dirname) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404); res.end('Not found'); return;
  }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
});

await new Promise((r) => server.listen(0, '127.0.0.1', r));
const { port } = server.address();

function captureFrame(frameIdx, targetPng) {
  return new Promise((resolve, reject) => {
    const url = `http://127.0.0.1:${port}/index.html?w=${W}&h=${H}&frame=${frameIdx}`;
    const proc = spawn(CHROMIUM, [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu-sandbox',
      '--enable-webgl',
      '--use-gl=angle',
      '--use-angle=swiftshader',
      '--enable-unsafe-swiftshader',
      '--hide-scrollbars',
      '--force-device-scale-factor=1',
      `--window-size=${W},${H}`,
      '--virtual-time-budget=2500',
      `--screenshot=${targetPng}`,
      url,
    ], { stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '';
    proc.stderr.on('data', (d) => { err += d.toString(); });
    proc.on('close', (code) => {
      if (code !== 0 || !fs.existsSync(targetPng)) reject(new Error(`Frame ${frameIdx} failed (${code}): ${err}`));
      else resolve();
    });
  });
}

try {
  if (PREVIEW) {
    await captureFrame(START_FRAME, OUT_PATH);
    console.log(`Rendered preview: ${OUT_PATH} (${W}x${H})`);
  } else {
    console.log(`Rendering ${TOTAL_FRAMES} frames (${W}x${H} @ ${FPS} fps)...`);
    for (let i = 0; i < TOTAL_FRAMES; i++) {
      const fnum = START_FRAME + i;
      const png = path.join(framesDir, `f_${String(i).padStart(5, '0')}.png`);
      await captureFrame(fnum, png);
      if ((i + 1) % 30 === 0 || i === TOTAL_FRAMES - 1) {
        console.log(`  rendered ${i + 1}/${TOTAL_FRAMES}`);
      }
    }
    await new Promise((resolve, reject) => {
      const ff = spawn('ffmpeg', [
        '-y', '-loglevel', 'error',
        '-framerate', String(FPS),
        '-i', path.join(framesDir, 'f_%05d.png'),
        '-c:v', 'libx264', '-preset', 'medium', '-crf', '14',
        '-pix_fmt', 'yuv420p',
        '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
        '-movflags', '+faststart',
        OUT_PATH,
      ], { stdio: 'inherit' });
      ff.on('close', (c) => (c === 0 ? resolve() : reject(new Error(`ffmpeg exited ${c}`))));
    });
    console.log(`Encoded MP4: ${OUT_PATH}`);
  }
} finally {
  server.close();
}
