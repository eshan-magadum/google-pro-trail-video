# 02 — SHOT-BY-SHOT BREAKDOWN (all 18 shots)

Frame numbers are 1-indexed at 29.97 fps (time = (frame−1)/29.97). Stats come from `data/scenes.json`: luma 0–255, saturation 0–255, flow = mean optical-flow px/frame at 180×320. Palettes are k-means centres sorted by area. Reference images: `reference_frames/Sxx_*`. Cut strips: `transitions/cut_into_Sxx_*`.

---
### S01 · f1–53 · 0.00–1.77 s · SPLIT · HOOK
**Script:** "Anthropic engineer just built the most…"
**Top:** near-black `#11100e` background with a soft radial lift in the centre. A **framed artwork card** (Goya etching of flying men with bat wings, sepia/grey) with a cream mat and rounded ~12 px corners, centred at y≈430, ~585 px wide. A **source pill** in the bottom-left corner of the card: white rounded pill, black Anthropic "A\" logo + "Anthropic" in serif, small lavender dot. (Looks like a link-preview / news-source tag.)
**Motion:** the card **slowly pushes in and drifts** (f1 is slightly larger and offset, then it settles and keeps drifting about 2% over the shot). The source pill slides in with the card.
**Bottom:** speaker, eyes closed at start (mid-blink and speaking), hands come up in a gesture f37–53.
**Captions (on seam):** Anthropic(1) · engineer(15) · just built(28) · the most(43).
**Why it works:** brand authority + human face + an intriguing image in the first frame. There is no title card and no intro.
Stats: luma 66, sat 80, flow 0.42 · palette `#11100e #40383c #b29289 #7a6164`.

### S02 · f54–121 · 1.77–4.04 s · FULL_GFX · THE ARTIFACT
**Script:** "…powerful prompt that I have ever seen,"
**Visual:** full-screen dark document (`#100f0b` background, soft centre lift / vignette). Small grey serif intro line "A simple prompt that often helps me:", then a **blockquote with a 4 px lavender `#8b8cf0`-ish left rule**. Body text is cream serif (~26 px): "I want a deeper version of this task, not a bigger one. Before rewriting it: (1) say what a top professional… (4) say what, other than you or me, would show the result is right. Then rewrite my prompt to ask for exactly that."
**Motion:** very slow push-in plus a slight upward drift (≈3% over 2.2 s). The text is readable and the shot holds long enough to screenshot.
**Captions (below the text block, y≈835):** powerful(54) · prompt(72) · that I have(84) · ever seen,(97).
Stats: luma 25.5 (darkest shot), sat 68, flow 0.30 · palette `#100f0b #1a191b #474646 #7b7a79`.

### S03 · f122–175 · 4.04–5.84 s · FULL_GFX · CONTEXT PULL-OUT + HIGHLIGHT
**Script:** "…but nobody is using it."
**Visual:** hard cut to a **zoomed-out** view of the same page. The surrounding article is now visible: bullet paragraphs ("Produce new knowledge", "Challenge what you know", "Use an outside judge" with bold lead-ins), and a small "Range" label under the prompt.
**Motion:** continuous **camera pull-out and upward scroll** f122–150 (flow peaks here). Around f143–148 a **rounded lavender/purple highlight rectangle is drawn around the blockquote** (stroke ~3 px, radius ~8 px, glow), and it stays on. f150–175 the page holds as a tiny full-page view with a slight drift.
**Meaning:** "it's buried in a long doc, so nobody sees it".
**Captions:** but nobody is(122) · using it(156).
Stats: luma 23, sat 73, flow 0.72.

### S04 · f176–245 · 5.84–8.17 s · SPLIT · ICEBERG TIP + TYPEWRITER
**Script:** "When prompting, most of us just describe the task."
**Top:** bright white sky with a radial glow. A **Claude-style chat input card** (white, soft shadow, radius ~20 px; "+" icon; model picker "Opus 5.5 ⌄"; orange rounded send button with ↑) sits **on the tip of an iceberg**. Two suggestion chips, "Write a blog post" (left) and "Summarize this" (right), sit on small floating ice floes. Below them: the cyan waterline with a caustic ripple texture, and the top of a pale-cyan low-poly iceberg underwater.
**Motion:** placeholder "How can I help you today?" (f176–183), then **typewriter** "Make a slide deck for our Q3 review." from f184 to f231 (~36 characters in ~47 frames ≈ 1.3 frames/char) with a caret. The scene slowly pushes in.
**Bottom:** speaker, expressive brows, hand gestures f221–232.
**Captions (seam):** when(176) · prompting(184) · most of us.(190) · Just describe(206) · the task.(231).
Stats: luma 149, sat 79 · palette `#f4f9f8 #130c0e #a57370 #d1ccd0`.

### S05 · f246–368 · 8.17–12.28 s · FULL_GFX · DIVE UNDER THE ICEBERG
**Script:** "Well, in fact, we should be using the deeper meaning behind the prompt."
**Layout cut on "well":** the same iceberg animation continues, but the speaker panel disappears and the graphic fills the frame.
**Motion (camera):** a **continuous downward tilt / sink below the waterline**, f246–300 (the chat box moves up and out of the top of frame). The iceberg's tall underwater body is revealed: pale cyan, faceted, white facet lines. Water gets darker toward the bottom (cyan `#a2d2de` → `#084597` → navy `#091f55`), with caustic light streaks on the sides and tiny floating particles.
**Content:** four **grey placeholder icons** stacked inside the iceberg. f288–308 a **warm peach radial glow** blooms inside the berg ("deeper meaning").
**Staggered reveals (one per beat, ~12–13 frames apart):**
| Frame | Icon (Fluent 3D emoji) | Label |
|---|---|---|
| f309–313 | 👩‍🔬 woman scientist | What a pro would do |
| f322–326 | 🗄 card file box (yellow folders) | The rawest material |
| f335–339 | 🧰 red toolbox | Their methods & tools |
| f348–352 | ✅ green check box | What proves it right |
Each reveal: grey → full colour, scale pop ~0.9 → 1.08 → 1.0, a white glow ring that fades, and the label fades in and rises ~6 px over 4 frames. Labels are bold navy sans (~30 px).
**Hold:** the full stack holds f353–368 under "the prompt."
**Captions (chip at y≈850, over the berg):** well in fact,(246) · we should be(266) · using(278) · the deeper(287) · meaning(313) · behind(331) · the prompt.(355).
These four layers are exactly the four steps of the prompt in S02, so the metaphor teaches the content.
Stats: luma 140, **sat 143**, flow 0.73 (camera move) · palette `#e4f1ed #091f55 #a2d2de #084597`.

### S06 · f369–388 · 12.28–12.95 s · FULL_SPEAKER · BREATHER
**Script:** "For example,"
Punch-in on the speaker (face fills the frame). Hand gesture enters bottom-left f377–388. Caption y≈850: for example,(369).
Stats: luma 82, sat 122, flow 1.47 (real footage motion).

### S07 · f389–511 · 12.95–17.05 s · FULL_GFX · FLY-SWATTER vs "BUG FREE"
**Script:** "instead of saying to Claude 'fix this bug', say to Claude 'keep this app bug free'."
**World C (flat cartoon):** cream wallpaper with a faint diagonal-dash pattern, a soft diagonal light shaft, rust/orange desk band across the bottom 30%. A thick-outlined cartoon **smartphone** shows a music-player app (sunset-over-waves artwork, track bars, orange play button). On top, a **Claude input bar**: white, thick black outline, orange asterisk tile on the left, orange ↑ send tile on the right, placeholder "Reply to Claude…".
**Beat 1 (bad way), f389–441:** typewriter "fix this bug" (f392–406). A **fist holding a blue fly-swatter** slides in from the right (f392–396) and **swats** repeatedly (slams f411–416, f427–431, f437–441). Each slam leaves yellow impact stars and white **crack lines** on the screen glass. Red ladybug **bugs** crawl and multiply. f422–426 the input text gets an animated **red strike-through** (left → right, ~4 frames). f431 the text is deleted.
**Beat 2 (good way), f442–511:** typewriter "keep this app bug free" (f442–481). Swatting continues and gets tired: **sweat drops** by the fist. More bugs appear, and an orange pixel-invader bug sits on top of the phone (f457+). f483–486 "bug free" gets a **mint-green highlighter sweep**. f488–493 the **payoff**: golden swoosh/sparkle strokes and an **expanding mint shockwave ring** from the phone. The cracks vanish, the screen is restored, and bugs are knocked away. The **swatter drops out of the hand and tumbles down onto the desk** (f494–511). A mint glow ring stays around the phone as a "shield". One ladybug walks off on the right.
**Captions:** instead(389) · of saying(397) · to Claude,(407) · fix this bug,(419) · say to(442) · Claude,(453) · keep this app(464) · bug free.(493).
Stats: luma 168, sat 115, flow 0.36 · palette `#f8efd8 #9c450c #d8c9b0 #251915`.

### S08 · f512–565 · 17.05–18.85 s · SPLIT · ⌘V PASTE
**Script:** "Paste this prompt in before any task."
**Top:** soft white → peach gradient, faint grid, **dotted orange curved motion-path lines** with tiny diamond sparkles. Two **3D keycaps "⌘" and "V"** (white, bevelled, soft shadow) at the top. Below them is a Claude card: 🚀 "Plan our product launch.".
**Motion:** keycaps **press** (scale 1 → 0.92 → 1 with an orange outline glow, f523–530). f531–536 a **document card "✳ be-ambitious"** (monospace title, blurred body text = hidden prompt, peach border, radius 16) **drops in from above with spring overshoot** and pushes the task line down. f544–560 a **large thin peach ring** expands behind it.
**Bottom:** speaker mimes "paste in" with both hands pushing down (f531–545).
**Captions (seam):** paste(512) · this prompt(519) · in before(534) · any task.(548).
Stats: luma 151, sat 71.

### S09 · f566–641 · 18.85–21.39 s · FULL_GFX · SKILL CARTRIDGE POWER-UP
**Script:** "And that's why this Anthropic skill is so powerful."
**World C:** the same wallpaper and rust desk as S07 (the illustration world comes back). A **retro orange console** (thick black outline): 6 indicator LEDs, a black CRT with an orange **pixel-art invader**, and an analog gauge (cream dial, green → red arc, black needle). A **"SKILL.md" cartridge** (grey cartridge shell, orange title bar with asterisk + "SKILL.md" monospace, label "be-ambitious" in bold italic serif) **hovers and bobs** above the slot (f566–600).
**Beats:** f589 a small **Anthropic "A\" badge** stamps onto the label corner (on "anthropic"). f601–606 the **cartridge inserts** into the slot (ease-in). f607–640 **power-up**: an orange ring pulses from the slot; LEDs light **one by one** (f613–622); the pixel creature glows; the **needle swings into the red** (f619–628); the console **shakes** with **electric zig-zag lines** on the sides (f625+); **cream/yellow sunburst rays** fade in behind it and rotate slowly (f628+).
**Captions:** and that's(566) · why this(575) · anthropic(587) · skill is(605) · so powerful.(619).
Stats: luma 152, sat 137 · palette `#9c440b #f7e8cd #d4c4ab #f67644`.

### S10 · f642–703 · 21.39–23.46 s · SPLIT · STAMP PRESS + CONVEYOR
**Script:** "Just paste it in before any task,"
**Top:** white background with a warm yellow glow on the right. A **stamp press**: white rounded head with an orange asterisk, steel piston, and an orange pill stamp "✳ be-ambitious". Below it a **conveyor belt** (dark navy, 3 bolted rollers, tick marks) carries white **task cards** with emoji: 📊 Q3 review deck · ✉️ Launch email · 🐞 Checkout bug · 📋 Product roadmap · …
**Motion:** the belt moves **right → left at constant linear speed** (~4 px/frame). The press **slams every ~24–25 frames** (f647, f672, f696): the head flashes orange, the piston extends in ~4 frames, and an orange "be-ambitious" tab is left on the card. A peach ring expands from each impact (≈12 frames) and fades.
**Captions (seam):** Just(642) · paste it in(647) · before(669) · any task,(680).
**Bottom:** speaker smiling, raised brows.

### S11 · f704–732 · 23.46–24.42 s · FULL_GFX · THE EXPERT DOOR
**Script:** "and it tells you what a top…"
**World C, theatre:** purple velvet curtain `#290f31`, wood plank stage `#471d07`, a soft warm **spotlight cone from the top** with dust motes. A centre **wooden door** with a brass plate "Expert" (italic serif) and a brass knob.
**Motion:** f704–714 slow push-in. f715–720 the **door swings open** (hinge rotation on the left, ease-out) and **blinding cream light** pours out. **Purple god-ray fan** bursts behind it and the floor light pool brightens. f721–732 a **fast push-in toward the doorway** (~1.3×), as if walking through.
**Captions:** and it(704) · tells you(711) · what a top(725).

### S12 · f733–774 · 24.42–25.83 s · FULL_GFX · PROFESSOR + SPEECH BUBBLE
**Script:** "…expert would say,"
The same stage, spotlit. A **cartoon professor** (bald, white side hair, round glasses, white beard and moustache, brown suit) stands behind a **wooden lectern with a gold Claude-asterisk medallion**.
**Motion:** f737–741 he raises his index finger. f742–746 a **speech bubble pops in** (scale ~0.6 → 1.05 → 1.0, tilted ~−3°, thick outline): "**Reproduce it first.**" in bold italic serif. Mouth flaps between 2–3 shapes f745–773. Small idle bob.
**Captions:** expert(745) · would say,(758).
Stats S11–S12: luma ~68, sat ~175 (rich purple/brown).

### S13 · f775–847 · 25.83–28.26 s · SPLIT · SEARCHLIGHT LIGHTS THE BULBS
**Script:** "things that you would never have thought about."
**Top:** navy night sky `#0e0b1d` with faint dot stars. About 13 **hanging Edison bulbs** on long cords at different heights; each is grey-blue with a "W" filament, unlit. A soft, semi-transparent **searchlight / torch cone** rises from the bottom and **sweeps** across them (f775–810).
**Beats:** f786 the first bulb **ignites** (warm yellow + orange halo + small gold ring). f802 the second. f813–830 a **cascade**: bulbs light one after another, each with a ring. f815–830 the **whole background warms from navy to amber/brown**. By f835 every bulb is lit and the beam is gone.
**Captions (seam):** things(775) · that you(785) · would(795) · never have(801) · thought about.(824).

### S14 · f848–882 · 28.26–29.43 s · FULL_SPEAKER · PIVOT
**Script:** "And it doesn't just give you advice,"
Tight punch-in. The speaker does a sceptical squint / eye-roll on "advice" (f867–882). Captions y≈850: and(848) · it doesn't(849) · just give(858) · you advice,(867).

### S15 · f883–935 · 29.43–31.20 s · SPLIT · REVIEW WITH MAGNIFIER + MARKER
**Script:** "It actually reviews the whole prompt,"
**Top:** a **green cutting mat** (`#1b5e3c`, lighter grid lines + diagonal guides). A ruled **index card** (cream, blue lines, red margin, thick outline, slight tilt) reads "**Why is checkout so slow?**" in bold italic serif.
**Motion:** f883–912 a **magnifying glass** (gold rim, brown handle) glides left → right across the text with a **real lens magnification** of the letters under it. f913–935 a **red marker** enters from the right, draws a **wavy red underline** under "checkout" (f915–920), then **circles "so slow?"** (f925–933).
**Bottom:** speaker touches his temple ("reviews", f899–912), then points down at the card (f913–935).
**Captions (seam):** It actually(883) · reviews(894) · the whole prompt.(907).

### S16 · f936–1003 · 31.20–33.47 s · FULL_GFX · FLIP TO "EXPERT VERSION" + REWARD
**Script:** "so you're getting the expert version of it."
**Background:** royal blue `#033bb7` with a radial vignette, then **alternating light/dark blue sunburst rays** fade in (f943+) and rotate slowly.
**Motion:** f936–941 the card from S15 sits centred and does a **3D Y-axis flip** (horizontal squash to edge-on, almost invisible at f940–941). f942–944 the other side opens up: the **"Expert version" card** (cream, **thick gold/orange border**, asterisk tile, bold italic serif title, divider). f944–950 a gold ring pulses. Checklist rows reveal ~5 frames apart, each fading from 30% grey to full: 📈 **Raw traces** (f949), ⏱ **Profile it** (f954), ✅ **Load test** (f959). f972–974 a **gold "verified" seal coin with a white check stamps** onto the top-right corner (scale 1.4 → 1.0), with a ring pulse and a shine sweep across the title. f975–1003 **confetti**: small multicolour rectangles and dots (orange, yellow, teal, red, white) burst and drift down with rotation.
**Captions:** So you're(936) · getting(944) · the expert(956) · version(980) · of it.(996).
Stats: luma 110, sat 165, flow 0.88 · palette `#033bb7 #fcfbf4 #2f5dbe #163075`.

### S17 · f1004–1011 · 33.47–33.73 s · FULL_GFX · "THE PROMPT — EXCLUSIVE"
The same blue sunburst continues (the background matches across the cut). A cream sheet with a curled corner, "✦ The Prompt" (bold italic serif, orange sparkle), squiggle placeholder lines, and a red distressed **"EXCLUSIVE" rubber stamp** rotated ~−15°. It gently floats. Only 8 frames long: a teaser flash for the CTA. Caption: of it. (continued).

### S18 · f1012–1093 · 33.73–36.47 s · FULL_SPEAKER · CTA
**Script:** "Want the prompt? Comment 'deeper' and I'll send it over."
Tight punch-in that pushes in slightly over the shot. Normal caption chip: of it.(1012) · Want the(1014) · prompt?(1017) · Comment(1029) · deeper(1044) · and I'll(1061) · send it over.(1071–1093).
**CTA keyword:** f1040 to the end: “**DEEPER**" in large white **serif caps** (~95 px cap height ~70, Times/Playfair-like, curly open quote, straight close quote as in the source, soft black drop shadow), centred at **y≈960**, under the chip. It appears just before the speaker's **air-quote gesture** (f1045–1060) and the big laugh. No end card. The video ends on the speaker, which loops cleanly into S01.
