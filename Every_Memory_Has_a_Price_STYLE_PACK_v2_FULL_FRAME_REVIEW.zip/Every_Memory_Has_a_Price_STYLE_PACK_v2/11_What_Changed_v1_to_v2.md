# 11 — WHAT THE FULL FRAME-BY-FRAME PASS CHANGED (v1 → v2)
In v1 I had looked at ~300 frames. In v2 I viewed **all 2,334 frames in order**. Here is what that found.

## Mistakes in v1 that are now fixed
1. **Sign text**: the slanted board reads **'WE BUY SUMMERS'** (maroon slab-serif on mustard, with script 'cash today, any grade') — v1 said 'MY SUMMERS'.
2. **T2 (1.5 s)** is a continuous camera pull-up, not a cross-dissolve.
3. **T5/T9 (23 s)** is a cross-dissolve to flamingo-pool water + vertical blurred light streaks, not a 'dive into water'.
4. **T6 (27.5 s)** is a **shape match-cut** (dial ring growing over the bench), not a plain dissolve.
5. **The little brother in the street scene** is a healthy, bouncing **green-cap kid in a red shirt**; the frog hops onto his cap before he collapses. v1 had him sick already.
6. **The stranger is NOT grinning at the start of the gauge scene** — he is bored/blank; the grin grows from f879 to f893. v1 implied a constant grin.
7. **Scene boundaries** were shifted by up to ~0.6 s in v1; all 24 now use exact frame numbers and all measured stats were recomputed.
8. The ledger is **held up by Jerry** and pushed into; v1 said it was a simple dissolve overlay.
9. In the final shot the **brother's hurt face is the last image**, and Jerry's eyes change from ring-eyes to dots — v1 only said 'freeze'.

## New discoveries (not in v1 at all)
* **Eye-design = emotion code:** ring-eyes = alive/present; dash/line eyes = tired/blink/serene; **dot-eyes = hollow (Jerry from f2203)**; wavy zig-zag mouth = anxious/confused; sweat drop, tear, squeezed-x eyes (affection).
* **Hair = emotion code:** limp/flat while sick; **springs into spikes** the instant the brother is cured (f2008–2012).
* **Face colour as a light signal:** Jerry's skin pulses cold-lavender ↔ warm-orange about every 1.45 s in the 'WE BUY SUMMERS' scene, then gains a blue-white halo.
* **Persistent-object and face-match transitions** (frog, polaroid, dial ring, three face-position dissolves).
* **Extraction as a repeatable animated device:** helmet/dome descends → glowing halo → card rises → bloom flash → counter ticks → dome lifts (S06, S10, S22). The final one uses a lamp dome descending, a tube-follow, **a pixel-block mosaic** and a gold blow-out.
* **Red bleed** over the teal corridor when the OPERATING sign lights (f1484–1498).
* **Hood reveal:** the shopkeeper pulls his hood back to show a round worried face, with **tremor lines and a one-eye wink/flinch**.
* **One-eye wink in the very first frames** (f2–3), pre-swing push-in, 3-frame ghost blend inside the swing.
* **Light pulses on props:** amber door window pulses (f112–140), card glow pulses (f43–46), sparkle beats (f873–884, f1343–1350).
* **The polaroid has a diagonal glare streak and a blue handwritten caption 'the frog!'**; the ledger has a shimmering gold 2016 row; the odometer rolls before settling.
* **Animation is smooth 30 fps** (not on twos): only 35 of 2,333 frame pairs are near-duplicates.
* **Camera behaviours I had wrong or missed:** truck-right along the deli storefront, downward seam wipe with a white leading edge, the bench 'tiny far-wide → push-in', the gauge 'big → pull-back', the sickroom 'tiny wide → push-in'.

## What I can and can't claim
* I viewed every frame **at thumbnail size (100 × 178 px, 72 per sheet)** plus the earlier higher-resolution views. Whole-frame events, motion, lighting changes, props, and major expressions are reliable. Very subtle things (single-pixel eyebrow changes, tiny background text) could still be missed.
* Audio still measured, not listened to.
