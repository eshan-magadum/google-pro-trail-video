// High-Detail Procedural 3D Environment, Skybox, Foliage, Cutaway & VFX Builders (Skill v2.0)
// Derived directly from 30-FPS forensic analysis of 'Why Samurai Feared The Flying Thunder.mp4'
// and 'Every Memory Has a Price.mp4'. Eliminates bare walls, flat backgrounds, and primitive voids!
import * as THREE from 'three';

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// 1. Painted Multi-Layer Atmospheric Cloud Sky Dome (NEVER use flat single-color scene.background!)
export function makePaintedCloudSkyDome(preset = 'twilight_moon', radius = 65) {
  const c = document.createElement('canvas');
  c.width = 1024; c.height = 512;
  const g = c.getContext('2d');
  const rng = mulberry32(preset === 'golden_dusk' ? 202 : 707);

  const sky = g.createLinearGradient(0, 0, 0, 512);
  if (preset === 'golden_dusk') {
    sky.addColorStop(0.0, '#19224E');
    sky.addColorStop(0.38, '#3B487E');
    sky.addColorStop(0.68, '#B8785A');
    sky.addColorStop(0.86, '#F2B872');
    sky.addColorStop(1.0, '#2A2538');
  } else if (preset === 'storm_night') {
    sky.addColorStop(0.0, '#0E1232');
    sky.addColorStop(0.45, '#1D2554');
    sky.addColorStop(0.75, '#343D6E');
    sky.addColorStop(1.0, '#151836');
  } else {
    // Natural Samurai twilight sky (slate-navy zenith -> dusty misty blue-grey horizon!)
    sky.addColorStop(0.0, '#161C38');
    sky.addColorStop(0.42, '#2B365C');
    sky.addColorStop(0.72, '#566488');
    sky.addColorStop(0.86, '#7E869E');
    sky.addColorStop(1.0, '#282634');
  }
  g.fillStyle = sky;
  g.fillRect(0, 0, 1024, 512);

  // Soft painterly wispy horizontal cloud strata (NOT round repetitive circles!)
  for (let i = 0; i < 65; i++) {
    const cx = rng() * 1024;
    const cy = 65 + rng() * 290;
    const rx = 65 + rng() * 165;
    const ry = 10 + rng() * 28;
    const isLight = rng() > 0.45;
    g.save();
    g.translate(cx, cy);
    g.scale(1, ry / rx);
    const cg = g.createRadialGradient(0, 0, rx * 0.08, 0, 0, rx);
    if (preset === 'golden_dusk') {
      cg.addColorStop(0, isLight ? 'rgba(255,212,154,0.22)' : 'rgba(34,36,78,0.26)');
    } else {
      cg.addColorStop(0, isLight ? 'rgba(175,188,220,0.20)' : 'rgba(18,22,46,0.34)');
    }
    cg.addColorStop(1, 'rgba(30,36,68,0)');
    g.fillStyle = cg;
    g.beginPath(); g.arc(0, 0, rx, 0, Math.PI * 2); g.fill();
    g.restore();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return new THREE.Mesh(
    new THREE.SphereGeometry(radius, 32, 18),
    new THREE.MeshBasicMaterial({ map: tex, side: THREE.BackSide, fog: false })
  );
}

// 2. Instanced 3D Dry Grass / Foliage Tufts (catches warm firelight & eliminates flat plastic terrain!)
export function scatterInstancedGrassTufts(parent, {
  minX = -10, maxX = 10, minZ = -12, maxZ = 4,
  count = 420, excludeCenterRadius = 1.6,
  baseColor = '#6B5C44', seed = 404,
} = {}) {
  const rng = mulberry32(seed);
  // Single tapered blade quad
  const geo = new THREE.BufferGeometry();
  const verts = new Float32Array([
    -0.025, 0.0, 0.0,
     0.025, 0.0, 0.0,
     0.008, 0.34, 0.04,
  ]);
  geo.setAttribute('position', new THREE.BufferAttribute(verts, 3));
  geo.computeVertexNormals();

  const mat = new THREE.MeshStandardMaterial({
    color: baseColor,
    roughness: 0.88,
    side: THREE.DoubleSide,
  });
  const inst = new THREE.InstancedMesh(geo, mat, count);
  const dummy = new THREE.Object3D();
  let placed = 0;
  let guard = 0;
  while (placed < count && guard < count * 6) {
    guard++;
    const x = minX + rng() * (maxX - minX);
    const z = minZ + rng() * (maxZ - minZ);
    if (Math.hypot(x, z) < excludeCenterRadius && rng() < 0.85) continue;
    dummy.position.set(x, 0.0, z);
    dummy.rotation.set((rng() - 0.5) * 0.45, rng() * Math.PI * 2, (rng() - 0.5) * 0.45);
    const s = 0.65 + rng() * 1.15;
    dummy.scale.set(s, s * (0.8 + rng() * 0.7), s);
    dummy.updateMatrix();
    inst.setMatrixAt(placed++, dummy.matrix);
  }
  inst.count = placed;
  inst.instanceMatrix.needsUpdate = true;
  parent.add(inst);
  return inst;
}

// 3. Rutted Muddy Earth / Dirt Trail Ground PBR Texture (Warm charcoal-umber, zero neon blue!)
export function makeRuttedDirtGroundTexture() {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 512;
  const g = c.getContext('2d');
  const rng = mulberry32(812);

  g.fillStyle = '#4B3E38';
  g.fillRect(0, 0, 512, 512);

  // Wheel ruts & worn central trail
  const trail = g.createLinearGradient(0, 0, 512, 0);
  trail.addColorStop(0.0, 'rgba(32,26,30,0.35)');
  trail.addColorStop(0.32, 'rgba(84,68,58,0.28)');
  trail.addColorStop(0.50, 'rgba(98,78,64,0.34)');
  trail.addColorStop(0.68, 'rgba(84,68,58,0.28)');
  trail.addColorStop(1.0, 'rgba(32,26,30,0.35)');
  g.fillStyle = trail;
  g.fillRect(0, 0, 512, 512);

  // Subtle dark wheel track grooves
  for (const rx of [168, 344]) {
    g.fillStyle = 'rgba(26,20,24,0.35)';
    g.fillRect(rx - 14, 0, 28, 512);
    g.fillStyle = 'rgba(130,104,84,0.16)';
    g.fillRect(rx + 14, 0, 8, 512);
  }

  // Scattered dirt pebbles & organic soil blotches
  for (let i = 0; i < 240; i++) {
    const x = rng() * 512, y = rng() * 512, r = 4 + rng() * 24;
    g.fillStyle = rng() > 0.5 ? 'rgba(28,22,26,0.12)' : 'rgba(128,104,86,0.10)';
    g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping; tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 4);
  return tex;
}

// 4. Ornate Patterned Crimson & Gold Interior Rug Texture (Samurai Tent f384 benchmark!)
export function makeOrnamentalRugTexture(primary = '#8E1F2A', accent = '#1F2A56', gold = '#E6B44C') {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 768;
  const g = c.getContext('2d');

  g.fillStyle = primary;
  g.fillRect(0, 0, 512, 768);
  // Outer navy & gold borders
  g.strokeStyle = accent; g.lineWidth = 52; g.strokeRect(26, 26, 460, 716);
  g.strokeStyle = gold; g.lineWidth = 8; g.strokeRect(56, 56, 400, 656);
  g.strokeRect(10, 10, 492, 748);

  // Gold bead trim dots around border
  g.fillStyle = gold;
  for (let x = 28; x <= 484; x += 28) {
    g.beginPath(); g.arc(x, 26, 6, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.arc(x, 742, 6, 0, Math.PI * 2); g.fill();
  }
  for (let y = 54; y <= 714; y += 28) {
    g.beginPath(); g.arc(26, y, 6, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.arc(486, y, 6, 0, Math.PI * 2); g.fill();
  }

  // Ornate central medallion
  g.fillStyle = accent;
  g.beginPath(); g.ellipse(256, 384, 128, 178, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = gold; g.lineWidth = 7; g.stroke();
  g.fillStyle = primary;
  g.beginPath(); g.ellipse(256, 384, 72, 98, 0, 0, Math.PI * 2); g.fill(); g.stroke();
  // Floral rosette petals inside medallion
  g.fillStyle = gold;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    g.beginPath();
    g.ellipse(256 + Math.cos(a) * 30, 384 + Math.sin(a) * 30, 18, 9, a, 0, Math.PI * 2);
    g.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// 5. High-Detail 3D Hero Cutaway Prop: Turned Wooden Spool + Helical Braided Rope (TubeGeometry!)
export function makeHelicalRopeSpool({ radius = 0.28, height = 1.15, turns = 14 } = {}) {
  const grp = new THREE.Group();
  const woodMat = new THREE.MeshStandardMaterial({ color: '#D4A15A', roughness: 0.72 });
  const ropeMat = new THREE.MeshStandardMaterial({ color: '#543A26', roughness: 0.90 });

  const core = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.88, radius * 0.88, height, 24), woodMat);
  const capTop = new THREE.Mesh(new THREE.CylinderGeometry(radius * 1.24, radius * 1.24, 0.12, 24), woodMat);
  capTop.position.y = height * 0.5;
  const capBot = capTop.clone();
  capBot.position.y = -height * 0.5;
  grp.add(core, capTop, capBot);

  // True 3D helical rope coil wrapped tightly around spool
  const pts = [];
  const segs = turns * 18;
  for (let i = 0; i <= segs; i++) {
    const u = i / segs;
    const ang = u * turns * Math.PI * 2;
    const y = -height * 0.42 + u * height * 0.84;
    pts.push(new THREE.Vector3(Math.cos(ang) * radius, y, Math.sin(ang) * radius));
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  const rope = new THREE.Mesh(new THREE.TubeGeometry(curve, segs, 0.028, 7, false), ropeMat);
  grp.add(rope);
  return grp;
}

// 6. Directional Metallic Impact Spark Streaks (Samurai f1200 benchmark!)
export function makeStreakSparksSystem(parent, count = 36) {
  const grp = new THREE.Group();
  const sparkMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.2, 2.2, 0.75) });
  const rng = mulberry32(991);
  const items = [];
  for (let i = 0; i < count; i++) {
    const len = 0.14 + rng() * 0.28;
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.014, len, 0.014), sparkMat);
    grp.add(m);
    items.push({
      mesh: m,
      vx: (rng() - 0.5) * 4.2,
      vy: 1.2 + rng() * 3.8,
      vz: (rng() - 0.5) * 2.5,
      offset: rng(),
    });
  }
  parent.add(grp);
  function update(origin, burstPhase) {
    grp.visible = burstPhase > 0.001 && burstPhase < 1.0;
    if (!grp.visible) return;
    for (const it of items) {
      const p = Math.max(0, burstPhase - it.offset * 0.18);
      const x = origin[0] + it.vx * p;
      const y = Math.max(0.02, origin[1] + it.vy * p - 4.2 * p * p);
      const z = origin[2] + it.vz * p;
      it.mesh.position.set(x, y, z);
      it.mesh.rotation.z = Math.atan2(-it.vx, it.vy - 8.4 * p);
      it.mesh.scale.setScalar(Math.max(0.01, 1 - p));
    }
  }
  return { group: grp, update };
}

// 7. Practical Campfire w/ Stone Ring, Flickering Flame & Warm PointLight (creates real +30 warmth bounce!)
export function makeCampfireWithSmoke(parent, x, y, z) {
  const grp = new THREE.Group();
  grp.position.set(x, y, z);
  const stoneMat = new THREE.MeshStandardMaterial({ color: '#4A464C', roughness: 0.92 });
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const st = new THREE.Mesh(new THREE.DodecahedronGeometry(0.11, 0), stoneMat);
    st.position.set(Math.cos(a) * 0.36, 0.06, Math.sin(a) * 0.36);
    st.scale.set(1.2, 0.75, 1.0);
    grp.add(st);
  }
  const flameMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.4, 1.85, 0.45), transparent: true, opacity: 0.92 });
  const coreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.8, 3.1, 1.35) });
  const f1 = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.62, 10), flameMat);
  f1.position.y = 0.30;
  const f2 = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.42, 8), coreMat);
  f2.position.y = 0.22;
  grp.add(f1, f2);

  const light = new THREE.PointLight('#FF9838', 11.0, 12.0, 1.45);
  light.position.set(0, 0.65, 0);
  grp.add(light);
  parent.add(grp);

  function update(t) {
    const fl = 0.88 + 0.16 * Math.sin(t * 17.0) + 0.08 * Math.cos(t * 29.0);
    f1.scale.set(0.95 + 0.1 * Math.sin(t * 13), fl, 0.95);
    f2.scale.set(1.0, fl * 1.08, 1.0);
    light.intensity = 10.5 * fl;
  }
  return { group: grp, light, update };
}
