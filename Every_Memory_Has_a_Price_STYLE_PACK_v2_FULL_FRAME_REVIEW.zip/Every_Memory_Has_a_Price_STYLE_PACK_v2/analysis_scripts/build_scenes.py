import json
sc = json.load(open('/home/claude/work/pkg/data/scene_analysis.json'))
D = {
"S01": dict(
 vis="Memory-shop counter at night. Protagonist stands right of a long, wedge-perspective wooden counter, worried. Hooded stranger visible far-left behind a translucent glass partition. Green-shaded pendant lamp top-centre, teal oval-pattern wallpaper, wood door with an amber lit window, brass cash-register, a tiny glowing memory card on the counter.",
 cam="Low, wide-angle (≈20 mm) static; at 0.67 s swings and pitches down (T1) as the hero slides out right.",
 light="Cool navy ambient + warm counter pool; hard diagonal shadow band across the counter; lamp bloom; vignette strong (corner÷centre 0.21).",
 depth="Foreground counter large and slightly soft; stranger behind glass hazy; deep perspective convergence.",
 expr="Hero: uneasy → wide-eyed alarm. Stranger: blank, glowing eyes.",
 trans="Camera swing onto the card (T1).",
 beat="Hook line: someone sold his happiest memory to a stranger.",
 img="Vertical 9:16 night interior of a pawn-style memory shop: long wooden counter in steep wide-angle perspective, round-headed stick-figure boy (orange spiky hair, yellow vest with white stripe, tiny green frog badge) standing at the right looking worried, hooded figure with glowing amber eyes behind a translucent glass partition at far left, green pendant lamp glowing, teal wallpaper, amber-lit wooden door, brass cash register, one tiny glowing memory card on the counter, hard diagonal shadow across the counter, indigo shadows, strong vignette.",
 mot="Static low camera 0.5 s, then fast eased swing: camera pitches down ~70° onto the counter as the boy slides out of frame right; focus racks to the glowing card. 0.9 s total."),
"S02": dict(
 vis="Top-down macro of a pale glass tray on the counter with the glowing gold memory card (tiny lake-scene picture on it). Out-of-focus cash register at top.",
 cam="Near top-down pitch (~80°), slow push-in, rack focus (blur→sharp over ~12 frames).",
 light="Washed highlights (luma 109, sat 0.33): cool white tray against warm wood; card emits warm gold glow.",
 depth="Very shallow DOF; background creamy blur.",
 expr="n/a (prop).", trans="Fast 0.6 s bright→dark dissolve into the stranger (T2).",
 beat="'Memory' is shown as a physical object.",
 img="Top-down macro close-up of a small glowing golden memory card (like a miniature photo cassette with a tiny sunny lake picture) lying on a pale glass tray set in a warm wooden counter, shallow depth of field, blurred brass cash register at top, soft gold glow from the card, cool white tray, warm wood, flat clean 2.5D stylised render.",
 mot="Camera pushes in slowly while focus racks from soft to razor-sharp on the card; card glow pulses once. 0.7 s."),
"S03": dict(
 vis="Hooded stranger behind the counter, giant toothy grin, glowing amber eyes; wall of memory cubbies (≈6×8 grid) with tiny blue/pink/amber glowing cards; filing drawers with gold label plates; amber lit door; brass register; lamp pool on counter.",
 cam="Slow push-in + lateral drift, slight Dutch tilt (wall edge slants), 2.5–5 s.",
 light="Darkest scene (luma 42, 69 % of pixels <40, vignette 0.36). Pale-blue rim on hood; amber door and cubby cards are the only light.",
 depth="Cubby wall in soft focus; stranger and counter edge crisp.",
 expr="Stranger: gleeful, grin widens as camera closes; eyes glow brighter at ~4.5 s.",
 trans="Glass pane drifts across; dissolve to alley (T3).",
 beat="Establish the rule: memories are money.",
 img="Vertical 9:16 dark shop interior: round-faced hooded figure with big toothy grin and glowing amber eyes behind a wooden counter, hood is navy-black with a thin pale-blue rim light, a wall of small cubby holes containing tiny glowing blue/pink/amber memory cards, filing drawers with gold label plates, amber-lit door at right, brass register on the counter, a pool of warm lamplight on the counter, deep indigo shadows, heavy vignette, slightly tilted camera.",
 mot="Slow push-in toward the grinning figure with 1–2° lateral drift; grin widens slightly; eyes glow brighter at the end. 3.4 s."),
"S04": dict(
 vis="A translucent glass pane slides across frame while the shop dissolves to a rainy alley; hero re-enters at frame right; alley brick wall with a glowing 'MEMORIES' light-box poster.",
 cam="Pull-back with sideways glass sweep; zoom divergence −1.9.", light="Vignette 0.68 (frame still dark at edges), bokeh lights ahead.",
 depth="Pane in front → depth layering.", expr="Hero: worried.", trans="T3 glass sweep dissolve.", beat="Transition from the shop to the city.",
 img="Dark rainy alley at night, wet reflective paving tiles, purple-brick wall at left, glowing light-box poster with a shop logo, warm bokeh lights far down the alley, rain streaks, a faint translucent glass pane edge sweeping across the foreground.",
 mot="A translucent glass pane glides across the lens; interior dissolves into the rainy alley; rain streaks fade in first. 0.9 s."),
"S05": dict(
 vis="Rainy neon alley, wet pavement, vanishing-point light, vertical neon sign, bokeh lights, light-box poster at right.",
 cam="Forward dolly along the alley.", light="Indigo→electric-blue→lavender; far-end warm lights; strong haze (vig 0.55).",
 depth="Atmospheric perspective: far lights soft and hazy.", expr="—", trans="0.25 s window-glass dissolve (6.50–6.75 s): the alley is seen through rain-spotted glass while the lit extractor shop fades in behind it (luma 68→104). Not a cut.", beat="'There's a shop on every corner…'",
 img="Vertical 9:16 rainy night alley in wide-angle, wet reflective tiled ground mirroring neon, brick wall left, glowing shop light-box poster right, vertical neon sign, warm orange and magenta bokeh at the vanishing point, rain streaks, indigo and electric-blue gradient, haze.",
 mot="Smooth forward dolly down the alley, rain falling, reflections sliding on the wet ground. 0.8 s."),
"S06": dict(
 vis="First seen through the rain-spotted window glass, then fully revealed. Brightest interior: extraction-shop chair with a metal helmet clipped to a seated pink-faced customer; bald assistant standing; teal wall with arched gold sign ('pulled while you wait … cash on the spot … all grades'); teal-and-white checkerboard floor; big white pendant lamp.",
 cam="Dolly-in + tilt up toward the lamp (bloom swells 7.5→8.0 s).", light="Luma 108, 7 % pixels >235; lavender-pink radial haze `#8F708C→#ECD4D2`.",
 depth="Strong glow-fog flattens depth; floor checker pattern gives perspective.", expr="Customer: calm/blank; assistant: neutral.", trans="Dissolve/cut-on-action to the deli street.", beat="How it's done — memories pulled out like teeth.",
 img="Vertical 9:16 bright shop interior with lavender-pink glowing haze, teal wall with an arched yellow shop sign, teal-and-white checkerboard floor, a round-headed stick-figure customer sitting in a dentist-style chair with a metal dome helmet on their head, a bald round-headed assistant standing beside, large white pendant lamp blooming at the top, soft diffusion.",
 mot="Slow dolly-in while tilting up to the pendant lamp; lamp bloom grows; helmet gives a faint pulse of light. 2.3 s."),
"S07": dict(
 vis="Rainy night deli street: red awning 'DELI GROCERY', big glowing shop window full of colourful goods, fire escape, wet pavement, a landlord on the steps, a kid on a bike, bystanders.",
 cam="Low look at the steps → track right and crane down; kid rides, falls ≈ 13 s.", light="Indigo night + warm amber window; red awning accent; luma 85, 8.7 % bright pixels.",
 depth="Rain-streaked mid-ground; window glow blooms.", expr="Landlord: stern half-lids; kid: delighted → startled.", trans="Camera tilts up the wall (continuous into S08).", beat="'Landlords take birthdays, groceries cost the day you learn to ride a bike.'",
 img="Vertical 9:16 rainy night street, a deli with a red awning and a huge warm glowing shop window full of colourful goods, fire escape above, wet pavement reflections, round-headed stick-figure people on the steps and a child on a small bicycle, indigo and violet night with amber window glow, rain.",
 mot="Camera starts low at the steps, tracks right, then cranes down to the child on the bike; bike wobbles and falls; rain keeps falling. 4 s."),
"S08": dict(
 vis="Camera tilts up the face of a building to a colossal city-dividing wall with warm spotlights and white light shafts; fallen bike and kid at the bottom of frame.",
 cam="Tilt up with Dutch roll ≈ 15–20°.", light="God-rays from top, lens flare, violet haze; luma 75.",
 depth="Extreme scale — tiny characters vs giant wall.", expr="—", trans="T4 top-down luminous wipe to the pool.", beat="'The city is split in two by a giant wall.'",
 img="Vertical 9:16 dramatic upward view of a gigantic concrete city wall at dusk, tilted 15–20°, warm spotlights along the top casting white light shafts through violet haze, tiny stick-figure child and a fallen bicycle at the bottom of frame, indigo and lavender gradient sky.",
 mot="Camera tilts upward along the wall with a slow Dutch roll; light shafts sweep; lens flare grows. 2.6 s."),
"S09": dict(
 vis="Sunny resort: turquoise pool with caustics, hillside tiered seating, floodlight tower, palm trees, pink bougainvillea; far figure on a lounger, then butler and lounger in big straw hat and sunglasses.",
 cam="Water-level dolly forward + rise after the wipe.", light="Blown daylight: luma 155, bloom 17 %, no vignette (0.91).",
 depth="Deep focus, plastic-clean.", expr="Rich lounger: smug half-lids; butler: haughty, one brow raised.", trans="Camera glides on into S10.", beat="'On one side, the rich just buy everyone else's summers.'",
 img="Vertical 9:16 sunny luxury resort pool, turquoise water with bright caustic patterns, tall palm trees, pink flowering bushes, a stadium-like green hillside with floodlight tower under a deep blue sky, in the foreground a round-headed stick-figure wearing a huge straw hat and sunglasses on a lounger with a butler in a white jacket holding a tray, clean glossy 3D look, over-bright and cheerful.",
 mot="Low camera at pool-edge level glides forward over the water and rises to reveal the lounger and butler. 2.9 s."),
"S10": dict(
 vis="Hawaiian-shirt guy with snorkel mask and yellow snorkel under a glowing copper dome extractor; foreground golden odometer box 'BAHAMAS' rolling to 300 on a gold tray; bright blue window and sea behind.",
 cam="Tilt down from helmet to counter.", light="Blown highlights: 46 % pixels >235; radial halo near-white behind head → cobalt edges.",
 depth="Counter large in foreground, subject mid, window far.", expr="Guy: eyes-closed bliss, dreamy smile.", trans="Pulls back to the couch (S11).", beat="'Some guy has Bahamas 300 times…'",
 img="Vertical 9:16 sunny interior with big window to sea, round-headed stick-figure in a floral Hawaiian shirt with snorkel mask and yellow snorkel, eyes closed in bliss, wearing a glowing copper memory-extractor dome on his head, golden mechanical odometer counter on a round gold tray in the foreground labelled BAHAMAS with rolling digits, radial white-to-cobalt halo glow, bright and slightly over-exposed.",
 mot="Camera tilts down from the glowing dome to the odometer; digits roll rapidly and settle on 300; golden pulse. 2.5 s."),
"S11": dict(
 vis="Wide: the guy slumped on a white couch, counter beside him, pink flamingo float in the pool; camera then dives top-down onto the glassy water.",
 cam="Pull-back wide → crane/dive to the water surface.", light="Bright cyan water, caustics, 31 % bright pixels.",
 depth="Pool surface refracts; ripples fill frame.", expr="Guy: blissed-out, eyes closed.", trans="T5 dive into water → cold dusk.", beat="'…without leaving his couch.'",
 img="Vertical 9:16 modern poolside, a round-headed stick-figure lounging on a white couch beside a gold counter box, a pink flamingo float on turquoise water with bright caustics, blue sky, glossy over-bright 3D, camera slightly high.",
 mot="Camera pulls back to a wide, then descends toward the pool surface; ripples and caustics expand until the whole frame is water. 2.8 s."),
"S12": dict(
 vis="Poor side at dusk: three elders on a wooden bench holding framed/polaroid photos; chain-link fence; red bench ad ('…BOUGHT & SOLD … 555-0142'); cracked concrete; vertical pipes.",
 cam="Low static → very slow push-in.", light="Cold violet-blue ambient (luma 91) with warm skin; softness lost to hyper-detailed linework (sharpness ≈ 2000).",
 depth="Mostly flat/deep, fence pattern gives texture.", expr="Woman: calm blank smile; man with glasses: half-lidded, slightly confused; third: partly seen.", trans="T6 → dark shop gauge.", beat="'…smiling with no idea why.'",
 img="Vertical 9:16 dusk street bench scene: three elderly round-headed stick-figure people sitting in a row holding old framed photos, curly-haired woman and bald man with round glasses, blank gentle expressions, blue chain-link fence behind, red advertisement banner on the bench with white lettering, cracked concrete floor, thick black outlines, cold violet-blue light with warm skin tones.",
 mot="Very slow push-in; one elder blinks; subtle parallax of the fence versus the bench. 4 s."),
"S13": dict(
 vis="Brass 'HAPPINESS' gauge (pocket-watch style with sunny/rainy icons and coloured arc), price counter, bucket of cards; stranger's face large behind it, grin growing, eyes glowing.",
 cam="Tight static with breathing push.", light="Gold glow from the gauge strengthens as needle climbs (bright-pixel share ≈ 5 %), cubby wall in dark.",
 depth="Gauge sharp; stranger and cubbies soft.", expr="Stranger: grin widens from neutral to ecstatic as the needle moves.", trans="Dissolve to the night street.", beat="'The happier the memory, the more it pays.'",
 img="Vertical 9:16 close-up of a brass pocket-watch style gauge on a small wooden base labelled HAPPINESS with a coloured arc, a sun icon at the right and a rain-cloud icon at left, a rolling price counter, a metal bucket of tiny memory cards at left, behind it a dark hooded figure with a huge toothy grin and glowing amber eyes, dark cubby wall, gold glow from the gauge, indigo shadows.",
 mot="The needle swings up from rain to sun; gauge glows brighter; the stranger's grin widens and eyes brighten. 3.7 s."),
"S14": dict(
 vis="Night street from a low Dutch angle: string of pennant lights, apartment windows, fire hydrant, wet ground mirror-reflecting the characters; hero, landlord and a green-capped kid with a frog; later the camera tilts down into the reflection.",
 cam="Low Dutch tilt, slow drift, then tilt-down.", light="Deep cobalt `#152075` / indigo `#151440`, luma 56, sat 0.66 — the most saturated gloom.",
 depth="Mirror reflections create a second layer.", expr="Hero: troubled; kid: gleeful then sick.", trans="Dissolve into the hospital.", beat="'Jerry only sold his to cover rent. Same week his little brother gets sick.'",
 img="Vertical 9:16 low Dutch-angle night street with strings of small pennant lights, tall apartment buildings with glowing windows, a fire hydrant, wet ground reflecting everything like a mirror, round-headed stick-figure boy with orange hair and yellow vest next to a small kid in a green cap holding a green frog, deep cobalt and indigo palette, rain mist.",
 mot="Camera drifts sideways at a low tilted angle, then tilts down into the wet-ground reflection. 3.9 s."),
"S15": dict(
 vis="Hospital bedside at night: brother in bed with frog plush, protagonist in chair eyes closed smiling, small warm lamp, red blanket; background deep navy.",
 cam="Slow push-in/orbit.", light="Warm lamp pool on faces against cobalt; luma 71.",
 depth="Soft background; faces crisp.", expr="Hero: tender; brother: weak smile.", trans="Polaroid appears (T7).", beat="'…he begs for the same bedtime story.'",
 img="Vertical 9:16 dim hospital room at night, a sick small round-headed stick-figure child in a bed with a green frog plush, an older boy with orange spiky hair and a yellow vest sitting beside the bed with eyes closed and a gentle smile, small warm bedside lamp, red blanket, deep navy-blue background, soft lamplight on faces.",
 mot="Slow push-in with a tiny orbit; the lamp light flickers softly; the boy blinks. 3.6 s."),
"S16": dict(
 vis="A polaroid expands into a golden-hour lake: wooden dock, two boys, a frog leaping from a net, lily pads, reeds, sun low on the horizon.",
 cam="Photo match-cut zoom, then gentle drift with parallax.", light="Honey sun + cool blue water: luma 127, bloom 12 %, vig 0.67.",
 depth="Layered: reeds in front, dock mid, tree-line distant.", expr="Boys: joyful squints; frog: wide-eyed leaping.", trans="Dissolve back to the hospital.", beat="The cherished memory — the thing being traded.",
 img="Vertical 9:16 golden-hour lake scene seen as a nostalgic memory, wooden dock, two round-headed stick-figure boys (one orange spiky hair, one smaller) fishing with a net, a green frog leaping out of the net, lily pads and reeds in the foreground, sun low at the horizon with glowing reflections on blue water, tree line in the distance, warm gold and cool teal-blue palette.",
 mot="Polaroid fills the screen then dissolves outward into the full-frame lake; slow parallax drift; the frog leaps out of the net in an arc. 3.2 s."),
"S17": dict(
 vis="Hospital corridor price-gauge on an IV pole, then the sale desk: stranger as a dark foreground silhouette at left, protagonist lit from below at the desk, a glass partition, a tiny glowing card between them.",
 cam="Static two-shot with very slow push.", light="Very dark (luma 48, 61 % <40); face lit from beneath, lavender edge, thin glint on the glass.",
 depth="Foreground silhouette defocused; face crisp.", expr="Hero: drained → shocked (sweat drop) → defeated → hopeful-afraid → single tear.", trans="Whip pull-back (T8).", beat="'But the medicine costs way more than that. So Jerry goes and sells that summer.'",
 img="Vertical 9:16 very dark scene: a worried round-headed stick-figure boy with orange spiky hair at a desk lit from below by a small lamp so his face glows peach-white, a dark hooded silhouette in the left foreground with only faint eyes catching light, a thin glass partition with a pale reflection, a tiny glowing golden memory card on the desk, deep indigo-black surroundings, strong vignette.",
 mot="Almost static; very slow push-in; sweat drop forms and falls; the card pulses; a single tear rolls at the end. 4.8 s."),
"S18": dict(
 vis="Birthday memory card on a green gauge box ('EMPTY / PAID'), then pull-back to the boy standing by it in a teal-and-white checkerboard corridor; 'OPERATING' sign above the door flips dim → red.",
 cam="Whip pull-back and up (T8).", light="Cold clinical teal `#79A5A9`; luma 118; the red sign is the only hot colour.",
 depth="Foreground box large and defocused; boy mid.", expr="Hero: deadpan, half-lids, then a subtle eyebrow lift.", trans="Dissolve to the next sale.", beat="'The best birthday he ever had pays for the surgery.'",
 img="Vertical 9:16 clinical teal corridor with a checkerboard floor, a pale door with a small sign that reads OPERATING glowing red, a round-headed stick-figure boy with orange hair and a yellow vest standing with a flat blank expression beside a small olive-green gauge box on a pole holding a colourful birthday card, bright cold fluorescent light.",
 mot="Fast pull-back and rise from the card on the gauge box to reveal the boy; the OPERATING sign flicks from dim to red. 2.7 s."),
"S19": dict(
 vis="Protagonist stands selling whole years with a yellow banner ('…SUMMERS') on the teal wall behind; spotlight cones; head glows lavender-white then warm orange.",
 cam="Eye-level hold with tiny head-drift (motion 0.46).", light="Cool/warm flicker on his face, halo around his head at 54 s; luma 75.",
 depth="Mid shot; wall slightly soft.", expr="Alarm → deadpan → hollow stare → drooping head tilt.", trans="Cross-dissolve to the sickbed.", beat="'…until his head is mostly bad days and bus rides.'",
 img="Vertical 9:16 medium shot of a round-headed stick-figure boy with orange spiky hair and a yellow vest standing against a teal wall with a yellow banner, spotlights above, tired half-lidded eyes and a blank flat mouth, his head edged by a faint lavender-white glow as if fading, dark navy surroundings, strong vignette.",
 mot="Near-static, tiny head-drift; his face glow flickers between cool lavender and warm orange; the halo grows. 5.3 s."),
"S20": dict(
 vis="Brother worse in bed (dim blue room, lamp); then an open 'MEMORY SAVINGS' ledger: year rows 2025→2016 with red SOLD stamps, 2016 highlighted gold with a star.",
 cam="Bed → push into the ledger page.", light="Cold blue bed; bright paper page lifts frame luma to ≈ 136.",
 depth="Ledger flat to camera.", expr="Brother: sunken.", trans="Dissolve to the shop.", beat="'Until there's only one good year left.'",
 img="Vertical 9:16 top-down view of an open ledger book titled MEMORY SAVINGS with rows of years, each with a red SOLD stamp, one row highlighted gold with a star, pale paper, soft shadows; second image: dim blue hospital bedroom, a frail round-headed child in bed, small lamp.",
 mot="Dissolve from the bed to the ledger, SOLD stamps slam in one after another; camera pushes down to the gold star row. 4 s."),
"S21": dict(
 vis="Shop at night under a gold arched sign ('MEMORIES bought & sold — CASH TODAY · ALL GRADES'): stranger now worried and round-faced beside the boy wearing the helmet; stranger's face fills the frame during the warning.",
 cam="Slow push to the stranger, reverse on the boy.", light="Black surround with warm sign; 56 % <40 luma, but bright face (p95 234).",
 depth="Faces large; sign soft behind.", expr="Stranger: worried, brows raised, small 'o'; boy: resigned half-lids.", trans="Helmet drop (T10).", beat="'Kid, you don't want this. There's nothing happy left in there.'",
 img="Vertical 9:16 close-up of a pale round-headed hooded shopkeeper with worried raised brows and a small open mouth, black surroundings, a glowing gold arched sign reading MEMORIES bought & sold behind him, a round-headed boy with orange hair and a metal dome helmet on his head at the left edge, dark navy-black palette with warm gold accents.",
 mot="Slow push-in on the worried shopkeeper; cut-free swing to the boy as the helmet lowers over his head. 5 s."),
"S22": dict(
 vis="Helmet lowers over the head; a tube rises; camera follows it up into near-black navy where a glowing memory card forms among drifting pixel-blocks and tumbling blue letter shapes from the shop sign; card flares to full gold.",
 cam="Whip-follow upward; peak motion 10 px/frame at 64.1 s.", light="Luma 43→188 in 15 frames (the film's brightest flash).",
 depth="Abstract; no horizon.", expr="—", trans="Gold dissolves into the warm morning room.", beat="'…and it pays for everything.'",
 img="Vertical 9:16 abstract dark navy void with drifting blue pixel blocks, a small rectangular memory card glowing intensely warm gold at the centre, a transparent tube coming from below, faint outline of letters, deep blue and gold only.",
 mot="Camera follows a tube upward at speed into darkness; the card brightens and swells until it fills the screen with gold light. 1.6 s."),
"S23": dict(
 vis="A week later: bright cream-gold hospital morning; brother sits up with frog plush, cheering; background heavily blurred with get-well drawings and bokeh windows; royal-blue frame edges; red bedspread.",
 cam="Near-static, shallow DOF, hand-held-calm.", light="Honey light on cream; blue edges; luma 142; bloom 19 %.",
 depth="**Extreme shallow DOF** — background is pure bokeh.", expr="Brother: frown → beaming → ecstatic open grin → excited 'o'.", trans="T11 colour-temperature flip.", beat="'A week later, his brother sits up in bed, cured…'",
 img="Vertical 9:16 bright cosy hospital morning, a small round-headed stick-figure child with orange spiky hair sitting up in bed with a big happy open-mouth smile holding a polaroid, a green frog plush on the bed rail, red blanket, cream-gold light, extremely blurred background of windows and colourful get-well drawings, royal-blue edges to the frame.",
 mot="Near-static camera; the child sits up, hair bouncing, beams, then asks excitedly; background bokeh breathes subtly. 5.6 s."),
"S24": dict(
 vis="Cold cobalt close-up of the protagonist, pale lavender, blank confusion; brother small and warm at left; blurry window bokeh behind; ending freeze.",
 cam="Very slow push-in then total freeze (last 30 frames identical).", light="Cold cobalt key on Jerry vs warm honey on brother — the emotional punchline.",
 depth="Jerry in sharp foreground; brother mid; bokeh behind.", expr="Jerry: blank, quiet, a little lost.", trans="Freeze on the last frame.", beat="'…and his brother was in every single one…'",
 img="Vertical 9:16 close-up of a pale round-headed stick-figure man with orange hair bathed in cold cobalt-blue light, blank slightly confused face, a much smaller warm-lit child with orange hair in bed at the left, heavily blurred window bokeh behind, blue and warm-gold contrast, emotional and quiet.",
 mot="Very slow push-in over 5 s; subtle blink; frame freezes for the last second. 6.6 s."),
}

BEATS={"S01":"Opening hook: someone has traded away their happiest memory to a stranger.",
"S02":"The 'memory' is shown as a physical, glowing object you can hold.",
"S03":"Rule of this world: memories are currency.",
"S04":"Shift from the shop out into the wider city.",
"S05":"Memory shops are on every corner.",
"S06":"How the trade works: the memory is drawn out of the customer's head.",
"S07":"Everyday bills (rent, a birthday, groceries) are paid with the best days of your life.",
"S08":"A colossal wall splits the city into two worlds.",
"S09":"Rich side: the wealthy buy other people's summers.",
"S10":"A rich man 'owns' a pile of tropical holidays he never took.",
"S11":"…and never even gets off his couch.",
"S12":"Poor side: people stare at old photos, smiling without knowing why.",
"S13":"The happier the memory, the higher the price (the rule made visual).",
"S14":"The hero sells one to pay rent; the same week his little brother falls ill.",
"S15":"In hospital the little brother keeps asking for the same bedtime story.",
"S16":"That story is a golden summer when they caught a giant frog at the lake.",
"S17":"The medicine costs far more; he sells the frog-summer memory to afford it.",
"S18":"His best birthday pays for the surgery.",
"S19":"He keeps selling whole years until his head holds mostly bad days.",
"S20":"The brother worsens; the ledger shows only one good year left.",
"S21":"The shopkeeper warns him not to sell the last one.",
"S22":"He sells it anyway, and it pays for everything.",
"S23":"A week later the brother sits up, cured, and asks for the frog story.",
"S24":"Irony payoff: the hero no longer remembers who the boy is."}
for k,v in BEATS.items(): D[k]['beat']=v

# ---------- 02 breakdown ----------
out=["# 02 — SHOT-BY-SHOT BREAKDOWN (24 scenes, frame-accurate)\nTimes are in seconds from the start; frame = t × 30 + 1. Numbers (luma, sat, etc.) are measured over *every frame* of the scene. Palette swatches are the six dominant colours (percent of pixels).\n"]
for s in sc:
    d=D[s['id']]; pal=' · '.join(f"`{p['hex']}` {p['pct']:.0f}%" for p in s['palette'])
    fa=int(round(s['start']*30))+1; fb=min(2334,int(round(s['end']*30)))
    out.append(f"""
## {s['id']} · {s['name']}
**{s['start']:.2f} – {s['end']:.2f} s** (frames {fa}–{fb}, {s['frames']} frames, {s['end']-s['start']:.1f} s)

* **What you see:** {d['vis']}
* **Camera:** {d['cam']}
* **Lighting / shadow:** {d['light']}
* **Depth / blur:** {d['depth']}
* **Characters & expression:** {d['expr']}
* **Transition out:** {d['trans']}
* **Narrative beat (my paraphrase):** {d['beat']}
* **Measured:** luma **{s['luma']}**/255 (P5 {s['contrast_p5']}, P95 {s['contrast_p95']}) · saturation **{s['sat']}** · vignette corner÷centre **{s['vignette_corner_to_center']}** · bright-pixel share **{s['bright_frac']*100:.1f}%** · dark-pixel share **{s['dark_frac']*100:.0f}%** · motion **{s['motion']}** px/f · zoom divergence **{s['zoom_div']:+.2f}** · sharpness **{s['sharp_lap']}**
* **Palette:** {pal}
""")
open('/home/claude/work/pkg/02_Shot_By_Shot_Breakdown.md','w').write('\n'.join(out))
# ---------- 08 per-shot prompts ----------
STYLE_TAIL=" Style: 2.5D stylised animation — flat cel-coloured round-headed stick-figure characters with thick black ink outlines, in a painterly lit 3D-rendered environment; soft bloom, volumetric haze, clean gradients, no film grain, no photorealism."
p=["# 08 — PER-SHOT PROMPTS (24 scenes)\nFor each scene: **IMAGE PROMPT** (first frame / keyframe), **MOTION PROMPT** (image-to-video), **GRADE** (grade.sh preset + numbers), **TIMING**. Paste the *STYLE LOCK* from `07_Astra_Master_Prompts.md` before each image prompt if your generator forgets between shots. Generate at 9:16.\n"]
gm={'S01':'gloom','S02':'gloom','S03':'gloom','S04':'gloom','S05':'gloom','S06':'bright (haze) + extra bloom','S07':'gloom (use PI/5.5 vignette)','S08':'gloom','S09':'bright','S10':'bright','S11':'bright','S12':'gloom (cool)','S13':'gloom','S14':'gloom','S15':'gloom','S16':'warm/bright','S17':'gloom','S18':'bright, teal','S19':'gloom','S20':'gloom','S21':'gloom','S22':'gloom → gold flash','S23':'warm','S24':'gloom (cold cobalt)'}
for s in sc:
    d=D[s['id']]
    p.append(f"""
## {s['id']} · {s['name']}  ({s['start']:.2f}–{s['end']:.2f} s · {s['end']-s['start']:.1f} s clip)
**IMAGE PROMPT**
> {d['img']}{STYLE_TAIL}

**MOTION PROMPT**
> {d['mot']} Smooth eased camera, no shake, no cut, keep character outlines and colours consistent.

**GRADE:** preset `{gm[s['id']]}` — target luma ≈ {s['luma']}, saturation ≈ {s['sat']}, vignette corner÷centre ≈ {s['vignette_corner_to_center']}, dominant colours {', '.join(q['hex'] for q in s['palette'][:4])}.
**TRANSITION OUT:** {d['trans']}
""")
open('/home/claude/work/pkg/08_Per_Shot_Prompts.md','w').write('\n'.join(p))
print('scenes written:',len(sc))
