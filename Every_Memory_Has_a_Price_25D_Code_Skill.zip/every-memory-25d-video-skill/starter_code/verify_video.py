#!/usr/bin/env python3
"""
Automated QA Verifier (Skill v2.0) for 2.5D Hybrid Code Videos & Pre-Render Single-Frame Gates.
Checks:
  - Container spec (9:16 >= 720w), constant 30.00 FPS, zero hard cuts
  - Visual Detail Density Gate (edge_pct >= 12.0%, edge_mean >= 11.5 — prevents sparse rooms!)
  - Color Temperature Contrast & Shadow Palette (prevents monochromatic blue over-tinting!)
  - Practical Bloom Coverage (>= 0.10%), Vignette, Saturation, Ending Freeze, and -14 LUFS Loudness

Usage:
  Full Video QA:         python3 verify_video.py out/final.mp4 [--mode twilight|gloom|warm|cold] [--expect-freeze]
  Pre-Render Scene Gate: python3 verify_video.py --audit-frame out/_keyframes/scene_01.png [--expect-warm]
"""
import argparse
import json
import re
import subprocess
import sys
import numpy as np
from PIL import Image


def ffprobe_info(path):
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path],
        text=True,
    )
    return json.loads(out)


def decode_frames(path, w=180, h=320):
    raw = subprocess.check_output([
        "ffmpeg", "-v", "error", "-i", path,
        "-vf", f"scale={w}:{h}:flags=area",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-",
    ])
    arr = np.frombuffer(raw, dtype=np.uint8)
    n = arr.size // (h * w * 3)
    return arr[: n * h * w * 3].reshape(n, h, w, 3)


def check_lufs(path):
    proc = subprocess.run(
        ["ffmpeg", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"],
        stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True,
    )
    m_i = re.findall(r"I:\s+(-?\d+\.\d+)\s+LUFS", proc.stderr)
    m_tp = re.findall(r"Peak:\s+(-?\d+\.\d+)\s+dBFS", proc.stderr)
    return (float(m_i[-1]) if m_i else None, float(m_tp[-1]) if m_tp else None)


def measure_frame(rgb):
    arr = rgb.astype(np.float32)
    R, G, B = arr[..., 0], arr[..., 1], arr[..., 2]
    luma = 0.2126 * R + 0.7152 * G + 0.0722 * B
    cmax, cmin = arr.max(-1), arr.min(-1)
    sat = np.where(cmax > 1.0, (cmax - cmin) / np.maximum(cmax, 1.0), 0.0)
    gx = luma[1:-1, 2:] - luma[1:-1, :-2]
    gy = luma[2:, 1:-1] - luma[:-2, 1:-1]
    grad = np.sqrt(gx * gx + gy * gy)
    H, W = luma.shape
    ch, cw = H // 6, W // 6
    corners = np.concatenate([
        luma[:ch, :cw].ravel(), luma[:ch, -cw:].ravel(),
        luma[-ch:, :cw].ravel(), luma[-ch:, -cw:].ravel(),
    ])
    center = luma[H // 3 : 2 * H // 3, W // 3 : 2 * W // 3]
    dark = arr[luma <= np.percentile(luma, 5)]
    return {
        "luma": float(luma.mean()),
        "sat": float(sat.mean()),
        "warmth_rb": float((R - B).mean()),
        "vig": float(corners.mean() / max(center.mean(), 1e-3)),
        "bloom_pct": float((luma > 235.0).mean() * 100.0),
        "edge_mean": float(grad.mean()),
        "edge_pct": float((grad > 22.0).mean() * 100.0),
        "p05_rgb": (float(dark[:, 0].mean()), float(dark[:, 1].mean()), float(dark[:, 2].mean())),
    }


def check(label, ok, detail):
    print(f"[{'PASS' if ok else 'FAIL'}] {label}: {detail}")
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="Video MP4 path OR PNG path when --audit-frame is set")
    ap.add_argument("--audit-frame", action="store_true", help="Run Stage 4B single-frame detail gate on a PNG")
    ap.add_argument("--expect-warm", action="store_true", help="Require warm color temperature (R-B > -5) on frame")
    ap.add_argument("--mode", default="twilight", choices=["twilight", "gloom", "warm", "cold"])
    ap.add_argument("--expect-freeze", action="store_true")
    args = ap.parse_args()

    if args.audit_frame:
        im = Image.open(args.target).convert("RGB")
        w, h = im.size
        st = measure_frame(np.asarray(im.resize((180, 320), Image.BILINEAR)))
        dr, dg, db = st["p05_rgb"]
        ok = True
        ok &= check("9:16 Aspect & Resolution", w * 16 == h * 9 and w >= 720, f"{w}x{h}")
        ok &= check("Visual Detail Density Gate (edge_pct >= 12.0%)", st["edge_pct"] >= 12.0,
                    f"edge_pct={st['edge_pct']:.2f}%, edge_mean={st['edge_mean']:.2f} (ref Samurai=15.1%, EMHAP=19.2%)")
        ok &= check("Lifted Non-Crushed Shadows (max P05 RGB > 16)", max(dr, dg, db) > 16.0,
                    f"P05 RGB=({dr:.1f}, {dg:.1f}, {db:.1f})")
        ok &= check("Vignette Framing (0.18-0.88)", 0.18 <= st["vig"] <= 0.88, f"corner/center={st['vig']:.3f}")
        if args.expect_warm:
            ok &= check("Warm Scene Temperature (R-B > -5)", st["warmth_rb"] > -5.0, f"warmth(R-B)={st['warmth_rb']:+.1f}")
        sys.exit(0 if ok else 1)

    info = ffprobe_info(args.target)
    vs = next(s for s in info["streams"] if s["codec_type"] == "video")
    astreams = [s for s in info["streams"] if s["codec_type"] == "audio"]
    w, h = int(vs["width"]), int(vs["height"])
    num, den = map(int, vs["r_frame_rate"].split("/"))
    fps = num / den
    dur = float(info["format"]["duration"])

    ok = True
    ok &= check("Vertical 9:16 resolution", w * 16 == h * 9 and w >= 720, f"{w}x{h}")
    ok &= check("Constant 30 FPS", abs(fps - 30.0) < 0.01, f"{fps:.2f} fps, {dur:.2f} s")

    frames = decode_frames(args.target)
    n = len(frames)

    # Zero hard cuts check
    diffs = np.abs(frames[1:].astype(np.float32) - frames[:-1].astype(np.float32)).mean(axis=(1, 2, 3))
    hard_cuts = []
    for i in range(len(diffs)):
        lo, hi = max(0, i - 4), min(len(diffs), i + 5)
        med = float(np.median(diffs[lo:hi]))
        if diffs[i] > max(28.0, 4.0 * med):
            hard_cuts.append((i + 1, round(float(diffs[i]), 1), round(med, 1)))
    ok &= check("Zero hard cuts", len(hard_cuts) == 0, f"detected={hard_cuts[:5]}")

    # Sample every 15th frame for whole-video detail density, bloom, warmth & shadow audit
    sample_stats = [measure_frame(frames[i]) for i in range(0, n, max(1, n // 40))]
    mean_edge_pct = float(np.mean([s["edge_pct"] for s in sample_stats]))
    mean_edge = float(np.mean([s["edge_mean"] for s in sample_stats]))
    mean_bloom = float(np.mean([s["bloom_pct"] for s in sample_stats]))
    mean_sat = float(np.mean([s["sat"] for s in sample_stats]))
    p90_warmth = float(np.percentile([s["warmth_rb"] for s in sample_stats], 90))
    mean_vig = float(np.mean([s["vig"] for s in sample_stats]))

    ok &= check("Whole-Video Detail Density (edge_pct >= 12.0%)", mean_edge_pct >= 12.0,
                f"edge_pct={mean_edge_pct:.2f}%, edge_mean={mean_edge:.2f} (Samurai=15.1%, EMHAP=19.2%)")
    ok &= check("Mean Saturation (0.30-0.75)", 0.30 <= mean_sat <= 0.75, f"sat={mean_sat:.3f}")
    ok &= check("Vignette Corner/Center (0.18-0.90)", 0.18 <= mean_vig <= 0.90, f"ratio={mean_vig:.3f}")
    ok &= check("Practical Bloom Highlights (mean >= 0.15%)", mean_bloom >= 0.15, f"bloom(>235)={mean_bloom:.2f}%")
    if args.mode in ("twilight", "warm"):
        ok &= check("Warm-vs-Cool Dynamic Range (P90 warmth R-B > 0)", p90_warmth > 0.0,
                    f"P90 warmth={p90_warmth:+.1f} (prevents monochromatic over-bluing!)")

    mid = measure_frame(frames[n // 2])
    dr, dg, db = mid["p05_rgb"]
    if args.mode in ("gloom", "cold"):
        ok &= check("Lifted Indigo/Cobalt Shadows", db > dr and db > dg and db > 12,
                    f"P05 RGB=({dr:.1f}, {dg:.1f}, {db:.1f})")
    else:
        ok &= check("Lifted Natural Twilight Shadows", max(dr, dg, db) > 16,
                    f"P05 RGB=({dr:.1f}, {dg:.1f}, {db:.1f})")

    if args.expect_freeze and n >= 30:
        end_std = float(frames[-28:].astype(np.float32).std(axis=0).mean())
        ok &= check("Ending 1s Freeze Hold", end_std < 0.5, f"pixel_std={end_std:.3f}")

    if astreams:
        lufs, tp = check_lufs(args.target)
        if lufs is not None:
            ok &= check("Audio Loudness (-14 LUFS +/-2.5)", -16.5 <= lufs <= -11.5, f"{lufs:.1f} LUFS, peak {tp:.1f} dBFS")

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
