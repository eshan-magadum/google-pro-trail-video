# 09 — STEP-BY-STEP PRODUCTION WORKFLOW

## Overview (≈ 1.5–3 days for a 78 s short)
1. **Story & script** (Astra, PROMPT 1) → pick a premise → 215-word narration → shot list.
2. **Character lock** (PROMPT 3) → generate the sheet; keep the best frames as *reference images* for every later generation.
3. **Keyframes** — for each of the 24 scenes: STYLE LOCK + the scene's IMAGE PROMPT (from `08_Per_Shot_Prompts.md`) + character reference images. Generate 4–6 candidates, choose 1. Check against `reference_frames/Sxx_*.jpg`.
4. **Animate** — image-to-video for each keyframe with PROMPT 5 + the scene's MOTION PROMPT. Duration = scene length (+0.5 s handles). 1080×1920, 24–30 fps (conform to 30).
5. **Grade each clip** — `./grade.sh clip.mp4 clip_g.mp4 gloom|bright|warm` (or the numbers in doc 04 in DaVinci/Premiere).
6. **Assemble** on a 30 fps, 1080×1920 timeline in the scene order; overlap clips for the transitions (doc 03: 0.25–2 s each). Where an AI tool can't do the special transition (glass-pane, polaroid, water dive, gold flare) build it in the editor: mask wipe, cross-dissolve with scale-in, or an overlay of a gold radial gradient (Add blend, opacity 0→100→0 over 0.4 s).
7. **Narration** — record or generate a warm close-mic male voice; pace ≈ 2.8 words/s.
8. **Captions** — 1–2 words each, white 84 px bold sans, 7–8 px black stroke + soft shadow, centred, baseline at 71 % of height (y ≈ 1370 on 1080×1920); chunk lengths from `data/caption_chunk_timing.csv`.
9. **Sound** — rain bed, price-counter ticks, whooshes at every camera swing, electric hum at the helmet, silence before the flare, low ambient music; master −14 LUFS / −1.5 dBTP.
10. **Final pass** — add 10–20 % extra bloom on lights, check vignette is consistent in gloom scenes, freeze the last second, export H.264 1080×1920 30 fps ~12–16 Mbps, AAC 192 kbps.

## Consistency tricks that matter most
* Use the **same seed / reference images** for every shot containing a character.
* Lock **colour tokens**: Indigo shadow `#0F0D25`, hair orange `#D9532A`, vest yellow, gold `#B58955`/`#F7D99F`, teal `#79A5A9`, royal blue `#3A448E`.
* Always keep the character **flat** — if a generator adds 3D shading to a face, regenerate; the cel/3D split is the style.
* Generate **gloom scenes slightly too bright and desaturated** if the tool tends to crush — then finish with `grade.sh`.
* Keep each clip ≤ 6 s (AI motion drifts after that); stitch long holds with a slow scale animation in the editor.
* Lip movement is not required: the narration is voice-over; mouths barely move.

## Export presets
| Platform | Size | fps | Bitrate |
|---|---|---|---|
| YouTube Shorts / TikTok / Reels | 1080×1920 | 30 | 12–16 Mbps H.264, AAC 192 kbps |
| Archive master | 1080×1920 | 30 | ProRes 422 HQ or 40 Mbps |

## Checklist before publishing (QA)
- [ ] All 24 scenes present, no hard cuts
- [ ] Mean luma of gloom scenes 45–80; saturation 0.55–0.69
- [ ] Vignette visible but not black corners (corner÷centre 0.25–0.40)
- [ ] Gold glow used only on memory objects
- [ ] Captions never overlap faces
- [ ] Narration −14 LUFS, true peak ≤ −1.5 dB
- [ ] Final second is a still frame
- [ ] **Original characters, story and script** (see note in 00_START_HERE)
