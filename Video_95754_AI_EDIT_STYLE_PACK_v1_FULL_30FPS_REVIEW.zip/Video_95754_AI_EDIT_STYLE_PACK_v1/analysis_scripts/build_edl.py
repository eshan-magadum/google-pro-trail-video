import json, csv

FPS = 2997 / 100
scenes = json.load(open("/tmp/v95/pack/data/scenes.json"))["scenes"]
captions = list(csv.DictReader(open("/tmp/v95/pack/data/caption_chunks_frame_accurate.csv")))

shot_specs = {
  "S01": {
    "world": "World_A_Dark_Editorial",
    "spoken_text": "Anthropic engineer just built the most",
    "metaphor": "Authority source card (Goya etching 'Modo de volar' from Anthropic engineer article) + Anthropic brand pill above speaker",
    "camera": {"move": "slow_push_and_settle", "scale_from": 1.04, "scale_to": 1.00, "curve": "ease-out"},
    "layers": [
      {"type": "top_pane_bg", "rect": [0,0,720,640], "fill": "#11100e", "radial_lift": "#1e1c18"},
      {"type": "framed_artwork_card", "center": [360,335], "size": [585,430], "radius": 12, "mat_color": "#d8ceb8", "content": "Goya_Modo_de_volar_etching"},
      {"type": "source_pill", "pos": [0,462], "size": [205,38], "radius_right": 19, "fill": "#f4efe4", "text": "A\\ Anthropic •", "font": "Serif SemiBold 22px #11100e"},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640], "scale": 1.0, "gesture_frames": [37,53], "gesture": "both_hands_rise"}
    ],
    "events": [
      {"frame": 1, "primitive": "card_settle_drift", "detail": "Framed card & Anthropic pill settle inward over 53 frames"},
      {"frame": 37, "primitive": "speaker_gesture", "detail": "Speaker raises both hands open-palmed on 'just built'"}
    ]
  },
  "S02": {
    "world": "World_A_Dark_Editorial",
    "spoken_text": "powerful prompt that I have ever seen,",
    "metaphor": "Direct close-up of the actual blockquote prompt in dark mode",
    "camera": {"move": "slow_push_in", "scale_from": 1.00, "scale_to": 1.03, "curve": "linear"},
    "layers": [
      {"type": "full_bg", "rect": [0,0,720,1280], "fill": "#100f0b", "radial_lift": "#1c1b17"},
      {"type": "lead_in_text", "pos": [90,340], "text": "A simple prompt that often helps me:", "font": "Serif Regular 22px #8e8d8a"},
      {"type": "blockquote_rule", "rect": [90,380,4,410], "fill": "#7e82e8"},
      {"type": "blockquote_text", "rect": [116,380,520,410], "font": "Serif Regular 26px #e8e6df", "line_height": 1.42,
       "text": "I want a deeper version of this task, not a bigger one. Before rewriting it: (1) say what a top professional in this field would do here that I'm not asking for; (2) name the rawest material they would start from instead of what has already been digested for me; (3) name the specific methods and tools they would use; (4) say what, other than you or me, would show the result is right. Then rewrite my prompt to ask for exactly that."}
    ],
    "events": [
      {"frame": 54, "primitive": "ambient_push", "detail": "Readable close-up holds with 3% slow push-in"}
    ]
  },
  "S03": {
    "world": "World_A_Dark_Editorial",
    "spoken_text": "but nobody is using it.",
    "metaphor": "Camera zooms out to the full long-form article and draws a highlight box around the hidden prompt",
    "camera": {"move": "P18_doc_zoom_out_and_scroll", "frames": [122,150], "scale_from": 0.78, "scale_to": 0.42, "curve": "ease-in-out"},
    "layers": [
      {"type": "full_bg", "rect": [0,0,720,1280], "fill": "#100f0b"},
      {"type": "full_article_column", "center_x": 360, "paragraphs": ["Produce new knowledge", "Challenge what you know", "Use an outside judge", "Blockquote prompt", "Range"]},
      {"type": "highlight_box", "primitive": "P05", "frames": [143,148], "stroke": "#7e82e8", "stroke_width": 2.5, "radius": 8, "glow": 8}
    ],
    "events": [
      {"frame": 122, "primitive": "P18", "detail": "Continuous zoom-out and upward scroll revealing surrounding essay"},
      {"frame": 143, "primitive": "P05", "detail": "Lavender rounded highlight box draws around the blockquote over 6 frames"}
    ]
  },
  "S04": {
    "world": "World_A_and_B_Iceberg_Surface",
    "spoken_text": "When prompting, most of us just describe the task.",
    "metaphor": "Claude chat box on the tiny above-water tip of an iceberg typing a surface-level task",
    "camera": {"move": "slow_push_in", "scale_from": 1.00, "scale_to": 1.025, "curve": "linear"},
    "layers": [
      {"type": "top_pane_iceberg_tip", "rect": [0,0,720,640], "sky": "#f4f9f8", "waterline_y": 445, "water_color": "#3bd4f5"},
      {"type": "claude_chat_card", "rect": [110,210,500,115], "radius": 20, "fill": "#ffffff", "model_label": "Opus 5.5 ⌄", "send_btn": "#e8743b"},
      {"type": "suggestion_chips", "items": [{"text": "Write a blog post", "x": 130, "y": 368}, {"text": "Summarize this", "x": 590, "y": 372}]},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640], "gesture_frames": [221,232]}
    ],
    "events": [
      {"frame": 176, "primitive": "placeholder_idle", "detail": "'How can I help you today?' with blinking caret"},
      {"frame": 184, "primitive": "P01_typewriter", "end_frame": 231, "text": "Make a slide deck for our Q3 review.", "rate_fr_per_char": 1.3}
    ]
  },
  "S05": {
    "world": "World_B_Iceberg_Underwater",
    "spoken_text": "Well, in fact, we should be using the deeper meaning behind the prompt.",
    "metaphor": "Camera dives underwater down the iceberg as the 4 hidden layers of the prompt light up inside the ice",
    "camera": {"move": "P19_vertical_dive", "frames": [246,300], "pan_y_px": 520, "curve": "ease-in-out"},
    "layers": [
      {"type": "underwater_gradient", "colors": ["#3bd4f5", "#0866c6", "#084597", "#091f55"]},
      {"type": "low_poly_iceberg", "center_x": 360, "y_range": [20,880], "fill": "#d7f2f7", "facet_stroke": "#ffffff"},
      {"type": "internal_warm_bloom", "frames": [288,368], "center": [360,470], "radius": 220, "color": "#ffb870"},
      {"type": "stacked_3d_icons", "items": [
        {"slot": 1, "y": 215, "emoji": "👩‍🔬", "label": "What a pro would do", "reveal_frame": 309},
        {"slot": 2, "y": 385, "emoji": "🗄️", "label": "The rawest material", "reveal_frame": 322},
        {"slot": 3, "y": 545, "emoji": "🧰", "label": "Their methods & tools", "reveal_frame": 335},
        {"slot": 4, "y": 700, "emoji": "✅", "label": "What proves it right", "reveal_frame": 348}
      ]}
    ],
    "events": [
      {"frame": 246, "primitive": "P19", "detail": "Switch to full-screen and tilt down below waterline over 54 frames"},
      {"frame": 288, "primitive": "warm_core_bloom", "detail": "Warm peach glow fades in at the heart of the iceberg"},
      {"frame": 309, "primitive": "P09_P10_P11", "detail": "Layer 1 (Scientist + 'What a pro would do') pops from 30% grey to 3D colour"},
      {"frame": 322, "primitive": "P09_P10_P11", "detail": "Layer 2 (File box + 'The rawest material') pops (+13 frames)"},
      {"frame": 335, "primitive": "P09_P10_P11", "detail": "Layer 3 (Red toolbox + 'Their methods & tools') pops (+13 frames)"},
      {"frame": 348, "primitive": "P09_P10_P11", "detail": "Layer 4 (Green check + 'What proves it right') pops (+13 frames)"}
    ]
  },
  "S06": {
    "world": "Speaker_Punch_In",
    "spoken_text": "For example,",
    "metaphor": "Human signpost breather before switching to World C cartoon example",
    "camera": {"move": "static_punch_in", "scale": 1.75},
    "layers": [{"type": "speaker_fullscreen", "rect": [0,0,720,1280], "scale": 1.75}],
    "events": [{"frame": 377, "primitive": "speaker_gesture", "detail": "Left hand rises into lower frame"}]
  },
  "S07": {
    "world": "World_C_Retro_Cartoon_Desk",
    "spoken_text": "instead of saying to Claude, fix this bug, say to Claude, keep this app bug-free.",
    "metaphor": "Swatting bugs cracks the phone screen ('fix this bug'); rewriting to 'keep this app bug free' triggers a green shield shockwave that heals the phone and drops the swatter",
    "camera": {"move": "micro_push", "scale_from": 1.00, "scale_to": 1.02, "curve": "linear"},
    "layers": [
      {"type": "wallpaper_and_desk", "wall": "#f8efd8", "desk_trim": "#d96b1f", "desk": "#9c450c", "desk_y": 855},
      {"type": "claude_input_bar", "rect": [36,165,648,96], "outline": "6px #1e1612", "fill": "#ffffff"},
      {"type": "cartoon_smartphone", "rect": [235,340,250,515], "outline": "10px #1e1612", "app": "sunset_waves_music_player"},
      {"type": "fly_swatter_arm", "color": "#3d8ec9", "outline": "5px #1e1612"}
    ],
    "events": [
      {"frame": 392, "primitive": "P01_typewriter", "end_frame": 406, "text": "fix this bug"},
      {"frame": 392, "primitive": "swatter_enter", "detail": "Fist with blue fly-swatter slides in from right"},
      {"frame": 411, "primitive": "P23_swat_slam_1", "detail": "Swatter slams phone -> yellow impact star + screen crack 1"},
      {"frame": 422, "primitive": "P02_red_strikethrough", "end_frame": 426, "detail": "Red bar strikes through 'fix this bug'"},
      {"frame": 428, "primitive": "P23_swat_slam_2", "detail": "Second slam Top -> big star + more glass cracks + new ladybug"},
      {"frame": 431, "primitive": "input_clear", "detail": "Strikethrough text cleared to empty caret"},
      {"frame": 438, "primitive": "P23_swat_slam_3", "detail": "Third slam Bottom -> more cracks"},
      {"frame": 442, "primitive": "P01_typewriter", "end_frame": 481, "text": "keep this app bug free"},
      {"frame": 457, "primitive": "bug_escalation", "detail": "Sweat drops appear on fist; orange pixel-invader bug spawns on top of phone"},
      {"frame": 483, "primitive": "P03_green_highlight", "end_frame": 486, "detail": "Mint green highlighter sweeps across 'bug free'"},
      {"frame": 488, "primitive": "P23_P11_heal_shockwave", "end_frame": 500, "detail": "Golden swoosh arcs + expanding mint ring heal all cracks, knock bugs off, leave green shield outline, and drop swatter onto desk"}
    ]
  },
  "S08": {
    "world": "World_A_Clean_UI",
    "spoken_text": "Paste this prompt in before any task.",
    "metaphor": "3D Cmd+V keycaps press and drop the blurred 'be-ambitious' prompt card above the user's task, synced to speaker's downward hand press",
    "camera": {"move": "slow_push_in", "scale_from": 1.00, "scale_to": 1.02},
    "layers": [
      {"type": "top_pane_grid_bg", "rect": [0,0,720,640], "fill": "#f7f6f3", "grid": "#e9e4dc", "dotted_paths": "#e8a88a"},
      {"type": "keycaps_3d", "keys": ["⌘", "V"], "y": 180, "size": [128,128]},
      {"type": "claude_prompt_box", "rect": [60,315,600,320], "task_line": "🚀 Plan our product launch."},
      {"type": "pasted_skill_card", "primitive": "P08", "title": "✳ be-ambitious", "body": "7_lines_blurred_prompt"},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640], "gesture_frames": [531,548], "gesture": "both_hands_press_down"}
    ],
    "events": [
      {"frame": 523, "primitive": "P06_keycap_press", "end_frame": 530, "detail": "⌘ and V depress with orange glow outline"},
      {"frame": 531, "primitive": "P07_card_drop_push", "end_frame": 536, "detail": "'be-ambitious' card drops in with spring overshoot, pushing 'Plan our product launch.' down"},
      {"frame": 544, "primitive": "P11_pulse_ring", "end_frame": 560, "detail": "Large thin peach circle expands behind the card"}
    ]
  },
  "S09": {
    "world": "World_C_Retro_Cartoon_Desk",
    "spoken_text": "And that's why this Anthropic skill is so powerful.",
    "metaphor": "SKILL.md / 'be-ambitious' cartridge slots into an orange retro machine, lighting 6 LEDs, pinning the gauge in the red, shaking with lightning and sunburst rays",
    "camera": {"move": "micro_push", "scale_from": 1.00, "scale_to": 1.03},
    "layers": [
      {"type": "wallpaper_and_desk", "wall": "#f7e8cd", "desk_trim": "#d96b1f", "desk": "#9c440b", "desk_y": 855},
      {"type": "sunburst_rays", "frames": [628,641], "color": "#fff6d6", "opacity": 0.42},
      {"type": "skill_cartridge", "header": "✦ SKILL.md", "title": "be-ambitious", "font": "Bold Italic Serif 36px"},
      {"type": "retro_power_console", "rect": [58,500,604,312], "fill": "#f67644", "leds": 6, "crt": "orange_pixel_invader", "gauge": "green_to_red_needle"}
    ],
    "events": [
      {"frame": 566, "primitive": "idle_float", "end_frame": 600, "detail": "Cartridge hovers and bobs above console slot"},
      {"frame": 589, "primitive": "badge_stamp", "detail": "Small Anthropic 'A\\' badge pops onto bottom-right of cartridge on 'anthropic'"},
      {"frame": 601, "primitive": "P25_cartridge_insert", "end_frame": 606, "detail": "Cartridge slides down into the slot"},
      {"frame": 607, "primitive": "P11_pulse_ring", "end_frame": 618, "detail": "Orange ring expands from slot"},
      {"frame": 613, "primitive": "P25_leds_and_needle", "end_frame": 628, "detail": "6 LEDs light left-to-right; pixel invader blooms; gauge needle swings into red zone"},
      {"frame": 625, "primitive": "P25_shake_lightning_rays", "end_frame": 641, "detail": "Console vibrates with yellow electric arcs + rotating sunburst rays fade in"}
    ]
  },
  "S10": {
    "world": "World_A_Clean_UI",
    "spoken_text": "Just paste it in before any task,",
    "metaphor": "Automated stamp press stamps an orange 'be-ambitious' tab onto every task card riding a conveyor belt",
    "camera": {"move": "static_clean"},
    "layers": [
      {"type": "top_pane_bg", "rect": [0,0,720,640], "fill": "#f6f7f5", "warm_glow_right": "#fff0c2"},
      {"type": "stamp_press", "head_rect": [252,115,216,138], "piston_x": 360, "stamp_pill": "✳ be-ambitious"},
      {"type": "conveyor_belt", "rect": [52,575,616,45], "fill": "#1c2d3d", "speed_px_per_fr": -4.0,
       "cards": ["📊 Q3 review deck", "✉️ Launch email", "🐞 Checkout bug", "📋 Product roadmap"]},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640]}
    ],
    "events": [
      {"frame": 647, "primitive": "P24_stamp_cycle_1", "detail": "Press slams 'Q3 review deck' -> attaches orange 'be-ambitious' tab + peach pulse ring"},
      {"frame": 672, "primitive": "P24_stamp_cycle_2", "detail": "Press slams 'Launch email' (+25 frames) -> tab + pulse ring"},
      {"frame": 696, "primitive": "P24_stamp_cycle_3", "detail": "Press slams 'Checkout bug' (+24 frames) -> tab + pulse ring"}
    ]
  },
  "S11": {
    "world": "World_C_Theatre_Stage",
    "spoken_text": "and it tells you what a top",
    "metaphor": "Spotlighted stage door labeled 'Expert' swings open into blinding light and camera rushes inside",
    "camera": {"move": "P20_walkthrough_zoom", "frames": [721,732], "scale_from": 1.00, "scale_to": 1.32, "curve": "ease-in"},
    "layers": [
      {"type": "purple_curtain_and_stage", "curtain": "#290f31", "floor": "#471d07", "floor_y": 810},
      {"type": "spotlight_cone", "fill": "rgba(255,232,185,0.28)"},
      {"type": "expert_door", "rect": [228,390,264,455], "fill": "#8a3e15", "plaque": "Expert", "light_interior": "#fdf4c5"}
    ],
    "events": [
      {"frame": 715, "primitive": "P20_door_swing", "end_frame": 720, "detail": "Door rotates open in 3D; warm light floods out + purple god-ray fan bursts behind"},
      {"frame": 721, "primitive": "P20_zoom_into_light", "end_frame": 732, "detail": "Fast 1.32x push-in toward open doorway"}
    ]
  },
  "S12": {
    "world": "World_C_Theatre_Stage",
    "spoken_text": "expert would say,",
    "metaphor": "Spotlit grey-bearded professor at a Claude lectern raises his finger and says 'Reproduce it first.'",
    "camera": {"move": "micro_push", "scale_from": 1.00, "scale_to": 1.02},
    "layers": [
      {"type": "purple_curtain_and_stage", "curtain": "#290f31", "floor": "#471e08", "floor_y": 810},
      {"type": "professor_at_lectern", "center": [360,590], "medallion": "gold_claude_asterisk"},
      {"type": "speech_bubble", "primitive": "P13", "frames": [742,774], "text": "Reproduce it first.", "font": "Bold Italic Serif 42px #111"}
    ],
    "events": [
      {"frame": 737, "primitive": "finger_raise_anticipation", "end_frame": 741, "detail": "Professor raises index finger"},
      {"frame": 742, "primitive": "P13_bubble_pop", "end_frame": 746, "detail": "Speech bubble pops in with spring overshoot"},
      {"frame": 745, "primitive": "P14_mouth_flap", "end_frame": 773, "detail": "2-state mouth flap animation while speaking"}
    ]
  },
  "S13": {
    "world": "World_D_Night_Bulbs",
    "spoken_text": "things that you would never have thought about.",
    "metaphor": "A flashlight beam in a dark room ignites one hanging light bulb, then triggers a full 13-bulb cascade that warms the whole sky",
    "camera": {"move": "static_top_pane"},
    "layers": [
      {"type": "top_pane_night_sky", "rect": [0,0,720,640], "fill_start": "#0e0b1d", "fill_end": "#5c3c28"},
      {"type": "hanging_edison_bulbs", "count": 13, "unlit_color": "#5d708c", "lit_color": "#ffe066", "halo": "#ff9d2e"},
      {"type": "searchlight_cone", "primitive": "P26", "frames": [775,811]},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640]}
    ],
    "events": [
      {"frame": 775, "primitive": "P26_beam_sweep", "end_frame": 810, "detail": "Searchlight beam sweeps left-to-right across unlit bulbs"},
      {"frame": 786, "primitive": "bulb_ignite_1", "detail": "First bulb lights warm yellow with orange glow"},
      {"frame": 802, "primitive": "bulb_ignite_2", "detail": "Second bulb lights"},
      {"frame": 813, "primitive": "P26_cascade_and_sky_warm", "end_frame": 832, "detail": "All remaining 11 bulbs ignite in rapid cascade with gold P11 rings; background warms from navy to amber"}
    ]
  },
  "S14": {
    "world": "Speaker_Punch_In",
    "spoken_text": "And it doesn't just give you advice.",
    "metaphor": "Tight speaker punch-in with sceptical eye-roll on 'advice'",
    "camera": {"move": "static_punch_in", "scale": 1.78},
    "layers": [{"type": "speaker_fullscreen", "rect": [0,0,720,1280], "scale": 1.78}],
    "events": [{"frame": 867, "primitive": "speaker_expression", "detail": "Sceptical squint and sideways eye-roll on 'you advice,'"}]
  },
  "S15": {
    "world": "World_C_Cutting_Mat",
    "spoken_text": "It actually reviews the whole prompt,",
    "metaphor": "Magnifying glass scans a ruled index card ('Why is checkout so slow?'), then a red marker underlines 'checkout' and circles 'so slow?'",
    "camera": {"move": "static_top_pane"},
    "layers": [
      {"type": "top_pane_cutting_mat", "rect": [0,0,720,640], "fill": "#1b5e3c", "grid": "#2e7d56"},
      {"type": "ruled_index_card", "rect": [55,195,610,315], "tilt_deg": -1.2, "text": "Why is checkout\nso slow?", "font": "Bold Italic Serif 52px"},
      {"type": "magnifying_glass", "primitive": "P22", "frames": [883,912], "lens_zoom": 1.35},
      {"type": "red_marker_strokes", "primitive": "P04", "frames": [915,934]},
      {"type": "speaker_bottom_pane", "rect": [0,640,720,640], "gesture": "finger_to_temple_then_point"}
    ],
    "events": [
      {"frame": 883, "primitive": "P22_magnifier_pass", "end_frame": 912, "detail": "Magnifying glass glides left-to-right magnifying text inside lens"},
      {"frame": 915, "primitive": "P04_wavy_underline", "end_frame": 920, "detail": "Red marker draws wavy underline under 'checkout'"},
      {"frame": 925, "primitive": "P04_red_circle", "end_frame": 933, "detail": "Red marker circles 'so slow?'"}
    ]
  },
  "S16": {
    "world": "World_C_Royal_Blue_Sunburst",
    "spoken_text": "so you're getting the expert version of it.",
    "metaphor": "Index card flips 180° in 3D into the gold-bordered 'Expert version' checklist, gets stamped with a gold verified seal, and bursts with confetti",
    "camera": {"move": "slow_push_in", "scale_from": 1.00, "scale_to": 1.03},
    "layers": [
      {"type": "royal_blue_sunburst_bg", "base": "#033bb7", "rays": "#2f6ae0", "rays_fade_in_frame": 943},
      {"type": "flippable_expert_card", "rect": [42,290,636,455], "border": "double gold #f5b841 + black 6px", "header": "✳ Expert version",
       "rows": [
         {"icon": "📈", "color": "#5eb0e5", "text": "Raw traces", "reveal_frame": 949},
         {"icon": "⏱️", "color": "#f5a623", "text": "Profile it", "reveal_frame": 954},
         {"icon": "✅", "color": "#82c985", "text": "Load test", "reveal_frame": 959}
       ]},
      {"type": "verified_gold_seal", "primitive": "P15", "frame": 972, "pos": [595,375]},
      {"type": "confetti_emitter", "primitive": "P17", "frames": [975,1003]}
    ],
    "events": [
      {"frame": 936, "primitive": "P21_3d_card_flip", "end_frame": 944, "detail": "Card flips on Y-axis from 'Why is checkout so slow?' to 'Expert version'; blue sunburst rays fade in + gold pulse ring"},
      {"frame": 949, "primitive": "P09_row_reveal_1", "detail": "'Raw traces' row activates from 30% grey"},
      {"frame": 954, "primitive": "P09_row_reveal_2", "detail": "'Profile it' row activates (+5 frames)"},
      {"frame": 959, "primitive": "P09_row_reveal_3", "detail": "'Load test' row activates (+5 frames)"},
      {"frame": 972, "primitive": "P15_P16_P17_seal_and_confetti", "end_frame": 1003, "detail": "Gold checkmark seal stamps top-right + shine sweep + gold ring + 35-particle confetti burst"}
    ]
  },
  "S17": {
    "world": "World_C_Royal_Blue_Sunburst",
    "spoken_text": "(of it.)",
    "metaphor": "8-frame teaser flash of 'The Prompt' sheet stamped EXCLUSIVE",
    "camera": {"move": "idle_float"},
    "layers": [
      {"type": "royal_blue_sunburst_bg", "base": "#053ab2", "rays": "#3d66ca"},
      {"type": "prompt_document_sheet", "center": [360,510], "size": [365,435], "tilt_deg": -3.0, "title": "✦ The Prompt", "stamp": "EXCLUSIVE (-15 deg red border)"}
    ],
    "events": [{"frame": 1004, "primitive": "teaser_flash", "detail": "8-frame high-retention visual flash of the downloadable prompt object"}]
  },
  "S18": {
    "world": "Speaker_CTA_Punch_In",
    "spoken_text": "Want the prompt? Comment deeper and I'll send it over.",
    "metaphor": "Tight speaker CTA punch-in with giant serif “DEEPER\" keyword synced to air-quotes",
    "camera": {"move": "progressive_push_in", "scale_from": 1.75, "scale_to": 1.88, "curve": "ease-out"},
    "layers": [
      {"type": "speaker_fullscreen", "rect": [0,0,720,1280]},
      {"type": "cta_keyword_serif", "frames": [1040,1093], "center": [360,955], "text": "“DEEPER\"", "font": "Bold Display Serif 94px #ffffff", "shadow": "0 6px 18px rgba(0,0,0,0.85)"}
    ],
    "events": [
      {"frame": 1040, "primitive": "cta_keyword_lock", "detail": "Giant white serif “DEEPER\" pops on below caption chip and stays locked to f1093"},
      {"frame": 1045, "primitive": "speaker_air_quotes", "end_frame": 1060, "detail": "Speaker raises both hands for air-quotes with big smile"}
    ]
  }
}

edl = {
  "meta": {
    "source_video": "Video-95754.mp4",
    "resolution": [720, 1280],
    "aspect_ratio": "9:16",
    "fps": round(FPS, 2),
    "total_frames": 1093,
    "duration_s": 36.47,
    "audio_target": {"integrated_lufs": -14.1, "lra_lu": 1.6, "true_peak_dbfs": -0.9, "speech_wpm": 214},
    "layout_rules": {
      "SPLIT": {"top_graphic_rect": [0,0,720,640], "bottom_speaker_rect": [0,640,720,640], "caption_center_y": 632},
      "FULL_GFX": {"graphic_rect": [0,0,720,1280], "caption_center_y": 850},
      "FULL_SPEAKER": {"speaker_rect": [0,0,720,1280], "zoom_factor": 1.76, "caption_center_y": 850, "cta_keyword_center_y": 955}
    }
  },
  "shots": [],
  "captions": captions
}

for sc in scenes:
    sid = sc["id"]
    merged = dict(sc)
    merged.update(shot_specs[sid])
    merged["shot_captions"] = [c for c in captions if c["scene"] == sid]
    edl["shots"].append(merged)

json.dump(edl, open("/tmp/v95/pack/edit_decision_list.json", "w"), indent=2)
print("wrote edit_decision_list.json with", len(edl["shots"]), "shots and", len(edl["captions"]), "captions")
