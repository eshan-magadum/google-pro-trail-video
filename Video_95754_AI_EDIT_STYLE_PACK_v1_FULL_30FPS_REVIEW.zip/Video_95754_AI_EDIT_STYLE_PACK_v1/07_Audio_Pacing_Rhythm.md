# 07 — AUDIO, PACING & RHYTHM SPECIFICATION

Full per-frame audio data is in `data/audio_per_frame.csv` and `data/audio_summary.json`. Word-level timestamps are in `data/transcript.json`.

## 1. Measured audio fingerprint
| Metric | Value | Notes |
|---|---|---|
| **Sample rate / channels** | 48,000 Hz, 2 channels (AAC 53 kbps) | Almost completely mono: side-to-mid ratio is **0.0202** (−34 dB side energy). |
| **Integrated loudness (EBU R128)** | **−14.1 LUFS** | Ideal Instagram / TikTok / YouTube Shorts target (−14 LUFS). |
| **Loudness range (LRA)** | **1.6 LU** (LRA low −14.9, high −13.3) | Heavily compressed / levelled voiceover — every syllable sits at almost the exact same loudness. |
| **True / sample peak** | **−0.9 dBFS** | Brickwall limiter at −0.9 dBFS. |
| **Per-frame RMS distribution** | p10 **−28.8 dBFS**, median **−19.1 dBFS**, p90 **−12.5 dBFS** | Quietest frames in the entire 36.5 s video only drop to **−39.8 dBFS** (f971). |
| **Silence gaps > 120 ms below −40 dB** | **0 (none)** | Every breath pause longer than ~0.12 s was trimmed out before or during editing. |
| **Background floor / music bed** | Very low continuous mid-frequency floor (~−24 to −28 dBFS during micro-pauses at f125, f735, f1006, peaking around 150–780 Hz) | Either a very subtle low-mixed ambient synth pad (−26 dBFS, ~12 dB below speech) or room/mic floor under heavy compression. Speech is 100% dominant; there are **no loud whoosh/boom SFX spikes** masking the voice. |

## 2. Narration pace & breath-cutting rules
- **Total words:** 130 words in 36.47 s = **3.56 words/second (214 WPM)**.
- **Micro-pauses between sentences:** typically **0.08–0.18 s (2–5 frames)**. Longest gap between spoken segments is **0.44 s** (10.72 → 11.16 s, during the 4-layer iceberg reveal in S05, giving the icons room to pop).
- **Rule for preparing a new raw video:**
  1. Run Tight-Cut / Jump-Cut on the raw talking-head track first: strip all dead air, "ums", and breaths > 150 ms so the speech flows at 195–220 WPM.
  2. Apply a vocal compressor + limiter targeting **−14.0 LUFS integrated**, **LRA < 2.5 LU**, **−1.0 dBFS ceiling**.
  3. Because the graphic overlays cover 54% of the video full-screen and 33% in split-screen, **audio jump-cuts are invisible** whenever a full-screen graphic is playing — place full-screen graphics over any seam where two takes were stitched together.

## 3. Cut-to-Word Synchronization Table (every cut lands on a word onset)
Every single shot change in `Video-95754.mp4` is locked to the spoken script within **0 to 3 frames (0–100 ms)** of a word onset, and coincides with a spectral-flux transient in the audio:

| Cut # | Frame | Time (s) | From → To Layout | Exact word spoken at the cut | Word onset (s) | Offset |
|---:|---:|---:|---|---|---:|---:|
| Start | **f1** | 0.00 | `SPLIT` (S01) | "**Anthropic** engineer…" | 0.00 | 0.0 fr |
| 1 | **f54** | 1.77 | `SPLIT → FULL_GFX` (S02) | "…the most **powerful** prompt…" | 1.66 | −3.2 fr |
| 2 | **f122** | 4.04 | `FULL_GFX → FULL_GFX` (S03) | "…but **nobody** is using it." | 4.08 | +1.3 fr |
| 3 | **f176** | 5.84 | `FULL_GFX → SPLIT` (S04) | "When **prompting**, most of us…" | 5.84 | **0.0 fr** |
| 4 | **f246** | 8.17 | `SPLIT → FULL_GFX` (S05) | "Well, **in** fact, we should be…" | 8.22 | +1.4 fr |
| 5 | **f369** | 12.28 | `FULL_GFX → SPEAKER` (S06) | "**For** example," | 12.28 | **0.0 fr** |
| 6 | **f389** | 12.95 | `SPEAKER → FULL_GFX` (S07) | "**instead** of saying to Claude…" | 12.88 | −2.0 fr |
| 7 | **f512** | 17.05 | `FULL_GFX → SPLIT` (S08) | "**Paste** this prompt in…" | 17.02 | −0.9 fr |
| 8 | **f566** | 18.85 | `SPLIT → FULL_GFX` (S09) | "And **that's** why this Anthropic…" | 18.90 | +1.4 fr |
| 9 | **f642** | 21.39 | `FULL_GFX → SPLIT` (S10) | "**Just** paste it in before…" | 21.34 | −1.4 fr |
| 10 | **f704** | 23.46 | `SPLIT → FULL_GFX` (S11) | "and **it** tells you what a top…" | 23.46 | **+0.1 fr** |
| 11 | **f733** | 24.42 | `FULL_GFX → FULL_GFX` (S12) | "…what a **top** expert would say," | 24.36 | −1.9 fr |
| 12 | **f775** | 25.83 | `FULL_GFX → SPLIT` (S13) | "**things** that you would never…" | 25.78 | −1.4 fr |
| 13 | **f848** | 28.26 | `SPLIT → SPEAKER` (S14) | "And **it** doesn't just give you…" | 28.26 | **0.0 fr** |
| 14 | **f883** | 29.43 | `SPEAKER → SPLIT` (S15) | "It **actually** reviews the whole…" | 29.42 | −0.3 fr |
| 15 | **f936** | 31.20 | `SPLIT → FULL_GFX` (S16) | "so **you're** getting the expert…" | 31.24 | +1.3 fr |
| 16 | **f1004** | 33.47 | `FULL_GFX → FULL_GFX` (S17) | "…version of **it.**" | 33.36 | −3.2 fr |
| 17 | **f1012** | 33.73 | `FULL_GFX → SPEAKER` (S18) | "Want **the** prompt? Comment…" | 33.74 | **+0.2 fr** |

## 4. Internal Animation-to-Syllable Sync (inside shots)
Not only do cuts land on word onsets — **internal keyframes inside a shot** are also locked to specific spoken words:
- **f143** ("nobody"): purple highlight rectangle draws around the prompt in S03.
- **f184** ("prompting"): first letter `M` of `Make a slide deck...` types in S04.
- **f231** ("the task."): typing finishes on the exact frame the phrase ends.
- **f309, f322, f335, f348** ("deeper → meaning → behind → the prompt"): the 4 iceberg icons pop on in an even 13-frame pulse train across the back half of the sentence.
- **f411** ("Claude,") & **f419** ("fix this bug,"): fly-swatter slams the screen and cracks appear.
- **f422**: red strike-through crosses out `fix this bug` right as he says it.
- **f483** & **f488** ("bug free."): green highlighter sweeps `bug free`, then the mint shockwave heals the phone and drops the swatter.
- **f523** ("this prompt") → **f531** ("in before"): `⌘V` keys depress → `be-ambitious` card drops in.
- **f589** ("anthropic"): tiny Anthropic `A\` badge stamps onto the cartridge.
- **f601** ("skill is") → **f619** ("so powerful."): cartridge slots in on "skill is", needle hits the red and sunburst rays explode on "so powerful."
- **f715** ("tells you"): stage door swings open into light.
- **f742** ("expert"): professor's speech bubble `Reproduce it first.` pops on.
- **f786** ("that you") → **f815–830** ("never have thought about."): first bulb lights on "that you", full 13-bulb cascade and warm sky shift happen across "never have thought about."
- **f915** & **f925** ("the whole prompt."): red marker underlines `checkout` and circles `so slow?`.
- **f936–944** ("So you're getting"): 3D card flip from index card to `Expert version`.
- **f972–975** ("version"): gold verified seal stamps onto the card and confetti bursts.
- **f1040** ("deeper"): huge serif `“DEEPER"` pops on as the speaker's hands come up for air-quotes.
