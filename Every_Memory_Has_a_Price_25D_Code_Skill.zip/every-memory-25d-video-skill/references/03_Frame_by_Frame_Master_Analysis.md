# 03 — Frame-by-Frame Master Analysis (All 24 Scenes, f0001–f2334 @ 30 FPS)

Every metric below is computed directly from the 2,334 extracted frames of `Every Memory Has a Price.mp4` (`720×1280`, `30.00 fps`, `77.80 s`) and cross-verified by direct inspection of full-resolution keyframes (`assets/reference_keyframes/`), frame-by-frame transition strips (`assets/transition_strips/`), and all 33 contact sheets (`assets/contact_sheets/`).

> **Timestamp formula:** `time_s = (frame - 1) / 30.0` (1-indexed frames `f0001`–`f2334`).

---

## Master Quantitative Telemetry Table (All 24 Scenes)
| Scene | Frames (Time) | Dur | Luma (P05–P95) | Sat / ShSat | Vig | B−R Cast | Sharp (Ctr/Brd) | DOF Ratio | Palette Hex (Sh / Mid / Hi) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| **S01** Hero Intro | `f0001–0031` (`0.00–1.00s`) | 1.03s | 64.8 (`15–180`) | .48 / .55 | .20 | `-2.9` | `1109 / 41` | `39.1×` | `#201930 / #624E56 / #F2E2C9` |
| **S02** Card Macro | `f0032–0053` (`1.03–1.73s`) | 0.73s | 111.6 (`45–180`) | .31 / .50 | .29 | `-13.8` | `566 / 2.5` | **`159.4×`** | `#2B1F35 / #8B727C / #C5C3BC` |
| **S03** Pawn Counter | `f0054–0157` (`1.77–5.20s`) | 3.47s | **38.3** (`12–115`) | .54 / .58 | .41 | `+14.1` | `745 / 43` | `24.7×` | `#1B1731 / #5F4856 / #E8D9C9` |
| **S04** Glass Wipe | `f0158–0168` (`5.23–5.57s`) | 0.37s | 56.5 (`20–125`) | .48 / .59 | .63 | `+20.5` | `528 / 67` | `13.7×` | `#201A3F / #574563 / #D7D0CB` |
| **S05** Rainy Alley | `f0169–0203` (`5.60–6.73s`) | 1.17s | 68.1 (`26–150`) | .54 / .70 | .52 | `+43.3` | `651 / 127` | `5.4×` | `#1B1D58 / #594A82 / #EAD0BE` |
| **S06** Extractor Shop | `f0204–0263` (`6.77–8.73s`) | 2.00s | 109.6 (`44–207`) | .38 / .63 | .52 | `+19.3` | `515 / 88` | `6.0×` | `#2A2453 / #6A5B84 / #EAD2D6` |
| **S07** Deli Street | `f0264–0396` (`8.77–13.17s`) | 4.43s | 81.7 (`25–223`) | .54 / .72 | .45 | `+39.4` | `1049 / 152` | `7.0×` | `#211949 / #4F4886 / #F1D9C1` |
| **S08** Dutch Wall | `f0397–0480` (`13.20–15.97s`) | 2.80s | 77.0 (`27–193`) | .55 / .69 | 1.09 | `+46.9` | `707 / 217` | `3.6×` | `#1D1D52 / #514783 / #F1D1AC` |
| **S09** Rich Pool | `f0481–0564` (`16.00–18.77s`) | 2.80s | 166.6 (`72–226`) | .38 / .54 | 1.02 | `+6.2` | `2175 / 285` | `8.3×` | `#331B1A / #8D9591 / #D4CDB0` |
| **S10** Bahamas Dome | `f0565–0648` (`18.80–21.57s`) | 2.80s | **175.8** (`49–242`) | .37 / .59 | .93 | `+0.8` | `1325 / 662` | `2.0×` | `#341816 / #92807F / #DED8D4` |
| **S11** Couch Pull-Back | `f0649–0720` (`21.60–23.97s`) | 2.40s | 170.3 (`82–221`) | .41 / .58 | .97 | `+42.5` | `1198 / 521` | `14.7×` | `#341815 / #838CA8 / #D7D6C2` |
| **S12** Poor Bench | `f0721–0828` (`24.00–27.57s`) | 3.60s | 86.3 (`28–172`) | .48 / .62 | .71 | `+7.3` | **`2588 / 1400`** | **`2.5×`** | `#281838 / #795572 / #F6B182` |
| **S13** Happiness Gauge | `f0829–0952` (`27.60–31.70s`) | 4.13s | 77.6 (`10–188`) | .47 / .61 | .30 | `-11.6` | `1162 / 159` | `8.6×` | `#15142D / #82675E / #F1D77C` |
| **S14** Night Street | `f0953–1080` (`31.73–35.97s`) | 4.27s | 51.7 (`17–141`) | **.67 / .78** | .41 | **`+58.3`** | `839 / 113` | `13.5×` | `#151B5E / #544684 / #E0C3C3` |
| **S15** Hospital Bed | `f1081–1176` (`36.00–39.17s`) | 3.20s | 78.3 (`16–187`) | .54 / .73 | .30 | `+30.0` | `1067 / 178` | `28.4×` | `#191344 / #635A8D / #E6C5B0` |
| **S16** Golden Lake | `f1177–1272` (`39.20–42.37s`) | 3.20s | 124.7 (`58–214`) | .47 / .51 | .77 | `+35.1` | `1534 / 205` | `8.5×` | `#281D23 / #517285 / #DCCFB6` |
| **S17** IV Pole & Desk | `f1273–1418` (`42.40–47.23s`) | 4.87s | 45.5 (`9–153`) | .62 / .70 | .34 | `+41.8` | `737 / 53` | `20.3×` | `#11112D / #464677 / #DDCFDC` |
| **S18** OPERATING Hall | `f1419–1500` (`47.27–49.97s`) | 2.73s | 123.5 (`35–205`) | .39 / .48 | .81 | `+7.0` | `1193 / 163` | `10.2×` | `#1D1F23 / #7C746F / #CDD4D5` |
| **S19** WE BUY SUMMERS | `f1501–1644` (`50.00–54.77s`) | 4.80s | 71.6 (`23–178`) | .58 / .63 | .39 | `+19.2` | `925 / 133` | `7.1×` | `#191C41 / #4C4F73 / #B6B5F0` |
| **S20** Bed & Ledger | `f1645–1742` (`54.80–58.03s`) | 3.27s | 94.4 (`10–196`) | .45 / .71 | .31 | `+22.6` | `1756 / 374` | `9.7×` | `#12102E / #9E88A2 / #D4C4C2` |
| **S21** Unhooded Shop | `f1743–1901` (`58.07–63.33s`) | 5.30s | 66.8 (`7–230`) | .51 / .64 | .27 | `+11.3` | `1317 / 221` | `6.2×` | `#150F28 / #6C659E / #DED4DB` |
| **S22** Climax Extract | `f1902–1978` (`63.37–65.90s`) | 2.57s | 89.0 (`39–204`) | .47 / .58 | .29 | `-4.3` | `770 / 96` | `39.9×` | `#121331 / #424072 / #F5DEB0` |
| **S23** Morning Ward | `f1979–2142` (`65.93–71.37s`) | 5.47s | 136.6 (`34–221`) | .46 / .67 | .59 | **`-43.1`** | `1455 / 234` | `7.1×` (`280×`v) | `#351834 / #7F5A6C / #E7C694` |
| **S24** Cold Cobalt End | `f2143–2334` (`71.40–77.77s`) | 6.40s | 83.6 (`16–212`) | **.63 / .81** | .34 | **`+47.3`** | `1019 / 229` | `4.6×` (`97×`v) | `#161C5F / #5B4981 / #E4CCA9` |

---

## Detailed Scene-by-Scene Forensic Notes (All 24 Scenes)

### Act 1: HOOK (`0.00–5.20 s`, `f0001–f0157`)
* **S01 — Hero Intro (`f0001–0031`, `0.00–1.00 s`):**
  * **Framing & Camera:** Wide vertical (~24 mm), slightly low angle inside the pawn shop; Jerry standing right-of-center beside the wooden counter, hooded stranger lurking behind the counter left. Static `f1–19`, then smooth push-in `f20–25` (`zoom_div +3.94 px/f`) accelerating into a ~70° whip-pitch down (`f25–35`).
  * **Acting & Micro-Beats:** `f1` Jerry has one brow raised/squinting; `f2–3` **single-eye wink/heavy blink**; `f4–6` half-lid; `f7+` full wide double-ring eyes with worried inward brows and tiny dot mouth. At `f28–30` Jerry's face softly defocuses and **double-exposes/ghosts over the counter** as the camera sweeps past him!
  * **Blur/DOF:** Crisp subject (`sharp_center 1109`), soft background walls (`sharp_border 41`, ratio `39×`).
* **S02 — Glowing Memory Card Macro (`f0032–0053`, `1.03–1.73 s`):**
  * **Framing & Camera:** Macro overhead pitch (`~55°` down) locked on a small silver/gold microchip memory card lying in a counter slot (`f36` settles). At `f47–53`, camera initiates a continuous **pull-up/back** (NOT a dissolve!).
  * **Light Cue:** Memory card's glowing warm core **pulses brighter at `f43–46`** right on the word `"memory"`.
  * **Blur/DOF:** **Highest shallow-DOF isolation in the entire film (`159.4×`)**: `sharp_center = 566` vs `sharp_border = 2.55`! Cash register and counter edges melt into smooth bokeh.
* **S03 — Pawn Shop Counter & Hooded Stranger (`f0054–0157`, `1.77–5.20 s`):**
  * **Framing & Camera:** Continuous pull-back from S02 (`f54–60` vignette closes, exposure drops `130 -> 38`, hooded stranger slides in at left `f55`), then slow pull-back/orbit drift (`dx -0.54, zoom -1.63`) revealing the full wall of glowing memory cubbies on the left and warm amber back-door window on the right.
  * **Acting & Light Cue:** Stranger holds a wide chalk-white toothy grin beneath a navy hood with subtle blue rim; **amber back-door window pulses brighter (`f112–140`, peak `f126–130`)** synced with a tiny sparkle on the counter edge on `"money"`. Darkest scene average (`mean_luma = 38.3`, shadow `#1B1731`).

### Act 2: WORLD (`5.23–15.97 s`, `f0158–f0480`)
* **S04 — Glass Window Pull-Through (`f0158–0168`, `5.23–5.57 s`):**
  * **Camera & 3D Continuity:** Verified directly in `T02` strip: the 3D camera literally **pulls backward through the shop's own glass storefront pane** (`f153–164` visible beveled glass edge sweeps left-to-right across the lens) as Jerry and the interior shrink into a glowing street-level window box labeled `MEMORIES`!
* **S05 — Rainy Neon Alley Dolly (`f0169–0203`, `5.60–6.73 s`):**
  * **Camera & Look:** Smooth dolly along a wet tiled indigo brick alley (`shadow #1B1D58`, `shadow_sat 0.70`, `b-r +43.3`); warm orange city-skyline bokeh stretches across the vanishing point while the `MEMORIES` lightbox slides right. Crisp diagonal **2D rain streaks** fall across frame. Dissolves through rain-spotted glass (`f196–204`) into S06.
* **S06 — Extractor Shop & Bloom Flash (`f0204–0263`, `6.77–8.73 s`):**
  * **Camera & Action:** Slow pull-back inside a teal/checkerboard extraction parlor (`luma 110`). Customer sits blissfully (closed eyes, soft smile) under a silver/lavender extractor helmet while bald assistant stands calmly beside the chair.
  * **Light Cue:** **`f237–250`** a small glowing memory card/jar rises out of the helmet's top tube, triggering a **lavender-white bloom flash (`f238–246`, bloom `4.5%`)** before a `0.2 s` haze dissolve (`f259–264`) into S07.
* **S07 — Deli Street, Landlord & Bike Crash (`f0264–0396`, `8.77–13.17 s`):**
  * **3D/2D Showcase Scene** (recreated in `deli_scene/`): Wide-angle `~76°` vFOV rainy night street (`#211949` shadows, `#4F4886` stucco, `#F1D9C1` Deli window spill, `shadow_sat 0.72`). Smooth wet reflection stretches across the concrete sidewalk.
  * **Camera & Action:** Opens on the angry landlord on the concrete stoop (his arm/legs physically **occluded behind the 3D iron handrail!**) confronting the worried woman; camera trucks right (`f313–324` landlord exits left) and settles low on the bike kid. Kid pedals `f349–372`, wobbles, tilts `f373–376`, and **cartwheels/crashes (`f375–378`)** onto the wet sidewalk while a grey-faced bystander reacts by the window (`f378+`). Diagonal 2D rain throughout.
* **S08 — Dutch-Tilt Wall Climb (`f0397–0480`, `13.20–15.97 s`):**
  * **Camera & Continuity:** Continuous 3D tilt-up from S07 (`f397–432`, you still see the fallen bike kid way down at bottom-left at `f448`!) sweeping past a giant hanging circular-emblem banner and cables into a **~25° Dutch-rolled** towering city wall lined with warm glowing orange sconces under a purple night sky (`b-r +46.9`). Ends with the **T04 downward caustic refraction wipe (`f470–481`)**.

### Act 3: CONTRAST — Rich Side vs Poor Side (`16.00–27.57 s`, `f0481–f0828`)
* **S09 — Rich-Side Pool, Lounger & Butler (`f0481–0564`, `16.00–18.77 s`):**
  * **Look & Camera:** Instant sunlit high-key jump (`luma 166.6`, vignette gone `1.02`, bloom `21.3%`). Water-level forward dolly rising over shimmering cyan caustic pool water (`f481–512`) onto a smug sunhat lounger (wearing sunglasses `f541+`) as a white-jacketed butler leans in with a tray. Crisp deep focus (`sharp_center 2175`). Ends in **white blow-out dissolve (`f557–566`)**.
* **S10 — Bahamas Dome Extraction & Odometer 300 (`f0565–0648`, `18.80–21.57 s`):**
  * **Look & Action:** Brightest scene in the film (`mean_luma 175.8`, `bloom 29.4%`). Inside a sunlit resort room, a brass **copper extractor dome descends on a ceiling pipe (`f577–600`)** onto a Hawaiian-shirt guy wearing a snorkel (eyes blissfully closed, halo at dome rim). Camera tilts down (`f604–612`) onto a brass pedestal odometer labeled `BAHAMAS` whose digits read `0299`, blur-roll (`f616`), and tick past **`300`** (`f617–640`) as the dome ascends (`f640–648`).
* **S11 — Bahamas Couch Pull-Back & Flamingo (`f0649–0720`, `21.60–23.97 s`):**
  * **Camera & Transition:** Pull-back wide revealing the man relaxed on a cream couch with the glowing dome lifting above him and a bright pink flamingo float in the turquoise pool outside (`b-r +42.5`). At `f685–720`, couch dissolves into pool water, then **vertical blurred white-blue light-streak blinds (`f705–720`)** sweep across to dissolve into S12.
* **S12 — Poor-Side Bench & Photo Lift (`f0721–0828`, `24.00–27.57 s`):**
  * **Look & Optical Record:** Dusk violet-mauve palette (`#281838` -> `#F6B182`). **Sharpest deep-focus scene in the entire video (`sharp_all = 1,904.8`, `sharp_center = 2,588`, `sharp_border = 1,400`, `dof_ratio = 2.46×`)!** Every chain-link diamond, brick joint, and red `MEMORIES BOUGHT & SOLD / 555-0142` letter is razor-sharp.
  * **Camera & Acting:** Starts far wide behind foggy vertical light pipes (`f721–780`) and pushes continuously into a two-shot of two elders (curly-grey woman + bald glasses man; 3rd figure exits left). Eyes close serenely (`f790–792`, `f808–822`); at **`f820–828` the woman lifts her framed 2D photo directly up to her face**, triggering the **T06 circular gauge dissolve (`f825–836`)**.

### Act 4: THE MECHANIC (`27.60–31.70 s`, `f0829–f0952`)
* **S13 — Happiness Gauge Gold Flood & `$` Counter (`f0829–0952`, `27.60–31.70 s`):**
  * **Camera & Acting:** Starts tight on the brass `HAPPINESS` gauge and pulls back (`f833–864`) showing the cubby shelves and hooded stranger behind it. **Crucial character beat:** from `f833–875` the stranger is **dark, bored, blank, head drooping**, needle parked low on the rain icon!
  * **Light & Action Climax:** `f866–884` tiny gold sparkles glint upper-right; `f879–893` the stranger's smile creeps into a **full toothy grin**; `f885–900` needle sweeps up to the sun side as the **entire dial floods from silver-white to glowing gold (`#F1D77C`)**; **`f901+` stranger's pupils ignite amber** while the `$` price odometer rolls (`f925–936`). Exits via **circular iris-ring dissolve (`f946–956`)** into S14.

### Act 5: STAKES & WARM MEMORY (`31.73–47.23 s`, `f0953–f1418`)
* **S14 — Night Street, Little Brother & Collapse (`f0953–1080`, `31.73–35.97 s`):**
  * **Look:** Highest global blue shift (`b-r = +58.3`, `mean_sat 0.669`, `shadow_sat 0.778`, `#151B5E`). Night street with overhead pennant lights and wet pavement reflections.
  * **Action & Rack Focus:** Little brother (red shirt, green frog-cap) bounces joyfully toward camera (`f1006–1044`) as a green frog hops onto his cap (`f1025–1044`). At **`f1046–1060`**, frog leaps off, cap tumbles, brother collapses into Jerry's arms (Jerry wide-eyed in alarm); camera increases Dutch tilt and pitches down onto the wet ground where the **frog sits alone (`f1054–1068`)**, followed by **heavy rack-defocus (`f1066–1080`)** blurring the entire street into indigo bokeh while keeping the frog razor-sharp!
* **S15 — Hospital Bed Warm Lamp & Frog (`f1081–1176`, `36.00–39.17 s`):**
  * **Persistent-Object Transition (`f1078–1092`):** Verified in `T07` strip: the exact razor-sharp frog stays pinned at `(50%, 51%)` while the blurred street dissolves into the dark metal hospital bed footboard and blurred room behind, then racks focus onto sick brother (left, dotted gown) and Jerry (right).
  * **Acting & Polaroid Push-In:** Tender closed-eye smiles (`f1093–1128`) -> brother's face droops sad (`f1117–1128` `"he begs"`) -> warm bedside lamp orb glows between them (`f1129–1146`). At `f1153–1176`, camera pushes past Jerry onto the glossy bedside Polaroid (`"the frog! :)"`) with a **diagonal white glare streak (`f1165–1179`)**.
* **S16 — Golden-Hour Lake Polaroid Memory (`f1177–1272`, `39.20–42.37 s`):**
  * **Living Photo Transition (`f1177–1189`):** Verified in `T08` strip: the frozen smiling drawing inside the Polaroid cross-dissolves into animated 2D boys while the white caption border fades away and foreground reeds/lily pads expand into full 9:16 frame!
  * **Look & Action:** Warm golden-hour sun low over calm lake (`luma 124.7`, `#DCCFB6` sky, `#517285` water). Gentle drift (`mean_diff 3.95`, lowest motion outside finale); **frog leaps from left lily pad into the net (`f1201–1237`)** with spray droplets and lands beside the laughing brother (`f1237+`). At `f1264–1275`, lake shrinks back inside the white Polaroid border and dims into S17.
* **S17 — Hospital IV Pole & Lamp-Lit Desk (`f1273–1418`, `42.40–47.23 s`):**
  * **Darkest Emotional Valley (`luma 45.5`, `#11112D`, `vig 0.34`, `dof 20.3×`):** Polaroid clipped onto an IV stand (`BLOOD METER` label `f1278–1282`); camera tilts up as Jerry swings in (`f1281–1288`).
  * **Micro-Acting Masterclass:** Jerry goes wide-eyed (`f1285`) -> deadpan (`f1286–1288`) -> **wavy zig-zag anxious mouth + blue sweat drop at temple (`f1302–1320`)** -> flat dash (`f1321–1324`) -> tiny `"o"` (`f1325`). At `f1326–1336`, **face-position cross-dissolve** shifts corridor face into the dark lamp-lit pawn desk (`f1333–1412`), with the hooded stranger as a **dark foreground silhouette far-left**; tiny glowing card sparkles on desk (`f1343`, `f1385`); Jerry glances sideways/up (`f1355–1368`) and sheds a **single blue tear (`f1399–1405`)**.

### Act 6: ESCALATION (`47.27–58.03 s`, `f1419–f1742`)
* **S18 — Birthday Card & Red OPERATING Corridor (`f1419–1500`, `47.27–49.97 s`):**
  * **Action:** Face-ghost dissolve (`f1412–1418`) onto a maroon birthday card macro atop an olive gauge box (`EMPTY/PAID` plate); camera pulls back (`f1433–1452`) as a **dark round ball-hand swings in from right and presses the box (`f1442–1447`)** and Jerry swings into the teal checkerboard hospital corridor.
  * **Acting & Light Signal:** Sly half-lid (`f1449–1458`) -> eyes-shut sigh (`f1459–1461`) -> wide ring-eyes (`f1462–1476`) -> **serene closed-eye resignation (`f1481–1500`)** as the red `OPERATING` lightbox flares (`f1484–1496`) and **bleeds crimson across the entire teal hall** (`T09` strip).
* **S19 — WE BUY SUMMERS Flicker & Memory-Drain Halo (`f1501–1644`, `50.00–54.77 s`):**
  * **Verified Sign & Props:** Slanted mustard board reading **`WE BUY SUMMERS` / `cash today, any grade`**; Jerry stands in diagonal 2D rain **carrying a stack of memory boxes in his stick arms**.
  * **Measured Light Cycle (Visible as Sine Wave in `analysis_dashboard.png` Panel 2!):** Jerry's face cycles cleanly between **cold lavender-white** and **warm orange** every **~43 frames (`1.43 s`)**: cold `f1513–1524`, warm `f1525–1541`, cold `f1543–1560`, warm `f1561–1572`, cold `f1573–1590`, warm `f1594–1606`, cold+halo `f1607–1626`, warm `f1627–1640`.
  * **Acting & VFX:** Wide ring eyes (`f1513`) -> squint (`f1537`) -> tired closed dash (`f1543–1560`) -> sideways deadpan (`f1561–1572`) -> **head droops back with eyes shut (`f1573–1640`)** while a glowing **blue-white memory-drain halo outline** expands around his head (`f1607–1640`).
* **S20 — Sickbed Hold & Memory Savings Ledger (`f1645–1742`, `54.80–58.03 s`):**
  * **Action & Verified Ledger Correction:** Dissolves to dim blue sickroom (`f1645–1678`, brother sunk deep in pillows, Jerry watching), then dissolves (`f1678–1692`) to a giant worried cold-lit Jerry holding open a ledger with his ball-hand. Camera pushes in (`f1693–1716`) until the crisp 2D **`MEMORY SAVINGS`** page fills frame: `YEAR 2025` through `YEAR 2019` each stamped red **`SOLD`**, **`YEAR 2018 ⭐ 🐸` highlighted shimmering gold** (`f1709–1740`, corrected from earlier v2 note!), and `YEAR 2017`–`2016` stamped `SOLD`. Dissolves upward (`f1737–1748`) into S21.

### Act 7: CLIMAX (`58.07–65.90 s`, `f1743–f1978`)
* **S21 — Stranger Unhooded & Resolute Confrontation (`f1743–1901`, `58.07–63.33 s`):**
  * **3D Continuity Detail:** Shot from **INSIDE the pawn shop looking OUT** — the arched window signage behind the stranger is physically **mirrored backwards (`SEIROMEm / dlos & thguob`)**! Overhead lavender dome lamp + red chair arms in bottom foreground.
  * **Acting Climax:** At **`f1773–1776`, the stranger pulls his hood back**, revealing a plain round white face; camera pushes tight (`f1777–1848`): worried tilted brows, tiny oval mouth, **tremor lines** beside his cheek, and a **one-eye wink/flinch (`f1840–1846`)**. Camera pulls back (`f1849–1872`): Jerry calm (blink `f1861–1863`), then **resolute (`f1889–1900`, brows angled down, half-lids)** while stranger squeezes eyes shut sadly (`f1890–1894`) -> wide shocked ring-eyes (`f1897+`).
* **S22 — Dome Descent, Backlit Memory Chip & Gold Blow-Out (`f1902–1978`, `63.37–65.90 s`):**
  * **Verified Frame-by-Frame in `T10` Strip:** Lavender extractor dome descends onto Jerry (`f1902–1920`); camera whips rapidly up the vertical tube (`mean_dy +5.4 px/f`, peak `diff 36.7`, fastest camera velocity in the film!).
  * **Verified Visual Correction:** At `f1931–1956`, a **physical 3D backlit memory chip card (`MC-4-2018`, gold contacts left, glowing golden square core)** rises out of the tube into dark indigo space in front of the backlit cubby grid & mirrored shop window (`SEIROMEm` + blue `23`), then its golden core **blooms outward into a full-frame gold-white blow-out (`f1957–1976`, peak `f1969–1973`, `luma 193`, `bloom 12%`)** before dissolving into S23 (`f1976–1992`).

### Act 8: TWIST & FREEZE HOLD (`65.93–77.77 s`, `f1979–f2334`)
* **S23 — Morning Ward Healed Brother Awakening (`f1979–2142`, `65.93–71.37 s`):**
  * **Look & Extreme Vertical DOF:** Warmest scene in the entire film (**`b-r = -43.1`**, `luma 136.6`, plum shadows `#351834`, honey highlights `#E7C694`). Background wall of get-well drawings & royal-blue windows is **heavily Gaussian-blurred (`sharp_top = 4.27` vs `sharp_bot = 1,125.5` -> `dof_vert_ratio = 280.4×`!)** while the 2D brother on the red bedspread is razor-sharp!
  * **Hair & Acting Arc:** Brother lies tiny with **limp flat hair (`f1979–2005`)** -> eyes open (`f2001–2004`) -> sits up (`f2005–2016`) and **hair springs up into joyful spikes (`f2008–2012`)** -> beaming toothy grin (`f2009–2028`) -> arms raised behind head (`f2029–2043` `"cured"`) -> hand on hip + wink (`f2044–2048`) -> talking with Polaroid (`f2049–2088`) -> excited `"O"` mouth asking (`f2097–2112`) -> **affectionate squeezed-x smile (`f2116–2130`)** leaning forward (`f2130–2136`).
* **S24 — Cold Cobalt Hollow Jerry & Final 30-Frame Freeze (`f2143–2334`, `71.40–77.77 s`):**
  * **Instant 6-Frame Emotional Inversion (`T11` strip `f2137–2142`):** Brother's warm cream face ghosts directly into Jerry's face at the identical screen center as color temperature flips instantaneously from **`b-r = -43.1` (warm cream)** to **`b-r = +47.3` (deep cold cobalt, `shadow_sat = 0.807` — highest shadow saturation in the entire film!)**.
  * **The Devastating Eye-Design Reveal:** Jerry starts with ring-eyes + **wavy confused mouth (`f2145–2150`)** -> flat dash blinks (`f2154–2158`, `f2173–2175`) -> faint smile (`f2177–2189`). A ball-hand + Polaroid enters from the left (`f2192–2208`). At **`f2203`, Jerry's double-ring eyes permanently collapse into SIMPLE EMPTY BLACK DOTS** (alive = ring eyes; hollow/erased = dot eyes!).
  * **Final Pan & Motionless Hold:** Camera pans/dollies smoothly so hollow Jerry slides right and tiny warm brother appears bottom-left (`f2209–2232`) holding the Polaroid -> brother rests cheek on hand (`f2233–2250`) -> eyes turn squiggly/confused (`f2257–2284`) -> **sad, hurt frown with tilted brows (`f2285–2334`)** as Jerry stares blankly past him under faint diagonal window light shafts (`f2265+`). Final 30 frames (`f2305–2334`, `1.00 s`) hold completely frozen (`36` duplicate frame pairs detected in S24) over `"single one."` / `"one."` — never cutting away!
