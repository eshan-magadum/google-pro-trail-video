# 10 — The "Single-Frame Detail Standard" for Full 60-Second Videos (Mandatory Protocol)

**The Golden Rule of Skill v2.0:**
> **Every single scene in a 60-second video MUST be engineered, dressed, lit, and audited with the exact same obsessive detail density as a standalone 1-frame masterpiece (`deli_scene` / `zombie_plane_scene` / `Samurai f384`).**

If an AI builds a 60-second video by squeezing 4+ locations into one monolithic file, visual quality collapses (`edge_pct` drops from `15–19%` down to `8%`). Follow every rule below without exception.

---

## 1. Modular Per-World Architecture (Ban Monolithic Multi-World Files!)
Never write all locations inside a single `scene.js`. Every distinct location MUST have its own dedicated ES module (`>= 250 lines`) with its own custom PBR textures:
```text
project/
  worlds/
    world_01_hangar.js       # >= 15 bespoke 3D props, >= 6 PBR textures, foreground occluders
    world_02_sky_deck.js     # Painted cloud skybox, distant terrain/horizon, layered 3D clouds
    world_03_cutaway.js      # High-detail 3D hero cutaway staged INSIDE the live 3D environment
    world_04_finale.js       # Fully dressed climax set (crowd, foliage, signage, warm sunset)
  rigs/
    characters_25d.js        # Multi-angle rigs (front, 3/4, back-of-head, crouch, lean, sit)
  fx/
    particles_and_vfx.js     # Streak sparks, flickering flames, smoke columns, ground cracks
  timeline.js                # 16–22 visual beats per 60 s (1 fresh angle/action every 2.0–3.5 s)
```

---

## 2. Mandatory Per-Scene Prop & Micro-Detail Budget
Fill `templates/scene_detail_budget_checklist.csv` for **every location** BEFORE coding. A scene is **NOT** ready to render until it satisfies ALL 7 minimums:

1. **Painted Atmospheric Sky / Horizon (ZERO Flat Solid Backgrounds):**
   - Outdoor sets MUST use `makePaintedCloudSkyDome()` (`starter_code/engine/environment_helpers.js`) with layered wispy clouds, horizon atmospheric haze, distant hills/buildings/trees, and a glowing sun/moon — **NEVER** a plain single-color `scene.background`!
   - Even cutaway / explainer scenes MUST keep a richly dressed 3D environment behind the hero prop (exact lesson from *Samurai* `f1392` spool cutaway inside the grass-and-banner camp!).
2. **Textured Ground / Floor With Micro-Storytelling (`>= 3` surface layers):**
   - Outdoor ground: rutted dirt/asphalt PBR + instanced grass tufts (`scatterInstancedGrassTufts()`) + rocks/cracks/puddles/fallen debris!
   - Indoor floor: wood planks / concrete slabs + patterned rugs (`makeOrnamentalRugTexture()`) or painted hazard lines + floor clutter (sandals, dropped tools, cans, safety cards, crates)!
3. **Hero Architecture + Wall Dressing (`>= 12` non-primitive props per room):**
   - Walls MUST NEVER be bare corrugated boxes. Dress walls & corners with shelving, weapon/gear racks, hanging cables, conduits, framed signs, glowing clocks, open doorways looking outside, stacked crates, barrels, vases, lamps, and rafters!
4. **Foreground Depth Occluders (`>= 2` per wide shot):**
   - Every wide or medium shot MUST place real 3D geometry between the camera and characters (table corners, hanging lamps/masks, railing posts, overturned carts, grass blades, weapon racks, doorways) to guarantee authentic 3D parallax!
5. **Warm-vs-Cool Lighting Balance (NO Monochromatic Blue Washing!):**
   - **Nocturnal Horror / Indigo Gloom (`Every Memory` mode):** Lifted indigo shadows (`P05 B > 18`), balanced with warm amber practical pools (`#FFC878`) and red/crimson story accents.
   - **Warm Interior / Daylight / Campfire / Historical (`Samurai` mode):** Natural warm twilight/charcoal shadows (`P05 RGB ~(28-36, 24-32, 32-42)`) paired with strong golden/orange practical lights (`warmth R-B` reaching **`+15 to +40`** in warm scenes!).
   - Every scene must include **at least 1–2 visible HDR practical light sources** (hanging lamps, campfires, lanterns, glowing gauges, moon/sun, sparks) so `bloom_pct` sits in **`0.3%–4.0%`** across the whole video.
6. **Multi-Angle 2.5D Character Craft & Layered Costumes:**
   - Every main character rig MUST support at least **4 body orientations/postures** (front, 3/4 lean, back-of-head turn, crouching/ducking/action pose) and **physical 3D prop interaction** (holding glowing tools, weapons, spheres, ropes — never floating detached!).
   - Costumes MUST include crisp 2D surface detailing (stitching, lamellar plates, straps, collars, pockets, emblems, varied hats/hair silhouettes) and grounded floor contact shadows under BOTH feet!
7. **High-Frequency Visual Beats (`16–22` beats per 60 s):**
   - Change camera angle, physical staging, prop reveal, or character acting beat every **`2.0–3.5 seconds`** (`median frame_diff >= 4.0`). Never hold an empty slow pan for 5+ seconds.

---

## 3. Mandatory Stage 4B: Full-Resolution Single-Frame Per-Scene Gate
**NEVER judge scene quality from a tiny `4×4` thumbnail contact sheet!**
Before rendering full video chunks:
1. Render **ONE FULL-RESOLUTION (`720×1280` or `1080×1920`) PNG** for **every single scene** (`scene_01.png` .. `scene_N.png`).
2. Inspect **EACH full-resolution PNG individually** via `view_file` and verify:
   - Does this frame look like a standalone 10/10 art piece even without motion?
   - Are there ANY bare walls, empty background voids, ungrounded floating props, or stiff front-facing clones?
3. Run `verify_video.py --audit-frame scene_XX.png` on every scene keyframe and require:
   - **Detail Edge Density `edge_pct >= 12.0%`** (target `14–20%`, matching *Samurai* `15.1%` & *Every Memory* `19.2%`!)
   - **Edge Gradient Mean `edge_mean >= 11.5`**
   - **Warmth & Lighting Match** (warm scenes MUST actually measure warm `R - B > 0`, not blue!)
4. Fix every scene that fails BEFORE launching the full 30-FPS chunk render!
