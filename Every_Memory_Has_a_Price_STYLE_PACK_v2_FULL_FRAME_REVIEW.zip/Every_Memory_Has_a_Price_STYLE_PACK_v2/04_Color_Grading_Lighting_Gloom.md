# 04 — COLOR GRADING, LIGHTING, SHADOWS, GRADIENTS, SATURATION, "GLOOMY FEEL"
All colours are k-means cluster centres sampled from the real frames (per scene, 12 frames each). Full palettes for all 24 scenes are in `data/scene_analysis.json`.

## 1. Global grade = "indigo shadows / peach highlights / cream-gold hope"
| Zone | Dark-night scenes | Bright scenes | Whole film |
|---|---|---|---|
| Shadows (darkest 10 %) | `#0F0D25` (R16 G13 B38) — crushed, blue-biased | `#3B373C` — lifted, neutral | `#1D192F` |
| Midtones | `#40385C` violet-slate | `#9DA4A4` cool teal-grey | `#5F5A75` |
| Highlights (top 5 %) | `#D9C5BE` warm peach-pink | `#F2EAD8` warm cream | `#E0D1C8` |

* **Black point is lifted, not zero** — average 1st-percentile luma = 17/255, and it is *indigo*, so blacks feel like deep water, not a void.
* **White point** — average 99th-percentile ≈ 224; only the flares and the pool blow to 250+.
* Lab a/b mean +12 / −13 → whole film leans **magenta-blue**; skin and wood bring the warmth back.
* Overall mean luma 93/255 (36 % key) = **low-key**; but the film oscillates between 18 and 200 luma, so **contrast between scenes** is as important as contrast inside them.

## 2. Saturation behaviour (important, counter-intuitive)
* Gloomy scenes are *more* saturated than bright scenes: night street 0.66, hospital desk 0.63 vs. pool 0.34, couch 0.42.
* Reason: bright scenes are bleached by bloom/white clipping; dark scenes keep deep, rich blue-violet. **Never desaturate to make it gloomy.** Keep deep blue saturated, kill brightness.
* Skin/hair stay clean: orange hair `#D9532A`-range, peach faces; characters are the most colour-controlled elements in the frame.

## 3. Gradients (every backdrop is a smooth gradient, no flat fills)
| Scene | Gradient |
|---|---|
| S03 shop | near-black navy `#0F0D21` edges → plum `#342946` → amber counter pool `#B17B62` |
| S05 alley | indigo `#1D1845` → electric blue `#1E2A80` → lavender `#524A98`, warm bokeh lights at far end |
| S06 extractor shop | radial lavender-pink haze `#8F708C → #ECD4D2` around the lamp (white-hot centre) |
| S08 wall | violet `#2F3482` sky with orange `#F2D5B3` lamp spill and white light shafts |
| S10 resort | **radial halo**: near-white `#EEEBEB` behind the head → cobalt `#4D7CEC` toward edges |
| S14 street | vertical cobalt `#152075` → indigo `#151440` with mirrored reflections |
| S16 lake | sunset: amber horizon → sky `#4382B1`; water `#1D537B` mirrors it |
| S23 recovery | cream-honey `#F7D99F` centre → **royal blue** `#3A448E` left/right edges, red bedspread `#8D1E1E` low |
| S24 end | cobalt `#20329B` → near-black `#17183B`; warm `#DDBE95` only on the brother |

## 4. Lighting design
**Gloom scenes**
* **Cool ambient fill** from above/behind (blue-violet), with a thin pale-blue **rim line** on hood/hair edges (e.g. stranger's hood rim at 0.5 s).
* **Warm practicals** as the only warm sources: amber door windows, desk lamp pool, memory-card glow (`#B58955` cluster), red/orange "OPERATING" lamp.
* **Face as lantern** (S17): the character's face is lit from below by the desk lamp → face is the brightest object (white-peach), the rest sinks to black. Edge of face falls to lavender.
* **Pendant lamp bloom**: soft halo ~15 % of frame around bulbs, teal/green shade in S01.
* **Volumetric light**: god-rays in S08, light cone from desk lamp in S17.
* **Rain and wet surfaces** double every light into a streak (S05, S07, S14).

**Bright scenes**
* **Overexposed daylight**: blown sky (`#8FBEEC`), clipped whites (46 % of S10 pixels >235), caustic pool patterns, heavy bloom. Looks like a luxury ad — deliberately sterile.

**Hope/warm scene (S23)**
* Soft frontal window light, honey-gold, with blue cold spill on the frame edges and heavy background blur.

## 5. Shadows
* **Colour**: indigo `#0F0D25`; shadows on the counter are deep violet, never black-grey.
* **Hard cast shadows**: diagonal razor-edge shadow band across the counter (S01/S03) from the glass partition — graphic and cinematic.
* **Soft contact shadows**: dark blobs under feet/chairs (S12).
* **Ambient occlusion**: corners of rooms and cubby-hole fronts go to near-black (the cubby wall's shelves are black with tiny glowing cards).
* **Characters** are *not* self-shadowed with realistic modelling — instead they get a **tint overlay** (cool lavender on the shadow side, warm peach on the key side) and an occasional rim.
* Shadow density by class: dark-night scenes have 36–69 % of pixels below luma 40; bright scenes 2–4 %.

## 6. Depth & blur
* Atmospheric perspective: distant elements (far alley, wall top) are hazier, bluer and lower contrast.
* Sharpness (Laplacian variance, higher = crisper): night scenes 180–260 (**soft, hazy**), most scenes 350–550, bench scene S12 ≈ 2,000 (hyper-detailed chain-link and crack lines), rich side S09–S11 ≈ 800–1,000 (digital-clean).
* Shallow DOF in S02, S23, S24 with creamy bokeh; deep focus in rich scenes.

## 7. Bloom / halation / vignette
* **Bloom**: bright-pass blur (σ ≈ 22–30 px at 1080 p) screen-blended at 25–55 %; makes lamps, cards and sky glow.
* **Vignette**: strong in gloom — corners are only **21–36 %** of centre brightness; none in bright scenes (0.91–0.99).
* **Halo around heads** in S19 (54 s) when memories drain: head turns lavender-white with a glowing outline.

## 8. THE GLOOM RECIPE (checklist)
1. Shadows deep indigo, lifted black (RGB ≈ 16/13/38); never pure black.
2. Keep blue saturated (HSV sat 0.55–0.69).
3. One or two tiny warm light sources per frame.
4. Strong vignette (corner ≈ 30 % of centre).
5. Rain/wet reflections/haze; far distance goes lavender.
6. Faces glow (lit from below or by a glowing prop).
7. Slow push-ins, long holds; no shake.
8. Bright "fake paradise" scenes in between to make the dark hurt more.
9. Clean image — no grain, no dirt overlay.
10. Reserve gold for memories; save the only warm cream scene for the cure.

## 9. Ready-to-use grade
Run `grade.sh` (included): `./grade.sh in.mp4 out.mp4 gloom|bright|warm`. Validated on reference-derived clips (see `data/grade_script_validation.txt`): bright preset matched the target within ~1 % luma, warm within ~3 %, gloom matches luma and contrast but runs slightly more saturated (0.69) than the mid-night reference (0.55) — which is right for the deep-night scenes (0.63–0.66). In DaVinci/Premiere: lift Shadows to (16,13,38), Gain highlights toward (217,198,191), Saturation 100–115 % on dark scenes, add Glow/Bloom at 25–40 %, Vignette −60 to −70 %.

## 10. v2 ADDITIONS — light as a story signal (found by viewing every frame)
| Frames | Effect | How to reproduce |
|---|---|---|
| f43–46 | Memory-card glow pulses once | Animate the card's emissive 100 % → 140 % → 100 % over 0.4 s |
| f112–140 | Amber door window pulses brighter, counter sparkle | Window glow +40 % ramp over 0.5 s, hold, release |
| f237–250 | Extraction bloom flash, frame goes pale lavender-white | Add radial white-lavender bloom 0 → 70 % opacity in 0.3 s, fall over 0.4 s |
| f557–566 | White blow-out between resort and window room | Exposure +4 stops cross-dissolve |
| f893–900 | Gauge dial floods from silver-white to gold | Colour-shift dial `#D9D9DE` → `#F2C94C` in 0.25 s + glow |
| f1484–1498 | OPERATING sign lights red and a red cast bleeds over the whole teal corridor | Red `#FF3B30` Screen overlay at 25–35 % with a radial falloff centred on the sign |
| f1513–1640 | Skin tone cycles cold lavender-white ⇄ warm orange every ~1.45 s, then a blue-white halo around the head | Keyframe skin tint between `#C9C3F0` and `#F2A25A`, period 1.45 s; add 6–10 px outer glow `#BFD4FF` from f1607 |
| f1957–1976 | Gold-white blow-out | Radial gold `#FFE9A8` to full-frame Add, peak at f1969–1973, then cross-dissolve |
| f2137–2143 | Cold flip: warm cream → cobalt in 0.2 s | Colour-temperature −4000 K cross-dissolve + background `#2038B8` |
| f2265–2334 | Faint diagonal window light shafts at the top | Two soft white 5–8 % opacity diagonal gradients |
