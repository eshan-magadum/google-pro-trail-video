import cv2, numpy as np, glob, json, os
files = sorted(glob.glob('frames/f_*.jpg'))
N = len(files)
rows = []
prev_gray = None
prev_small = None
prev_hist = None
for i, f in enumerate(files):
    img = cv2.imread(f)
    h, w = img.shape[:2]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    b, g, r = [img[..., k].astype(np.float32) for k in range(3)]
    L = lab[..., 0].astype(np.float32) * 100/255
    A = lab[..., 1].astype(np.float32) - 128
    B = lab[..., 2].astype(np.float32) - 128
    S = hsv[..., 1].astype(np.float32)/255
    V = hsv[..., 2].astype(np.float32)/255
    Hh = hsv[..., 0].astype(np.float32)*2  # 0..360
    lap = cv2.Laplacian(gray, cv2.CV_64F).var()
    # region luma: top / mid / bottom thirds, center vs edge (vignette)
    t, m, bt = gray[:h//3].mean(), gray[h//3:2*h//3].mean(), gray[2*h//3:].mean()
    cy0, cy1, cx0, cx1 = h//4, 3*h//4, w//4, 3*w//4
    center = gray[cy0:cy1, cx0:cx1].mean()
    mask = np.ones_like(gray, bool); mask[cy0:cy1, cx0:cx1] = False
    edge = gray[mask].mean()
    # corners (vignette)
    cs = 80
    corners = np.mean([gray[:cs,:cs].mean(), gray[:cs,-cs:].mean(), gray[-cs:,:cs].mean(), gray[-cs:,-cs:].mean()])
    # motion / change
    small = cv2.resize(gray, (90, 160)).astype(np.float32)
    diff = float(np.abs(small - prev_small).mean()) if prev_small is not None else 0.0
    hist = cv2.calcHist([hsv], [0,1], None, [18,8], [0,180,0,256]); hist = cv2.normalize(hist, hist).flatten()
    hdist = float(cv2.compareHist(prev_hist.astype(np.float32), hist.astype(np.float32), cv2.HISTCMP_BHATTACHARYYA)) if prev_hist is not None else 0.0
    # optical flow (global translation + zoom proxy)
    flow_mag = fx = fy = div = 0.0
    if prev_gray is not None:
        pg = cv2.resize(prev_gray, (180, 320)); cg = cv2.resize(gray, (180, 320))
        flow = cv2.calcOpticalFlowFarneback(pg, cg, None, 0.5, 3, 15, 3, 5, 1.2, 0)
        flow_mag = float(np.linalg.norm(flow, axis=2).mean())
        fx, fy = float(flow[...,0].mean()), float(flow[...,1].mean())
        # divergence from center = zoom proxy
        yy, xx = np.mgrid[0:320, 0:180]
        rx, ry = xx - 90, yy - 160
        rn = np.sqrt(rx**2 + ry**2) + 1e-6
        div = float(((flow[...,0]*rx + flow[...,1]*ry)/rn).mean())
    # dominant hue among saturated pixels
    sat_mask = (S > 0.2) & (V > 0.15)
    dom_hue = float(np.median(Hh[sat_mask])) if sat_mask.sum() > 200 else -1
    rows.append(dict(
        f=i+1, t=round(i/30, 3),
        luma=float(gray.mean()), luma_std=float(gray.std()),
        p1=float(np.percentile(gray,1)), p5=float(np.percentile(gray,5)), p50=float(np.percentile(gray,50)),
        p95=float(np.percentile(gray,95)), p99=float(np.percentile(gray,99)),
        dark_frac=float((gray<40).mean()), bright_frac=float((gray>200).mean()),
        R=float(r.mean()), G=float(g.mean()), B=float(b.mean()),
        sat=float(S.mean()), sat_p95=float(np.percentile(S,95)), val=float(V.mean()),
        lab_a=float(A.mean()), lab_b=float(B.mean()),
        lap=float(lap), top=float(t), mid=float(m), bot=float(bt),
        center=float(center), edge=float(edge), corners=float(corners),
        diff=diff, hdist=hdist, flow=flow_mag, fx=fx, fy=fy, div=div, dom_hue=dom_hue,
    ))
    prev_gray, prev_small, prev_hist = gray, small, hist
    if (i+1) % 400 == 0: print('done', i+1, flush=True)
json.dump(rows, open('metrics.json','w'))
print('total', len(rows))
