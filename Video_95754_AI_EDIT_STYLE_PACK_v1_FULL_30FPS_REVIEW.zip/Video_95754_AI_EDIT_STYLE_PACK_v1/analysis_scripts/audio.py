"""Audio measurement: per-frame RMS (dBFS), spectral centroid, onset strength; check for music bed / SFX at cuts."""
import numpy as np, wave, json, csv
w = wave.open("/tmp/v95/audio48k.wav"); sr = w.getframerate(); ch = w.getnchannels()
x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
x = x.reshape(-1, ch); L, R = x[:, 0], x[:, 1]; m = x.mean(1)
FPS = 29.97; hop = int(sr / FPS); rows = []
prev_spec = None
for i in range(int(len(m) / hop)):
    seg = m[i*hop:(i+1)*hop]
    if len(seg) < hop: break
    rms = np.sqrt((seg**2).mean()) + 1e-9
    spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))); f = np.fft.rfftfreq(len(seg), 1/sr)
    cent = (spec * f).sum() / (spec.sum() + 1e-9)
    low = spec[f < 150].sum() / (spec.sum() + 1e-9); high = spec[f > 6000].sum() / (spec.sum() + 1e-9)
    flux = float(np.maximum(spec - prev_spec, 0).sum()) if prev_spec is not None else 0.0
    prev_spec = spec
    rows.append(dict(frame=i+1, t=round(i/FPS, 3), rms_dbfs=round(float(20*np.log10(rms)), 1), centroid_hz=int(float(cent)),
                     low_ratio=round(float(low), 3), high_ratio=round(float(high), 3), flux=round(flux, 2)))
with open("/tmp/v95/data/audio_per_frame.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, rows[0].keys()); wr.writeheader(); wr.writerows(rows)
db = np.array([r["rms_dbfs"] for r in rows])
side = (L - R); stereo_width = float(np.sqrt((side**2).mean()) / (np.sqrt((m**2).mean()) + 1e-9))
summary = dict(sr=sr, channels=ch, peak_dbfs=round(float(20*np.log10(np.abs(x).max()+1e-9)), 2),
               integrated_rms_dbfs=round(float(20*np.log10(np.sqrt((m**2).mean()))), 1),
               p10_frame_db=float(np.percentile(db, 10)), p50_frame_db=float(np.percentile(db, 50)), p90_frame_db=float(np.percentile(db, 90)),
               quietest_frames=[rows[int(k)] for k in np.argsort(db)[:8]], side_to_mid_ratio=round(stereo_width, 4))
json.dump(summary, open("/tmp/v95/data/audio_summary.json", "w"), indent=1)
print(json.dumps({k: v for k, v in summary.items() if k != "quietest_frames"}, indent=1))
print("quietest", [(r["frame"], r["rms_dbfs"]) for r in summary["quietest_frames"]])
cuts = [54,122,176,246,369,389,512,566,642,704,733,775,848,883,936,1004,1012]
for c in cuts:
    win = rows[c-4:c+4]; print(c, [r["rms_dbfs"] for r in win], [int(r["flux"]) for r in win])
