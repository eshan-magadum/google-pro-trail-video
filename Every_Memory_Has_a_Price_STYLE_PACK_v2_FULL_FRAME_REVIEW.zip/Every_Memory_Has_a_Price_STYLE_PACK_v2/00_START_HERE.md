# EVERY MEMORY HAS A PRICE — STYLE & PRODUCTION PACK  (v2 — FULL FRAME-BY-FRAME REVIEW)
Analysis of `Every_Memory_Has_a_Price.mp4` (77.8 s · 720×1280 · 30 fps · 2,334 frames · 24 scenes), built so GPT-6.2 Astra (plus an image and a video generator) can recreate the same look and feeling.

## Read in this order
| File | What it covers |
|---|---|
| `01_Master_Style_Bible.md` | Technical fingerprint, the 8 style pillars, measured look numbers, and the extra points you didn't list |
| `02_Shot_By_Shot_Breakdown.md` | All 24 scenes: frames, camera, lighting, shadows, depth, characters, expression, transitions, measured stats and palettes |
| `03_Camera_Motion_and_Transitions.md` | Motion statistics, the 11 transition techniques, the camera move for every scene |
| `04_Color_Grading_Lighting_Gloom.md` | Grade, saturation, gradients, shadows, depth/blur, bloom, vignette, the **gloom recipe** |
| `05_Characters_and_Expressions.md` | Character construction, the cast, expression timelines |
| `06_Captions_Pacing_Audio.md` | Caption spec, narration pace, story beats, audio measurements and mix targets |
| `07_Astra_Master_Prompts.md` | **Copy-paste prompts for Astra** (director brief, style lock, character lock, negatives, motion, QA) |
| `08_Per_Shot_Prompts.md` | Image prompt + motion prompt + grade for each of the 24 scenes |
| `09_Production_Workflow.md` | Step-by-step pipeline, consistency tricks, export presets, QA checklist |
| `grade.sh` | ffmpeg finishing grade (gloom / bright / warm), validated against the reference |
| `10_Frame_Accurate_Event_Log.md` | **NEW v2:** everything found by viewing all 2,334 frames in order, by frame number |
| `11_What_Changed_v1_to_v2.md` | **NEW v2:** v1 mistakes corrected + the new discoveries |
| `data/` | **Per-frame metrics for all 2,334 frames (CSV)**, scene analysis JSON, timeline chart, caption timing, grade validation |
| `reference_frames/` | One key frame per scene (give these to Astra as images) |
| `sheets/` | `all_2334_frames_in_order/` (33 sheets, every frame labelled) + earlier overview and transition sheets |
| `analysis_scripts/` | The Python used, so the analysis can be re-run |

## How the analysis was done (honest account)
* **v2:** I extracted all 2,334 frames and **viewed every one of them, in order, in 33 contact sheets of 72 frames each** (each tile labelled with its frame number). I wrote notes as I went (`10_Frame_Accurate_Event_Log.md`) and then rebuilt the scene boundaries, transitions and expression notes from them. v1 had only ~300 frames viewed.
* **Resolution limit:** each frame was seen at **100 × 178 px**, plus the higher-resolution frames I viewed earlier (≈ 300). Whole-frame events, motion, lighting, props, scene structure and major expressions are solid; extremely subtle details (tiny brow shifts, small background text) can still be missed.
* **All 2,334 frames were also measured by code** (brightness, colour, saturation, sharpness, vignette, bloom, optical-flow motion) → `data/per_frame_metrics_all_2334_frames.csv`; per-scene stats were recomputed on the corrected frame boundaries.
* **Audio was measured, not listened to** (loudness, spectrum).
* **Captions** were read with OCR for timing; the story beats here are my own paraphrase, not a transcript.
* Colour hex values are k-means cluster centres from the actual frames. Descriptions marked *(observed)* are visual judgement, not measurements.

## The 16 things that make it look and feel like this
1. 2.5D: flat black-outlined stick-figure characters inside lit 3D dioramas.
2. **No hard cuts at all** — 11 kinds of camera-driven transition, 0.25–2 s each.
3. Gloom = **saturated indigo** shadows (#0F0D25), lifted blacks, not grey and not desaturated.
4. Tiny warm lights (amber windows, lamp pools, gold cards) as the only hope in the dark.
5. Strong vignette in gloom (corners ≈ 30 % of centre), none in bright scenes.
6. False-cheerful, blown-out tropical scenes inserted to make the dark hurt more.
7. Gold = memory/value on every memory object; the film's biggest flash is the gold flare at 65 s.
8. Faces lit like lanterns in the darkest scene.
9. Rain + wet reflections for the poor side; caustics + clean gloss for the rich side.
10. Slow holds, brief fast eased bursts, no shake, no grain, last second frozen.
11. Narration ≈ 2.8 words/s, captions 1–2 words (≈ 0.33 s each) at 70 % frame height, white with heavy black outline.
12. The ending's punchline is **light**: warm on the cured brother, cold on the hero who lost the memory.
13. **Transitions hold a prop or a face steady** (frog, polaroid, dial ring, face-position dissolves) — 24 of them, none a hard cut.
14. **Eyes and hair are an emotion code**: ring-eyes = alive, dot-eyes = hollow, limp hair = sick, spiky = healed.
15. **Light is a signal**: amber pulse, gold flood, red bleed, pulsing skin tone, gold blow-out, cold flip.
16. **One repeating machine** (the extraction dome) escalates three times to the pixel-mosaic gold blow-out.

## How to use with GPT-6.2 Astra
1. Upload `reference_frames/*.jpg` + `sheets/overview_*.jpg` + `data/timeline_all_2334_frames.png`.
2. Paste **PROMPT 1** from `07_Astra_Master_Prompts.md`; let Astra write the script/shot list. Then paste PROMPT 3 (characters) and generate the character sheet.
3. For each of the 24 shots use PROMPT 2 + the image prompt from `08_Per_Shot_Prompts.md`; animate with PROMPT 5 + the motion prompt; finish with `grade.sh`; assemble per `09_Production_Workflow.md`.
* Third-party guides say Astra plans and writes prompts but **doesn't render video itself**, so you'll need an image-to-video tool for the moving shots. Check your account in case that's changed.

## One important note
This pack captures the *craft* — look, light, camera, pacing — of the reference. The characters, story and script belong to the original creator. For a video you can publish safely (and that YouTube won't treat as reused content), use PROMPT 1 to build an **original story and original characters** in this style, and use the reference's design only as a private guide.
