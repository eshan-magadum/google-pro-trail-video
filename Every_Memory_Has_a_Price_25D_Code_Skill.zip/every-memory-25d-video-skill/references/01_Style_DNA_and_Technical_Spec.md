# 01 — Style DNA & Technical Specification

All quantitative metrics below were measured directly across **all 2,334 frames (30.00 fps, 77.80 s)** and the **44.1 kHz stereo audio stream** of `Every Memory Has a Price.mp4` (raw tables in `data/frame_metrics_30fps_2334.csv`, `data/audio_envelope_30fps.csv`, and `data/scene_summary_24_scenes.json`).

---

## 1. Container & Delivery Fingerprint
| Property | Reference Video (Measured) | Recommended Master Output |
|---|---|---|
| Resolution & Aspect | `720 × 1280` (9:16 vertical, SAR 1:1) | `1080 × 1920` (9:16 master) or `720 × 1280` (fast draft) |
| Frame Rate | `30.00 fps` constant (`r_frame_rate = avg_frame_rate = 30/1`) | `30.00 fps` constant, animated smoothly on ones |
| Codec & Color | H.264 Main L3.1, `yuv420p`, `bt709` (TV range), progressive | H.264 High/Main, CRF 14–16, `yuv420p`, `bt709`, `+faststart` |
| Duration & Frames | `77.80 s` video (`2,334` frames) / `77.89 s` audio | Match transcript at `2.8–2.9 wps` + `1.0 s` (30 f) freeze hold |
| Audio Spec | AAC-LC 44.1 kHz stereo, 128 kbps | AAC-LC 44.1/48 kHz stereo, 128–192 kbps |
| Integrated Loudness | **`-14.1 LUFS`** | **`-14.0 LUFS` (±0.5 LU)** |
| Loudness Range (LRA) | **`1.9 LU`** (`-15.0` to `-13.0 LUFS`, tightly compressed) | **`1.8–2.5 LU`** |
| True Peak | **`-2.0 dBFS`** | **`<= -1.5 dBTP`** |
| Duplicate Frame Pairs | `57 / 2,333` (primarily the 30-frame ending freeze hold + brief holds) | Zero "on twos" stutter; freeze only on final emotional hold |
| Hard Cuts | **`0`** across all 24 scenes | **`0`** (100% continuous camera, match, light, or physical wipes) |

---

## 2. Global Photometric & Optical Telemetry (2,334-Frame Averages)
| Metric | Global Mean | Gloom / Indigo Scenes | Warm / Rich / Healed Scenes | Cold Cobalt Finale (S24) |
|---|---|---|---|---|
| **Mean Luminance (0–255)** | `91.5` | `38 – 86` | `124 – 176` | `83.6` |
| **P05 Shadow Floor (0–255)** | `27.0` | `9.3 – 27.5` | `33.8 – 82.2` | `16.4` |
| **P95 Highlight Ceiling** | `194.2` | `115 – 223` | `204 – 242` | `211.8` |
| **Global HSV Saturation** | `0.511` | `0.47 – 0.67` | `0.37 – 0.47` | `0.631` |
| **Shadow HSV Saturation (<45 luma)** | **`0.653`** | **`0.55 – 0.78`** | `0.48 – 0.67` | **`0.807`** |
| **Vignette Ratio (Corner / Center)** | `0.511` | `0.20 – 0.52` | `0.59 – 1.02` | `0.337` |
| **Global Blue − Red Cast** | `+18.9` | `+11 to +58` | `-43 to +6` | **`+47.3`** |
| **Center Sharpness (Laplacian Var)** | `1,181.4` | `515 – 1,317` | `1,325 – 2,588` | `1,019.3` |
| **Border Sharpness (Laplacian Var)** | `255.2` | `40 – 217` | `205 – 1,400` | `228.7` |
| **Center/Border Sharpness Ratio** | **`4.63×`** | `3.6× – 39.1×` (`159×` macro) | `2.0× – 8.5×` | `4.6×` (`97×` vertical) |

---

## 3. Master Color Token System (Measured Hex Swatches)
```text
--- GLOOM / INDIGO NIGHT WORLD (65% of runtime) ---
SHADOW_DEEP_INDIGO    #0F0D25   (Lifted base shadow floor — NEVER #000000!)
SHADOW_NIGHT_STREET   #151B5E   (Rainy street shadows, S14, S24)
SHADOW_PAWN_SHOP      #1B1731   (Interior wood/cubby shadow, S03, S21)
MID_PERIWINKLE_WALL   #4F4886   (Building stucco & ambient fill, S07, S08)
MID_DUSK_VIOLET       #594A82   (Rainy alley brick/concrete midtone, S05)
PRACTICAL_AMBER_KEY   #FFD07A   (Shop windows, counter bulbs, memory glow)
PRACTICAL_WARM_HALO   #F1D9C1   (Deli interior & warm window bloom peak)

--- WARM MEMORY / GOLDEN HOUR / HEALED WARD (22% of runtime) ---
WARM_SHADOW_PLUM      #351834   (Plum-tinted shadows in morning ward S23)
WARM_MID_MAUVE        #7F5A6C   (Soft sunlit interior midtones)
WARM_HONEY_KEY        #E7C694   (Morning sunlight & lake horizon)
GOLD_GAUGE_FLOOD      #F1D77C   (Happiness gauge peak & climax memory card)
BLOWOUT_GOLD_WHITE    #FFF2C9   (Peak gold blow-out frame f1969-1973)

--- RICH SIDE / DAYLIGHT CYAN (9% of runtime) ---
RICH_SKY_BLUE         #4BA3FF   (Resort sky, S09–S11)
POOL_CAUSTIC_CYAN     #3AE0F2   (Shimmering turquoise water caustics)
SUNLIT_DECK_CREAM     #D4CDB0   (Pool deck & resort marble highlights)

--- SIGNAL & TWIST OVERRIDES (4% of runtime) ---
RED_OPERATING_SIGN    #E8352E   (S18 hospital OPERATING sign & corridor bleed)
COLD_COBALT_TWIST     #161C5F   (S24 shadow — instant 6-frame flip from S23)
DRAIN_HALO_LAVENDER   #B6B5F0   (S19 memory-drain outline around Jerry's head)

--- 2D CHARACTER INK & FILLS ---
CHARACTER_INK_BLACK   #120E1E   (Pure deep ink-black outline, ~1% frame width)
SKIN_PEACH_WARM       #F0DFD6   (Base head fill in neutral/warm scenes)
SKIN_LAVENDER_SHADE   #B29CC6   (Single-step soft crescent shadow on face)
SKIN_HOLLOW_COBALT    #B9C8F0   (Cold tint multiplied on 2D billboard in S24)
HAIR_ORANGE_BASE      #D95B26   (Jerry & brother spiky/limp hair fill)
VEST_MUSTARD_GOLD     #E2A42B   (Jerry's yellow vest flat fill)
FROG_BADGE_GREEN      #4CAF4F   (Recurring green frog motif & chest badge)
```

---

## 4. The 16 Non-Negotiable Style Pillars
1. **True 2.5D Contrast:** 3D lit architectural environments + flat 2D hand-drawn cel-shaded characters.
2. **Saturated Indigo Gloom Paradox:** Dark scenes stay highly saturated (`shadow_sat = 0.65–0.81`) because shadows are deep royal indigo/cobalt, never grey or pure black.
3. **Tiny Warm Practicals in Cold Darkness:** 85–90% of gloom frames are cool blue/violet; 10–15% is a concentrated warm amber focal pool (window, lamp, card, gauge).
4. **Wide-Angle Vertical Staging (`18–24 mm` equiv / `68–76°` vFOV):** Dramatic architectural perspective lines, looming walls, and strong foreground-to-background scale separation.
5. **Real 3D Parallax on Every Camera Move:** Characters sit at physical 3D Z-depths so dollying or trucking smoothly shifts foreground occluders, characters, and background walls at distinct speeds.
6. **Zero Hard Cuts:** Every scene boundary uses a camera move, persistent prop match, face-position match, light blow-out, or physical glass/caustic wipe.
7. **Smooth 30 FPS Motion (Never On Twos):** Continuous eased camera motion (`easeInOutCubic` / `easeInOutSine`) with zero handheld shake and zero artificial film grain.
8. **Zero Motion Blur — Perspective Conveys Speed:** Fast camera whips stay sharp (occasionally using a brief 3-frame ghost double-exposure, as in T1 `f28–30`).
9. **Selective Optical DOF:** Razor-sharp 2D characters isolated against gently or heavily blurred 3D backgrounds (`4.6×` average center-to-border sharpness; `159×` in S02 macro; crisp deep focus reserved specifically for rich/contrast tableaux S09–S12).
10. **Clean Gradients & Restrained Bloom:** Zero film grain or gritty noise. Bloom triggers **only** on emissive lights/windows/cards (threshold `>= 0.88`), never washing out 2D black ink outlines.
11. **Oversized Round-Head Minimalist Characters:** Head `~42%` of total figure height, thick black ink lines (`~1%` width), bean torso, stick limbs, round ball-hands (no fingers), no realistic noses.
12. **Eyebrows, Eye Geometry & Hair Do the Acting:** Double-ring eyes = alive; dash = tired/serene; empty dots = hollow/erased; squeezed-x = affection; limp hair = sick; spiky hair = healed.
13. **Camera & Props Perform More Than Walk Cycles:** Characters mostly hold pose, blink, tilt, and react; the camera pushes in on decisions and pulls back on reveals while props (odometers, domes, gauges, signs) animate mechanically.
14. **Light Color = Plot Signal:** Pulsing windows, flickering warm↔cold sign cycles (`1.43 s` period), red corridor bleeds, gold blow-outs, and instant cold flips directly narrate the plot.
15. **Crisp 1–2 Word Storyteller Captions:** Centered at `y = 70%`, bold white geometric sans (`7.5%` frame width), thick black outline (`~15%` stroke), sentence case, zero background box, zero emoji.
16. **Loop-Bait Emotional Freeze Hold:** Final `1.0 s` (`30 frames`) freezes motionless on the devastating twist image with a trailing emotional line.

---

## 5. Strict Anti-Patterns (Never Do These)
- ❌ **3D-shaded / Pixar / glossy plastic faces** on characters.
- ❌ **Crushed pure black shadows (`#000000`)** or muddy grey desaturated darkness.
- ❌ **Clearcoat / Phong specular circles** on wet sidewalks (always use matte-wet roughness `0.94` + soft painterly additive reflection decals).
- ❌ **Hard jump cuts** between scenes.
- ❌ **Handheld jitter, film grain overlays, VHS glitches, or anime speed lines.**
- ❌ **Low bloom threshold (`< 0.80`)** that makes characters glow or washes out ink outlines.
- ❌ **FFmpeg YUV screen-blend bloom** without `format=gbrp` (causes severe magenta color shift).
- ❌ **Multi-line subtitle blocks, yellow karaoke highlights, emojis, or rounded caption boxes.**
