---
name: every-memory-25d-video
description: Complete 30-FPS forensic analysis, 3D-vs-2D hybrid planning framework, and procedural Three.js + Canvas2D + FFmpeg code engine to recreate vertical short-form animated stories in the exact visual, cinematic, lighting, camera, and acting style of "Every Memory Has a Price.mp4" from any user script or transcript.
---

# Every Memory Has a Price — 2.5D Hybrid Code Video Skill

Use this skill whenever the user provides a **script, transcript, story idea, or plan** (with or without the reference video `Every Memory Has a Price.mp4`) and asks to **plan, design, or generate a vertical (9:16) 30-FPS animated video in this exact 2.5D style using code** (Three.js 3D lit dioramas + Canvas2D hand-drawn cel-shaded characters + headless Chromium WebGL2 + RGB-safe FFmpeg grading).

## Core Visual Truth (Why This Style Works)
*Every Memory Has a Price* is **NOT pure 2D animation** and **NOT pure 3D CGI**. It is a **true 2.5D hybrid**:
1. **3D Lit Diorama World (Three.js):** Wide-angle vertical perspective (`~18–24 mm` equiv / `68–76°` vFOV), architectural geometry, procedural PBR surfaces, real shadow-casting directional + warm practical point lights, smooth painterly wet-street reflections, atmospheric fog, genuine 3D parallax during camera moves, selective shallow DOF lens blur, and 3D foreground occluders (railings, glass windows, counter edges, bedposts).
2. **2D Flat Cel-Shaded Characters & Print Props (Canvas2D RGBA Billboards):** Oversized round heads (`~42%` of figure height), thick pure-black ink outlines (`~1%` frame width), flat fills with a single soft lavender shadow crescent + warm rim, rubber-hose stick limbs with round ball-hands (zero fingers), minimalist face rigs where **eyebrows, eye geometry, hair state, and light color do the acting**. Mounted as z-buffered billboards with `MeshBasicMaterial` (tinted slightly below the bloom threshold) so they **never receive photorealistic 3D shading** yet **naturally occlude behind 3D foreground objects**.
3. **Zero Hard Cuts + Light-as-Plot-Signal:** All 24 scene transitions are continuous camera moves, object/face matches, light blow-outs, or physical glass/caustic wipes. Color temperature is emotional storytelling: **Saturated Lifted Indigo Gloom** (`#0F0D25`, shadow sat `0.65`) vs **Golden-Hour Honey Warmth** vs **Cold Cobalt Hollowness**.

---

## Package Contents (Read Order)
| File | Purpose |
|---|---|
| `references/01_Style_DNA_and_Technical_Spec.md` | Complete measured 2,334-frame technical fingerprint, color tokens, 16 style pillars, anti-patterns |
| `references/02_3D_vs_2D_Layer_Architecture.md` | **Dedicated 3D-vs-2D Planner:** exact rules for what belongs in 3D behind/around the scene vs 2D, integration rules, 24-scene layer table, decision tree |
| `references/03_Frame_by_Frame_Master_Analysis.md` | Exhaustive 30-FPS breakdown of all 24 scenes (`f0001`–`f2334`, `0.00–77.80 s`) with measured telemetry & verified micro-events |
| `references/04_Camera_Motion_and_24_Transitions.md` | Motion physics, parallax, easing curves, and frame-by-frame specs for all 24 zero-hard-cut transitions (5 reusable families) |
| `references/05_Lighting_Color_Blur_and_Gloom.md` | Indigo shadow-lift math, saturation paradox, measured regional Blurriness/DOF profiles (`159×` macro vs deep focus), bloom, vignette, 7 light-signal cues |
| `references/06_Characters_Acting_and_Rig_Spec.md` | Proportions, line weights, full eye/brow/mouth/hair emotion state machine, limb kinematics, complete acting timelines |
| `references/07_Story_Structure_Pacing_Captions_Audio.md` | 8-act narrative curve, 2.8–2.9 wps pacing, 1–2 word caption geometry, 30-Hz audio envelope (`-14.1 LUFS`, `LRA 1.9 LU`), SFX sync map |
| `references/08_Transcript_to_Video_Planning_Guide.md` | Step-by-step AI workflow turning any user script/transcript into a complete production plan, 3D/2D matrix, code render, and QA pass |
| `templates/` | Ready-to-fill `project_plan_template.md`, `3d_2d_layer_matrix_template.csv`, `shot_list_template.csv`, `caption_timeline_template.csv` |
| `starter_code/` | Verified, working Three.js + Canvas2D + Headless Chromium + RGB-safe FFmpeg + Python QA 2.5D engine (`scene_demo.js`, `render_frames.mjs`, `grade_and_finish.sh`, `verify_video.py`) |
| `data/` | Raw 30-FPS measurements (`frame_metrics_30fps_2334.csv`, `audio_envelope_30fps.csv`, `scene_summary_24_scenes.json`, `analysis_dashboard.png`) |
| `assets/` | Visual proof atlas: `keyframes_overview.jpg`, 24 full-res `reference_keyframes/`, 11 frame-by-frame `transition_strips/`, and 33 `contact_sheets/` covering all 2,334 frames |

---

## Mandatory 7-Stage Production Workflow (When Given a User Script / Transcript)

Follow this exact sequence — **never skip straight to writing scene code without completing Stages 1–3**:

1. **Stage 1 — Transcript & Pacing Audit** (`references/07` & `08`):
   - Calculate word count and exact runtime at **2.8–2.9 words/sec** (165–175 wpm), plus a **1.0 s (30-frame) frozen final hold**.
   - Map the script onto the **8-Act Emotional Arc** (Hook -> World -> Contrast -> Mechanic -> Stakes -> Escalation -> Climax Blow-out -> Twist/Freeze).
   - Chunk every spoken word into **1–2 word caption beats** (`templates/caption_timeline_template.csv`, median `0.33 s`).
2. **Stage 2 — 3D vs 2D Layer Plan** (`references/02` + `templates/3d_2d_layer_matrix_template.csv`):
   - For **every single scene**, explicitly assign every visual element to:
     - **3D Background Set** (architecture, terrain, furniture, procedural PBR textures, atmospheric fog)
     - **3D Lighting & Wet Reflections** (hemisphere + directional shadow key + practical point lights + soft additive wet reflection decals)
     - **3D Foreground Occluders** (railings, window frames, counter bevels, bed rails, hoods)
     - **2D Cel Character Billboards** (cast, expression states, hair state, tint hex `< bloomThreshold`, ground contact shadow)
     - **2D Props & Print Graphics** (glowing cards, polaroids, ledgers, gauges, in-world signs)
     - **2D Screen Overlays & VFX** (diagonal rain, dust motes, memory-drain halos, vignette, blow-out flashes, captions)
3. **Stage 3 — Camera, Blur/DOF & Zero-Hard-Cut Transition Plan** (`references/04` & `05` + `templates/shot_list_template.csv`):
   - Choose camera FOV (`68–76°` wide establishing vs `45–55°` macro/intimate), eased motion curve (`easeInOutCubic` / `easeInOutSine`), DOF mode (`shallow_macro`, `shallow_portrait`, `moderate_street`, or `deep_focus`), and exact palette preset (`gloom_indigo`, `warm_honey`, `cold_cobalt`, `red_operating`).
   - Assign one of the **5 approved zero-hard-cut transition families** to every scene seam.
4. **Stage 4 — Build 3D Sets & 2D Cel Rigs in Code** (`starter_code/engine/`):
   - Extend `Hybrid25DStage`, `cel_character_rig.js`, `procedural_textures.js`, and `camera_transitions.js`.
   - Render single-frame `--preview` PNGs of **every scene keyframe** first and visually inspect them before rendering all 30-FPS frames!
5. **Stage 5 — Deterministic 30-FPS Render** (`starter_code/render_frames.mjs`):
   - Render all frames at exact `30.00 fps` (`720x1280` draft or `1080x1920` final) via headless Chromium WebGL2 (`--use-angle=swiftshader --enable-unsafe-swiftshader`).
   - Animate smoothly on ones (30 fps) — never "on twos" — except the intentional 30-frame freeze hold at the end.
6. **Stage 6 — RGB-Safe Look-Grade, Bloom & Audio Mastering** (`starter_code/grade_and_finish.sh`):
   - **CRITICAL:** Always convert to planar RGB (`format=gbrp`) before FFmpeg `blend=all_mode=screen` so bloom never causes a YUV magenta cast!
   - Mix VO + low-register ambient music (`-24 dB` under VO) + frame-locked SFX cues, and normalize to **`-14.0 LUFS`, `LRA ~2.0 LU`, `True Peak <= -1.5 dBTP`**.
7. **Stage 7 — Automated QA Gate** (`starter_code/verify_video.py`):
   - Verify 9:16 resolution, constant 30.00 fps, **zero hard cuts**, lifted indigo shadow floor (`B > R`, `B > G`, `P05 > 12`), saturation, vignette ratio, ending freeze hold, and LUFS loudness.

---

## Non-Negotiable Technical Guardrails
- **Never use `MeshPhysicalMaterial` clearcoat on wet sidewalks with `PointLight`s** — it creates fake round white specular balls. Always use `MeshStandardMaterial({ roughness: 0.94, metalness: 0 })` + `addWetReflectionDecal()` additive radial gradients.
- **Never lower `UnrealBloomPass` threshold below `0.85`** — keep it at `0.88–0.90` (`strength 0.20–0.26`) and tint 2D character billboards slightly below pure white (`#DED6EC`) so practical lights bloom while 2D black ink lines stay razor-sharp.
- **Never crush shadows to pure black `#000000`** — true shadow floor in the reference is lifted saturated indigo (`#15142D`–`#211949`, mean P05 luma `27.0`, shadow HSV saturation `0.653`).
- **Never insert film grain, handheld camera shake, anime speed-lines, or hard cuts.**
- **Never put fingers on hands or 3D shading on character faces.**
