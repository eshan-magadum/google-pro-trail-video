# Production Plan: <VIDEO_TITLE>

> Generated using the **Every Memory Has a Price — 2.5D Code Video Skill**
> Target format: `1080x1920` (or `720x1280` draft), `30.00 fps` constant, H.264 Main/High, BT.709, `yuv420p`, `-14.0 LUFS` (LRA ~2 LU, True Peak <= -1.5 dBTP).

## 1. Story & Emotional Thesis
- **Logline (1 sentence):**
- **Total Duration Target:** `<N>` seconds (`<N*30>` frames at 30 fps)
- **Spoken Word Count:** `<W>` words (Target pacing: **2.8–2.9 words/sec**, ~165–175 wpm)
- **Core Emotional Shift (Light-as-Story):**
  - Opening Mood / Palette: `[ ] Gloom Indigo` / `[ ] Warm Honey` / `[ ] Cold Cobalt`
  - Peak Warmth / Memory Beat (`t = ...s`):
  - Climax Blow-out / Transition (`t = ...s`):
  - Final Freeze-Frame Twist (`last 1.0 s = 30 identical frames`):

## 2. Beat Architecture (8-Act Short-Form Curve)
| Act | Time Window | Frames | Narrative Function | Dominant Palette | Avg Scene Len |
|---|---|---|---|---|---|
| 1. Hook | 0.0 – 5.0 s | f0001–f0150 | Stark claim + glowing hero prop + antagonist/hook | Gloom + 1 warm key | 0.8–3.0 s |
| 2. World | 5.0 – 16.0 s | f0151–f0480 | Establish rules across 3–4 micro-locations | Rainy indigo + warm windows | 1.5–4.0 s |
| 3. Contrast | 16.0 – 28.0 s | f0481–f0840 | Mirror structure (rich vs poor / before vs after) | Deep-focus cool/warm split | 2.5–3.5 s |
| 4. Mechanic | 28.0 – 35.0 s | f0841–f1050 | Visual device/gauge/meter proving the rule | Dark + gold-flood trigger | 3.5–4.0 s |
| 5. Stakes | 35.0 – 47.0 s | f1051–f1410 | Personal anchor + warm flashback memory | Indigo -> Golden-hour honey | 3.0–4.5 s |
| 6. Escalation | 47.0 – 59.0 s | f1411–f1770 | Rising cost / ledger / flickering drain | Red bleed / warm↔cold cycle | 3.5–5.0 s |
| 7. Climax | 59.0 – 66.0 s | f1771–f1980 | Quiet confrontation + full gold-white blow-out | Lavender -> Gold blow-out | 2.5–5.0 s |
| 8. Twist / Hold | 66.0 – 78.0 s | f1981–f2340 | Warm payoff -> instant cold flip -> 30-frame freeze | Warm cream -> Cold cobalt | 5.0–6.5 s |

## 3. Cast & 2D Cel Character Bible
| Character | Head/Hair Silhouette | Outfit Flat Fill | Eye Code (Alive / Tired / Hollow) | Key Expression Beats |
|---|---|---|---|---|
| Protagonist | Round head (42% height), spiky hair w/ zig-zag shading | Flat torso + 1 iconic chest badge | Double-ring -> dash -> empty dot | Wary -> tender -> drained -> hollow |
| Foil / Secondary | Distinct hat/hair/hood silhouette | Contrasting flat color | Smug / wide / squeezed-x | Bored -> grin -> shocked |

## 4. 3D Environments vs 2D Overlays Summary
*(Complete every scene row in `3d_2d_layer_matrix.csv` before writing code.)*
- **3D Sets Needed (Three.js Dioramas):**
  1. `<Set A>` — Geometry, textures, practical lights, wet reflections, foreground 3D occluders
  2. `<Set B>` — ...
- **2D Animated Assets (Canvas2D RGBA Billboards & Overlays):**
  1. Character rigs (`cel_character_rig.js` states)
  2. Hero 2D/2.5D props (cards, polaroids, ledger, gauges, signs)
  3. Atmospheric 2D overlays (diagonal rain, dust motes, halo outline, glitch mosaic, captions)

## 5. Zero-Hard-Cut Transition Plan
*(Every scene boundary MUST use one of the 5 approved transition families: Camera-Led, Object-Match, Face-Position Match, Light-Led Blow-Out/Flip, or Physical Occluder/Glass/Mosaic.)*
- `S01 -> S02`:
- `S02 -> S03`:
- ...

## 6. Audio, Voice & Caption Sync Plan
- **Narration Voice:** Single close-mic warm narrator, ~2.8 wps, short 6–12 word sentences.
- **Music Bed:** Low-register ambient minor pad at `-24 dB` under VO; swells on climax blow-out.
- **SFX Cues:** Map every camera swing (whoosh), mechanical action (click/odometer/hum), weather (rain), and emotional beat (silence-before-flare) to exact frame numbers.
- **Captions:** 1–2 words per chunk, centered at `x=50%`, `y=70%`, bold geometric sans (`7.5%` frame width), pure white fill `#FCFDFD`, thick black stroke (`7–8%` font size), sentence case, zero background box, zero emoji.
