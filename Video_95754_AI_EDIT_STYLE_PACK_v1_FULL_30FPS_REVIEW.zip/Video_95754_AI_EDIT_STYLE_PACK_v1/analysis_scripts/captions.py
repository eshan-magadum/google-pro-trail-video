import csv, json
FPS = 29.97
C = [("Anthropic",1),("engineer",15),("just built",28),("the most",43),("powerful",54),("prompt",72),("that I have",84),("ever seen,",97),
("but nobody is",122),("using it",156),("when",176),("prompting",184),("most of us.",190),("Just describe",206),("the task.",231),
("well in fact,",246),("we should be",266),("using",278),("the deeper",287),("meaning",313),("behind",331),("the prompt.",355),
("for example,",369),("instead",389),("of saying",397),("to Claude,",407),("fix this bug,",419),("say to",442),("Claude,",453),
("keep this app",464),("bug free.",493),("paste",512),("this prompt",519),("in before",534),("any task.",548),("and that's",566),
("why this",575),("anthropic",587),("skill is",605),("so powerful.",619),("Just",642),("paste it in",647),("before",669),("any task,",680),
("and it",704),("tells you",711),("what a top",725),("expert",745),("would say,",758),("things",775),("that you",785),("would",795),
("never have",801),("thought about.",824),("and",848),("it doesn't",849),("just give",858),("you advice,",867),("It actually",883),
("reviews",894),("the whole prompt.",907),("So you're",936),("getting",944),("the expert",956),("version",980),("of it.",996),
("Want the",1014),("prompt?",1017),("Comment",1029),("deeper",1044),("and I'll",1061),("send it over.",1071)]
SC = json.load(open("/tmp/v95/pack/data/scenes.json"))["scenes"]
def scene(f):
    for s in SC:
        if s["start_frame"] <= f <= s["end_frame"]: return s
out = []
for i, (t, f) in enumerate(C):
    e = (C[i+1][1] - 1) if i + 1 < len(C) else 1093
    s = scene(f)
    pos = "on split seam (y~632px centre)" if s["layout"] == "SPLIT" else "lower-middle (y~850px centre)"
    out.append(dict(idx=i+1, text=t, words=len(t.split()), start_frame=f, end_frame=e, frames=e-f+1, start_s=round((f-1)/FPS,3),
                    end_s=round(e/FPS,3), duration_s=round((e-f+1)/FPS,3), scene=s["id"], layout=s["layout"], position=pos))
with open("/tmp/v95/pack/data/caption_chunks_frame_accurate.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, out[0].keys()); w.writeheader(); w.writerows(out)
import statistics as st
d = [o["frames"] for o in out]; wds = [o["words"] for o in out]
print(len(out), "chunks; mean frames", round(st.mean(d),1), "median", st.median(d), "min", min(d), "max", max(d), "words mean", round(st.mean(wds),2), "dist", {k: wds.count(k) for k in set(wds)})
