# 04 — CAPTIONS & TYPOGRAPHY SPECIFICATION

The full frame-accurate table of all 72 caption chunks is in `data/caption_chunks_frame_accurate.csv`.

## 1. The primary caption chip (used in all 18 shots)
| Property | Measured value (at 720 × 1280) |
|---|---|
| **Font family** | Geometric grotesque sans-serif — matches **Inter Bold / ExtraBold** or **SF Pro Display Bold** (`font-weight: 700–800`). |
| **Font size** | **~44–46 px** (cap height ~32 px, x-height ~24 px). |
| **Text colour** | Pure white `#FFFFFF`. |
| **Text stroke / shadow** | Thin dark outline / tight drop shadow (`0 2px 6px rgba(0,0,0,0.65)` + `1.5 px` dark stroke) so letters stay crisp over bright backgrounds too. |
| **Chip background** | Translucent dark charcoal pill: `rgba(55, 55, 60, 0.78)` (on dark backgrounds it reads as `#464648`, on bright blue/cyan it blends slightly toward `#2f3b52`). |
| **Chip padding** | `padding: 10px 22px` (vertical × horizontal). Box height is **~68–72 px**; width hugs the text tightly (`text_width + 44 px`). |
| **Corner radius** | **~14–16 px** (rounded rectangle, NOT a full circular capsule). |
| **Horizontal alignment** | Always **centred** (`x = 360 px`). Single line only — never wraps to 2 lines. |
| **Animation on change** | **Instant cut (0-frame swap).** No pop, no fade, no word highlight, no karaoke fill. The pill width resizes instantly to the new text. |

### Vertical position rule (depends on layout!)
| Layout | Chip centre `y` | Why |
|---|---|---|
| **SPLIT** (S01, S04, S08, S10, S13, S15) | **y ≈ 632 px** (box `y: 597 → 667`) | Sits **directly on the horizontal seam (`y = 640`)** between the top graphic and the bottom speaker, overlapping the top of the speaker's hair by ~25 px. Anchors the two halves together and keeps the eye in the middle of the frame. |
| **FULL_GFX** (S02, S03, S05, S07, S09, S11, S12, S16, S17) | **y ≈ 845–860 px** (box `y: 812 → 884`) | Sits **just below the hero graphic** (in the "floor" zone — desk band, deep water, stage floor, blue rays), well above Instagram's bottom UI caption/audio area (`y > 1020`). |
| **FULL_SPEAKER** (S06, S14, S18) | **y ≈ 850 px** | Sits over the speaker's upper chest / collarbone, below the chin (`chin ≈ y 760–800`), so the mouth is never covered. |

## 2. Chunking rules (72 chunks across 130 words)
- **Words per chunk:** **1 to 3 words only.** Never 4+ words.
  - 1 word: **25 chunks (34.7%)** — used on punch words: `Anthropic`, `engineer`, `powerful`, `prompt`, `when`, `prompting`, `using`, `meaning`, `behind`, `instead`, `Claude,`, `paste`, `anthropic`, `Just`, `before`, `expert`, `things`, `would`, `and`, `reviews`, `getting`, `version`, `Comment`, `deeper`.
  - 2 words: **36 chunks (50.0%)** — the default rhythm (`just built`, `the most`, `using it`, `the task.`, `the deeper`, `bug free.`, `so powerful.`, `would say,`, `never have`, `thought about.`, `you advice,`, `It actually`, `the expert`, `of it.`, `Want the`, `and I'll`).
  - 3 words: **11 chunks (15.3%)** — only for fast short function words (`that I have`, `but nobody is`, `most of us.`, `well in fact,`, `we should be`, `keep this app`, `paste it in`, `what a top`, `the whole prompt.`, `send it over.`).
- **Duration per chunk:** mean **15.2 frames (0.51 s)**, median **14 frames (0.47 s)**, typical range **8–26 frames (0.27–0.87 s)**.
- **Case & punctuation:** **original sentence case with punctuation preserved** (`ever seen,`, `the task.`, `well in fact,`, `Claude,`, `prompt?`). Do **not** force all-caps or strip commas/periods. Notice occasional lowercase stylings (`when`, `paste`, `and that's`, `anthropic`, `deeper`) — natural sentence fragments.

## 3. The CTA keyword overlay (S18, f1040–1093)
When the speaker asks the viewer to comment a keyword (`Comment "deeper"`), a **second, much larger text layer** appears **below** the normal caption chip and stays locked until the final frame:
- **Text:** `“DEEPER"` (curly opening double-quote + ALL-CAPS keyword + closing double-quote).
- **Font:** High-contrast **Display Serif Bold** (matches **Times New Roman Bold / Playfair Display Bold / Georgia Bold**).
- **Size:** **~92–96 px** (cap height ~68 px), spans `x ≈ 55 → 665 px` (~85% of frame width).
- **Position:** centred at **`y ≈ 955 px`**, directly underneath the normal caption chip (`y ≈ 850`), which continues updating (`Comment` → `deeper` → `and I'll` → `send it over.`).
- **Styling:** pure white `#FFFFFF` with a strong soft black drop shadow (`0 6px 18px rgba(0,0,0,0.85)`), no background pill.
- **Timing:** pops on at **f1040 (34.67 s)** — 4 frames *before* the caption chip switches to `deeper` (f1044) and right as the speaker raises both hands for air-quotes — and holds through **f1093 (36.47 s)**.

## 4. In-graphic typography system (4 distinct type roles)
The graphics themselves use a consistent 4-font pairing that makes them feel editorial rather than generic:

| Role | Typeface style | Where it appears |
|---|---|---|
| **1. Editorial / "Prompt & Expert" display voice** | **Bold Italic Old-Style Serif** (Bookmania / Georgia Bold Italic / Instrument Serif Italic, `#1d1714`) | Cartridge label `be-ambitious` (S09), door brass plate `Expert` (S11), speech bubble `Reproduce it first.` (S12), index card `Why is checkout so slow?` (S15), card header `Expert version` (S16), paper title `The Prompt` (S17). **Rule:** whenever a graphic names a *skill, prompt, or expert quote*, set it in **Bold Italic Serif**. |
| **2. Product UI / checklist sans** | **Inter / SF Pro (Regular & Bold)** | Claude chat input (`Make a slide deck for our Q3 review.`, `Opus 5.5`, suggestion chips), iceberg layer titles (`What a pro would do`, bold navy `#0d214f`), task conveyor cards (`Q3 review deck`, `Launch email`, `Checkout bug`), checklist rows (`Raw traces`, `Profile it`, `Load test`). |
| **3. Code / skill identifier monospace** | **JetBrains Mono / SF Mono Medium** | `✳ be-ambitious` pasted card header (S08), `SKILL.md` cartridge header bar (S09), `✳ be-ambitious` orange stamp pills (S10). |
| **4. Long-form article serif** | **Source Serif / Charter / Georgia Regular** (light cream `#e8e6df` on `#100f0b`) | The actual Anthropic article and blockquote in S02–S03 (`I want a deeper version of this task, not a bigger one...`). |
| **5. Rubber stamp** | **Tracked uppercase slab/typewriter serif** (`#d93829`, double border rectangle, rotated `-15°`) | `EXCLUSIVE` stamp on `The Prompt` sheet (S17). |
