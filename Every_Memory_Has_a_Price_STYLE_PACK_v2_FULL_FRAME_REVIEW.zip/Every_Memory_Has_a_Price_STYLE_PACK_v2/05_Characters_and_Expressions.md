# 05 — CHARACTERS, EXPRESSIONS & PERFORMANCE
*(All character description is visual observation from full-resolution frames.)*

## Shared character construction
* **Head**: huge perfect circle/oval, ~40–45 % of total figure height; flat peach (`#F3D9BD`-ish) or chalk-white fill; a single soft shade shape on the shadow side.
* **Outline**: thick pure-black ink line (~6–8 px at 720 p), slightly varying width, closed shapes, hand-drawn wobble. Props get thinner black outlines (~2–3 px).
* **Body**: bean/oval torso in one flat colour + a simple clothing detail; **stick limbs** (thin rubber-hose lines with round ball hands/feet), no fingers.
* **Face**: minimalist — double-ring eyes (circle with smaller pupil circle) *or* simple dot eyes; thin arched eyebrows (the main acting tool); tiny mouth: dot, small curve, "o", or flat line. No nose except a tiny tick.
* **Hair**: flat orange with **zig-zag line shading** and 2–3 pale highlight strokes.
* **Lighting on characters**: key tint (warm peach) + cool lavender shade overlay + optional rim; they cast soft contact shadows but are not volumetrically modelled.
* **Animation**: limited — blinks, brow shifts, head tilts, mouth shapes, small body sway; locomotion only when the story needs it (bike, walking in). The **camera does most of the acting**.

## Cast
| Character | Design | Key notes |
|---|---|---|
| **Protagonist (Jerry)** | Orange spiky hair; yellow vest with white centre stripe over white shirt; small **green frog badge** on the chest; skinny black legs | Most expressions in the film (see arc) |
| **Little brother** | Same hair, smaller; pale blue/green dotted hospital gown; frog plush on the bed rail | Warm light when cured |
| **Hooded stranger (shopkeeper)** | Big black-navy hood with pale-blue rim line; chalk-white oval face; huge toothy grin; **glowing amber pupils** | Grin grows larger as price climbs (2.5→4.5 s, 30→31 s); later face is unmasked-looking, round, worried |
| **Extractor-shop assistant** | Bald white round head, tiny mouth | Stands beside the chair (S06) |
| **Rich-side figures** | Straw hat + sunglasses lounger; butler in white jacket with tray; Hawaiian-shirt guy with snorkel and yellow tube | Smug half-closed eyes, flat expression |
| **Poor-side elders** | Three on a bench: curly-grey woman with earrings, bald man with round glasses, one more partially visible | Each holds a framed/polaroid photo; faces are soft, vaguely content, eyes blank |
| **Landlord/others** | Blue-skinned or dark-clothed side figures, a green-capped kid with frog | Quick supporting beats |

## Jerry's expression timeline (observed from frames)
| Time | Expression | How it's drawn |
|---|---|---|
| 0.0–0.5 s | Wary, uneasy | Eyebrows tilt inward-up, small dot mouth |
| 0.5–0.9 s | Wide-eyed alarm | Eyes widen to full rings, pupils tiny |
| 36.5–38 s | Tender contentment (with brother) | Eyes closed as arcs, soft smile |
| 43.0 s | Exhausted, drained | Half-lid, mouth a flat dash |
| 43.5 s | Shock + **sweat drop** | Eyes round, a blue drop at the temple |
| 44.0 s | Defeated worry | Brow knit, tiny wavy frown |
| 45–47 s | Hopeful-but-afraid | Eyes up and to the side, small asymmetric smile, then a single tear |
| 48.5–49.5 s | Deadpan numb | Heavy half-lids, flat mouth |
| 50.5 s | Alarmed | Eyes wide, tiny mouth |
| 51–54 s | **Glassy empty stare**, slight head tilt | Lids half-down; head tints lavender-white with a glowing halo at 54 s (memory draining), flicking warm↔cool |
| 62–63 s | Scared, pale | Wide eyes, small "o" mouth |
| 63.5 s | Resigned | Half-lid with the helmet |
| 71.5–77 s | **Blank, pale-blue, vaguely confused** | Eyes large, pupils centred, tiny asymmetrical mouth; cold cobalt light, no warmth on his face |

## Brother
* 37–38 s: sunken eyes, faint smile, held in warm lamp light.
* 55–56 s: sunk into pillows, bluer and dimmer.
* 66.5 s: eyes open, brows scowling (waking) → 67 s eyes closed beaming → 67.5–69 s huge open grin with teeth and big pupils → 69.5 s excited open "o" mouth asking → 70.5 s squinting-smiling, hand raised.
* 74–77 s: tiny, warm, in the left of frame while Jerry fills the right in cold blue.

## Stranger's arc
* 1.8–5 s: **gleeful grin** (white teeth, curved lids), amber glints.
* 27.7–29 s (v2 correction): at the start of the gauge scene he is **bored and blank**, head drooping/tilting (f833–875).
* 29.3–31 s: smile appears (f879), full toothy grin (f893), eyes glow amber from f901 as the dial floods gold.
* 44.5–47 s: appears as a dark silhouette in the foreground, only faint eyes catching light; later he leans in with a flat mouth.
* 59.9–60.0 s (f1773–1776): **he pulls his hood back** to reveal a round white face; 60–61 s: worried tilted brows, small ellipse mouth, **tremor lines** at the left of the face, a one-eye **wink/flinch** (f1840–1846); 63 s: raised brow → eyes squeezed shut sadly → wide shocked ring-eyes.

## Acting rules to copy
1. One emotion per beat; change it with brows and lids, not with big mouth shapes.
2. Faces get big (extreme close-ups) at moments of decision.
3. Never show anything cruel — the horror is calm.
4. Light colour is part of the performance (lavender = hollow, warm = loved).

---
## v2 ADDITIONS (from viewing every frame)
### Eye / mouth / hair code
| Signal | Meaning | Examples (frames) |
|---|---|---|
| Double-ring eyes with small pupils | Alive, present, attentive | Jerry f7–1300 |
| Eyes as a flat dash/line | Tired, blink, serene | f1481–1500, f2154–2158 |
| One eye closed | Wink/flinch/startle | Jerry f2–3, stranger f1840–1846 |
| **Plain dot eyes (no rings)** | **Hollow — the memory is gone** | Jerry f2203–2334 |
| Squeezed-x/curved eyes | Affection, trust | brother f2116–2130 |
| Wavy zig-zag mouth | Anxiety / confusion | Jerry f1306–1320, f2145–2150 |
| Sweat drop at the temple / tear | Panic / grief | f1302–1320 / f1399–1405 |
| Limp flat hair | Sick | brother f1979–2005 |
| Spiky springing hair | Healthy, joyful | brother f2008–2012 |
| Blue-white halo outline on the head | Memory draining | Jerry f1607–1640 |

### Brother — two designs
* **Street (S14):** green cap, red shirt, with a frog that hops on his cap; healthy and bouncing; collapses at f1046–1060.
* **Hospital (S15–S24):** light-blue dotted gown, orange hair (limp when sick); final expression arc: cheerful → confused squiggle eyes → **hurt frown as Jerry stares past him** (the film's last image).

### Performance details
* The camera acts: push-ins on decisions, pull-backs for reveals. Characters rarely walk; they pose and change eyes/brows/mouth.
* Props perform too: the odometer rolls then settles; the dome descends/ascends; the gauge needle swings; the OPERATING sign flips.
* 'Ball-hand' (a black round hand) enters frame to press, hold or present objects (box f1442, ledger f1683, polaroid f2192).
