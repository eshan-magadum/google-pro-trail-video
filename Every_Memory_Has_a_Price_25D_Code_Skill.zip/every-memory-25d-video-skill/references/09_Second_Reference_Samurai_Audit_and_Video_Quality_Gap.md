# 09 — Second Reference Forensic Audit (`Why Samurai Feared The Flying Thunder.mp4`) & Full-Video Quality Gap Analysis

## 1. Executive Summary (30-FPS Forensic Comparison)
A complete 30-FPS frame-by-frame audit was performed across **three full vertical Shorts** plus our single-frame renders:
1. **Reference #1:** `Every Memory Has a Price.mp4` (`2,335 frames`, `77.83 s`, `720×1280`, `-14.1 LUFS`)
2. **Reference #2:** `Why Samurai Feared The Flying Thunder.mp4` (`1,772 frames`, `59.07 s`, `720×1280`, `-14.1 LUFS`, `LRA 2.4 LU`, `Peak -2.0 dBFS`)
3. **Our 69 s Full Code Short:** `parachute_hole_short.mp4` (`2,070 frames`, `69.00 s`, `1080×1920`)
4. **Our Single-Frame Benchmarks:** `zombie_plane_frame.png` & `deli_remake.png`

### Measured 30-FPS Quantitative Gap Table

| Metric | Samurai Ref #2 (`59.1s`) | Every Memory Ref #1 (`77.8s`) | Our Single Frame (`zombie_plane`) | Our 69s Video (`parachute_short`) | Diagnosis |
|---|---:|---:|---:|---:|---|
| **Visual Detail Density (`edge_pct > 22`)** | **`15.11%`** (`P90: 24.4%`) | **`19.17%`** (`P90: 24.8%`) | **`14.90%`** ✅ | **`8.52%`** ❌ | **44–56% lower surface/prop micro-detail in multi-scene video!** |
| **Gradient Detail Mean (`edge_mean`)** | **`14.01`** | **`16.21`** | **`12.35`** ✅ | **`9.23`** ❌ | Surfaces & backgrounds too smooth/empty |
| **Focal Center Sharpness (`sharp_ctr`)** | **`4,464`** | **`4,051`** | — | **`1,319`** ❌ | **3.2× softer center micro-linework & texture crispness** |
| **Color Warmth `R - B` (`mean` / `P10..P90`)** | **`+6.9`** (`-19.9 .. +38.2`) | **`-20.2`** (`-61.6 .. +27.4`) | — | **`-41.9`** (`-75.7 .. -8.9`) ❌ | **Over-blued everywhere! Even warm scenes stayed blue (`P90 < 0`)** |
| **Shadow Floor (`P05 RGB`)** | **`(33.1, 27.2, 33.6)`** | **`(19.9, 19.3, 42.8)`** | `(14.0, 8.3, 38.4)` | `(8.6, 18.4, 65.3)` ❌ | Over-saturated neon-blue shadows in daytime/warm interiors |
| **Practical Bloom (`luma > 235`)** | **`1.97%`** (`P50: 1.59%`) | **`1.60%`** (`P50: 0.49%`) | `0.11%` | **`0.43%`** (`P50: 0.00%`) ❌ | Missing warm glowing practicals in >50% of frames |
| **Kinetic Motion (`frame_diff` mean / P50)** | **`6.30`** / `5.04` | **`6.55`** / `4.60` | — | **`4.25`** / `2.46` ❌ | Half the median frame-to-frame life & acting motion |
| **Visual Beat Rate (beats / minute)** | **`18.3 / min`** (`1 every 3.3s`) | **`15.4 / min`** (`1 every 3.9s`) | — | **`10.4 / min`** (`1 every 5.8s`) ❌ | Lingers too long on static or sparsely staged angles |

---

## 2. Frame-by-Frame Craft Breakdown of `Why Samurai Feared The Flying Thunder.mp4`
Inspecting all 72 sampled tiles (`assets/samurai_reference/samurai_grid_part1.jpg`, `part2.jpg`) and 6 full-resolution micro-detail stills (`s_tent_f384.png`, `s_sparks_f1200.png`, `s_cutaway_f1392.png`, `s_shogun_f1680.png`) reveals **7 concrete production techniques** that make this video feel cinema-grade from frame 1 to frame 1,772:

1. **Dense Environmental Micro-Storytelling (`15–25` props per set):**
   - *Ming Tent (`f288–550`):* Ornate crimson-and-gold patterned rug with floral medallion & border tassels, cream ribbed canvas walls with angled wooden ceiling struts, painted folding shoji screen (pine tree + moon), red lacquer armor stand, standing katana, glazed ceramic jar + ladle, neat pair of wooden sandals on the floor, scroll vase overflowing with colored scrolls, brass incense braziers, glowing paper lanterns.
   - *Samurai Night Camp (`f048–140`, `f600–1750`):* Wheel-rutted dirt trail, hundreds of scattered dry grass tufts catching warm firelight, stone-ringed campfire + tripod cauldron + real flame & rising smoke column, wooden benches, bamboo water tubs, crates, barrels, stacked spear tripods, waving clan `nobori` banners with crests, wooden watchtowers, distant pine trees, hills topped with tiny silhouettes.
2. **Painted Realistic Atmospheric Skyboxes (ZERO Flat Solid Backgrounds):**
   - Deep twilight skies feature multi-layered dark wispy clouds, atmospheric horizon mist, and a softly blooming moon (`f048–260`) — **never** a flat single-color Three.js `scene.background` or repetitive round radial circles.
3. **Natural Warm-vs-Cool Lighting Contrast (Correcting Over-Bluing!):**
   - Unlike *Every Memory*'s strictly nocturnal neon-indigo aesthetic, *Samurai* uses **natural twilight charcoal-violet shadows** (`P05 RGB = 33, 27, 34`) contrasted with **rich warm orange firelight, amber lanterns, warm wood & red-gold textiles** (`warmth R-B` reaching **`+38.2`**!). Warm practical lights visibly bounce onto nearby grass blades, faces, and wood planks.
4. **Full Multi-Angle 2.5D Character Acting & Intricate Costumes:**
   - Characters are **NOT stiff front-facing cutouts**. They lean hard forward bowling the iron bomb (`f000–024`), turn **3/4 and full back-of-head** showing lined hair strands & hairpins (`f384, f456`), lie horizontally asleep in bed (`f528`), sneak hunched past sleeping guards (`f552–576`), duck behind tables covering ears (`f696–768`), crouch to pick up & shake the bomb (`f792–840`), swing katanas overhead (`f984–1032`), bash with staffs throwing directional metallic sparks (`f1176–1224`), and sit recoiling on the ground beside a towering antlered Shogun (`f1656–1704`).
   - Costumes carry intricate **2D line-art detail**: horizontal laced lamellar armor plates with rivets, distinct kabuto helmets (golden antlers, tall white eboshi, wide red-tasseled Ming hat, headbands, eye-patch), quilted tunic stitches, diagonal leather straps, and glinting steel weapons.
5. **High-Detail 3D Hero Cutaways Staged INSIDE the Live 3D World (`f1344–1560`):**
   - When explaining the bomb's internal mechanism, the 3D cast-iron sphere splits cleanly into floating top/bottom hemispheres (`f1368`) revealing a **turned wooden spool with wood grain and 18 helical coils of braided rope (`TubeGeometry`)** (`f1392–1560`) with live burning embers creeping down the spiral — **AND it stays staged directly inside the full grass-and-banner 3D camp**, NEVER in an empty solid-color void!
6. **Kinetic VFX Tied to Physical Impacts:**
   - Directional orange spark streaks spraying diagonally across dirt (`f1200`), jagged electric lightning crack (`f1320`), radial fracture web etched into dirt under the bomb (`f1344, f1608–1704`), swords stuck upright into the ground (`f1608`), and a massive billowing layered orange-gold fireball (`f1728–1771`).
7. **Rapid Visual Beat Frequency (`18` distinct visual beats in `59 s` = `1 every 3.3 s`):**
   - Every ~3 seconds delivers a genuinely new camera angle, physical action, or visual reveal — maintaining median `frame_diff = 5.04`.

---

## 3. Root Cause: Why Our Single-Frame Renders Looked 10/10 While Our 69s Video Fell Short

| Failure Mode Observed in `parachute_hole_short.mp4` | Why It Happened | Permanent Fix Enforced in Skill v2.0 |
|---|---|---|
| **Sparse rooms & empty voids** (`edge_pct 8.5%` vs `15–19%`) | Cramming 4 worlds into one monolithic `short_scene.js` starved each location to ~80 lines & ~5 primitive shapes | **Dedicated per-world modules (`worlds/world_<name>.js`, `>= 250 lines` each)** with hard **15-prop + 2-occluder + ground-detail + painted-skybox budget** |
| **Monochromatic neon-blue tint everywhere** (`warmth -41.9`) | Over-applying *Every Memory*'s indigo shadow rule to daylight, warm interiors, and golden sunsets | **Palette-matched shadow rule:** use natural warm-charcoal shadows (`P05 ~30,26,35`) & strong warm keys (`warmth +15..+40`) for warm interiors/daylight/firelight; reserve heavy indigo strictly for night gloom! |
| **Stiff front-facing paper-cutout characters** | Reusing only front-facing poses with simple single-color bean torsos | **Multi-pose 2.5D character rigs** (front, 3/4, back-of-head, crouch, lean, sit, prop-in-hand) + layered costume linework (seams, pockets, straps, plates, distinct headgear) |
| **Empty-void physics explainer (`S09`)** | Putting cutaway prop inside a blank `scene.background` color | **Never isolate a cutaway in an empty void** — stage exploded 3D hero props directly inside the live dressed 3D set with shallow DOF! |
| **Missed flaws during thumbnail-only audit** | Checking a tiny `4×4` thumbnail sheet (`360×640` tiles) hid sparse walls & flat textures | **Mandatory Full-Res Per-Scene Single-Frame Gate:** inspect **every scene's full-res (`720×1280` or `1080×1920`) PNG individually** AND pass automated `edge_pct >= 13.0%` before rendering chunks! |
