import cv2, numpy as np, sys, os
def make_sheet(frame_ids, out, cols=8, tw=150, th=267):
    rows = (len(frame_ids)+cols-1)//cols
    sheet = np.zeros((rows*th, cols*tw, 3), np.uint8)
    for k, fid in enumerate(frame_ids):
        img = cv2.imread(f'frames/f_{fid:05d}.jpg')
        img = cv2.resize(img, (tw, th), interpolation=cv2.INTER_AREA)
        label = f'{(fid-1)/30:.2f}s'
        cv2.rectangle(img, (0,0), (62,15), (0,0,0), -1)
        cv2.putText(img, label, (2,11), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255,255), 1, cv2.LINE_AA)
        r, c = divmod(k, cols)
        sheet[r*th:(r+1)*th, c*tw:(c+1)*tw] = img
    cv2.imwrite(out, sheet, [cv2.IMWRITE_JPEG_QUALITY, 88])
if __name__ == '__main__':
    step = int(sys.argv[1]); start=int(sys.argv[2]); per=int(sys.argv[3]); prefix=sys.argv[4]
    ids = list(range(start, 2335, step))
    for n in range(0, len(ids), per):
        make_sheet(ids[n:n+per], f'sheets/{prefix}_{n//per:02d}.jpg')
    print(len(ids), 'frames ->', (len(ids)+per-1)//per, 'sheets')
