# 03 — CAMERA MOVEMENT, MOTION & TRANSITIONS
Measured with Farnebäck optical flow on all 2,334 frames (global translation, zoom-divergence, magnitude) + frame-by-frame inspection of every transition.

## Motion statistics
* Mean motion 1.02 px/frame (analysis at 180×320), median far lower; **peak 10.1 px/frame at 64.1 s** (helmet-descent whip).
* Holds (S13, S19, S23, S24): 0.35–0.62 px/frame = slow parallax drift only.
* Bursts: 0.3–0.6 s at 4–9 px/frame, always eased in and out (no linear moves).
* No visible handheld shake. No obvious motion blur — speed is conveyed by perspective change.
* **Zero hard cuts.** Confirmed by viewing every frame: all 24 transitions below are dissolves, wipes, match-cuts or continuous camera moves.
* **Smooth 30 fps animation:** only 35 of 2,333 frame pairs are near-duplicates (the final hold + a few light pauses), so motion is NOT animated 'on twos'.

## The 24 transitions (v2 — rebuilt after viewing EVERY frame in order)
No transition is a hard cut. Frame numbers are exact (frame = time × 30 + 1).
| # | Frames (time) | Technique | What actually happens |
|---|---|---|---|
| T1 | f25–35 (0.8–1.1 s) | **Swing-pitch with ghost blend** | Short push-in on the hero, then the camera swings and pitches ~70° down onto the counter; his face double-exposes over the counter for 3 frames (f28–30) |
| T2 | f47–60 (1.5–2.0 s) | **Continuous pull-up** (not a dissolve) | From the card macro the camera lifts back, register appears, vignette closes, the stranger enters far-left at f55; luma 130→40 |
| T3 | f151–166 (5.0–5.5 s) | **Glass-pane sweep** | Pane edge enters from the left (f153), hero from the right (f152), shop dissolves to the rainy alley (f158–166) |
| T4 | f196–204 (6.5–6.8 s) | **Window-glass dissolve** | Alley seen through rain-spotted glass; lit extractor shop fades in behind it |
| T5 | f259–264 (8.6–8.8 s) | **Haze cross-dissolve** | Lavender-white shop haze → indigo deli street |
| T6 | f397–432 (13.2–14.4 s) | **Tilt-up** | Street → banner with round emblem → spot-lit wall, with Dutch roll |
| T7 | f470–481 (15.6–16.0 s) | **Downward seam wipe** | A seam at ~45 % height travels down; leading edge is an overexposed white band that resolves into cyan caustic water |
| T8 | f557–566 (18.5–18.8 s) | **White blow-out dissolve** | Resort → near-white frame → window room with the dome-extractor man |
| T9 | f685–720 (22.8–24.0 s) | **Water dissolve + vertical light-streak blur** | Couch ghosts into flamingo-pool water; vertical blurred white-blue streaks sweep over and dissolve into the dusk bench (bench ghosts at f716–720) |
| T10 | f825–836 (27.5–27.9 s) | **Shape match-cut** | Round brass dial ring grows over the bench scene and becomes the gauge scene (photo frame → dial) |
| T11 | f946–956 (31.5–31.8 s) | **Iris-ring dissolve** | The gold gauge ring fades out over the night street |
| T12 | f1078–1092 (36.0–36.4 s) | **Persistent-object dissolve** | The frog stays at the same screen position while street → hospital |
| T13 | f1162–1188 (38.7–39.6 s) | **Polaroid grow + border slide-off** | Camera passes Jerry's face to a polaroid that grows toward the lens with a diagonal glare streak; its white border/caption strip slides down and the picture fills the frame |
| T14 | f1264–1280 (42.1–42.7 s) | **Reverse polaroid** | The lake is re-framed inside a shrinking polaroid, dims, and becomes the polaroid clipped on the IV stand |
| T15 | f1326–1336 (44.2–44.5 s) | **Face-position dissolve** | Corridor face ghosts out at left while the lamp-lit desk face emerges at right |
| T16 | f1412–1418 (47.0–47.2 s) | **Face-ghost dissolve** | Desk face ghosts over the birthday-card macro |
| T17 | f1433–1452 (47.8–48.4 s) | **Pull-back + ball-hand swing** | Card macro → gauge box on pole; a dark ball-hand swings in and presses it; Jerry swings into frame |
| T18 | f1498–1512 (49.9–50.4 s) | **Orange/blue overlay dissolve** | Red-lit corridor figure ghosts over the 'WE BUY SUMMERS' scene |
| T19 | f1636–1648 (54.5–54.9 s) | **Warm→cold dissolve** | Warm sign-lit face fades into the blue sickroom |
| T20 | f1678–1692 (55.9–56.4 s) | **Dissolve to giant face + ledger push-in** | Bed → huge cold-lit Jerry face holding the open ledger; camera pushes in until the page fills the frame (f1693–1716) |
| T21 | f1737–1748 (57.9–58.3 s) | **Ledger-up dissolve** | Ledger page dissolves upward into the shop |
| T22 | f1902–1976 (63.4–65.9 s) | **Dome-descent → tube-follow → pixel mosaic → gold blow-out** | Lamp dome lowers on Jerry's head; camera tilts up the tube; sign letters tumble; frame breaks into pixel blocks; card glows and blows out to gold-white (peak f1969–1973) |
| T23 | f1976–1992 (65.9–66.4 s) | **Gold dissolve** | Gold blow-out → morning ward with a blue-white smear |
| T24 | f2137–2143 (71.2–71.4 s) | **Face-match dissolve + cold flip** | Brother's face ghosts onto Jerry's face at the same position while cream light flips to cold cobalt |

**Transition families to reuse:** (a) *object/prop match* — frog, polaroid, dial ring; (b) *face-position match* — T15, T16, T24; (c) *light-led* — white blow-out, red bleed, gold blow-out, cold flip; (d) *camera-led* — swing, pull-up, tilt-up, pull-back; (e) *physical overlay* — glass pane, window glass, vertical light streaks, pixel mosaic.

## Camera move vocabulary (how each scene moves)
| Scene | Move | Speed | Notes |
|---|---|---|---|
| S01 | Low-angle static → swing-pitch down | fast (0.4 s) | See T1 |
| S02 | Macro push-in + rack focus | slow | Shallow DOF, blurred register in BG |
| S03 | Slow push-in + lateral drift | 0.4–0.9 px/f | Slight Dutch tilt; grin widens as camera closes in |
| S04–S05 | Forward dolly down the alley | medium | Vanishing-point light at the far end |
| S06 | Dolly-in + tilt up to the lamp | slow | Lamp bloom grows 7.5→8.0 s |
| S07 | Low angle → track right → crane down on the bike | medium | Rain visible, kid falls at ≈ 13 s |
| S08 | **Tilt up the wall** (Dutch ~15–20°) | medium | God-rays from top, lens flare |
| S09 | Water-level dolly forward + rise | medium | Reveals loungers from far to near |
| S10 | Tilt down helmet → counter | medium | Odometer digits roll to 300 |
| S11 | Pull-back wide → top-down dive onto water | medium | See T5 |
| S12 | Low static → very slow push-in | 0.3–0.9 px/f | Sharpest scene in the film |
| S13 | Tight static with breathing push | tiny | Gauge needle climbs, glow brightens |
| S14 | Low Dutch street, then tilt down into reflection | medium | Wet-ground mirror image |
| S15 | Slow orbit push on bedside | slow | |
| S16 | Gentle drift + parallax on dock | 0.47 | Frog leap = only fast element |
| S17 | Static two-shot, slow push | very slow | Face lit from below |
| S18 | Whip pull-back | fast | See T8 |
| S19 | Eye-level hold with tiny head-drift | 0.46 | Expression carries it |
| S20 | Bed → ledger page | medium | |
| S21 | Slow push to stranger's face, reverse to Jerry | slow | |
| S22 | Whip-follow of tube | very fast | See T10 |
| S23 | Near-static, shallow DOF | 0.35 | Background bokeh |
| S24 | Very slow push-in → freeze | 0.62 → 0.008 | Final hold |

## Parallax / depth
* Characters are billboard-like flat cut-outs; environment is true 3D → camera moves produce real parallax between character and set.
* Foreground occluders (glass pane, hood, railing) pass in front to sell depth.
* Depth-of-field: **shallow** in S02, S23, S24 (heavy lens blur on backgrounds, a soft ≈20–30 px blur at 720p); **deep focus** in the rich scenes (S09–S11) and S12.
